import Link from 'next/link';
import { BorrowedBuffer } from '@/components/borrowed-buffer';
import { DispatchExample } from '@/components/dispatch-example';
import { FunctionLab } from '@/components/function-lab';
import { BatchBoundary } from '@/components/batch-boundary';

export function NextRelease() {
  return (
    <section aria-labelledby="next-release-title" className="border-y border-white/10 bg-white/[0.015] py-20">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-6 lg:grid-cols-2 lg:gap-20 lg:px-8">
        <div className="min-w-0">
          <p className="mono text-[11px] uppercase tracking-[0.2em] text-aurora-cyan">In development · unreleased</p>
          <h2 id="next-release-title" className="mt-4 font-display text-4xl font-medium tracking-tight text-ink-50">Borrow the payload.<br />Keep the checks.</h2>
          <p className="mt-5 max-w-lg text-[15px] leading-relaxed text-ink-200">Declare one wire layout. Accept <code>&amp;MyArgs</code> in an ordinary Rust handler, or parse it at a manual entrypoint. Both paths borrow the input and check nested option and enum values.</p>
          <p className="mt-4 max-w-lg text-sm leading-relaxed text-ink-300">These excerpts share the same update function in the Solana fixture. Select an entry path, then explore valid and refused inputs in the browser illustration. Account authorization and business rules remain explicit.</p>
          <DispatchExample />
          <Link href="/docs/release-readiness" className="mt-6 inline-block text-sm text-aurora-cyan underline underline-offset-4">Follow release readiness</Link>
        </div>
        <div className="min-w-0">
          <BorrowedBuffer />
          <FunctionLab />
        </div>
      </div>
      <BatchBoundary />
    </section>
  );
}
