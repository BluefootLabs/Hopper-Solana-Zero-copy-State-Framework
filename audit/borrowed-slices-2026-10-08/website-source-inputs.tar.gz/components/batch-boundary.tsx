'use client';

import { useId, useState } from 'react';
import Link from 'next/link';
import { ArrowUpRight, Check, X } from 'lucide-react';

export function BatchBoundary() {
  const id = useId();
  const [count, setCount] = useState(2);
  const [malformed, setMalformed] = useState(false);
  const rejected = count > 4 || (malformed && count > 0);
  const reason = count > 4
    ? 'Five elements exceed the declared capacity of four. The handler does not run.'
    : malformed && count > 0
      ? 'The last element has an invalid option tag. The whole batch is refused before handler admission.'
      : count === 0
        ? 'An empty batch is a valid encoding. Your application can require at least one element.'
        : `All ${count} elements pass representation checks. The handler borrows the original bytes and applies its application rules.`;

  return (
    <div className="mx-auto mt-12 max-w-7xl px-6 lg:px-8">
      <section aria-labelledby={`${id}-title`} className="grid gap-8 rounded-3xl border border-aurora-cyan/20 bg-[#0b1317] p-6 sm:p-8 lg:grid-cols-[1fr_1.1fr] lg:p-10">
        <div>
          <p className="mono text-[10px] uppercase tracking-[0.18em] text-aurora-cyan">Next release · checked borrowed batches</p>
          <h3 id={`${id}-title`} className="mt-4 font-display text-3xl tracking-tight text-ink-50">More elements.<br />One borrowed buffer.</h3>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-ink-200">Give a batch a capacity and a wire type. Hopper checks every element before your handler runs, without copying the batch into a capacity-sized array.</p>
          <code className="mt-5 block break-all rounded-xl border border-white/10 bg-black/20 p-4 text-xs text-aurora-lime">orders: BoundedSlice&lt;&apos;_, Order, 4&gt;</code>
          <p className="mt-3 text-xs leading-relaxed text-ink-300">Validation visits the present elements. Borrowing saves the owned container; application checks and Solana transaction limits still apply.</p>
          <Link href="/docs/borrowed-slices" className="mt-5 inline-flex min-h-11 items-center gap-2 text-sm text-aurora-cyan underline underline-offset-4">Explore the batch contract <ArrowUpRight size={14} aria-hidden /></Link>
        </div>
        <div className="min-w-0">
          <div className="flex items-center justify-between gap-3">
            <label htmlFor={`${id}-count`} className="text-sm text-ink-100">Elements in the input</label>
            <output htmlFor={`${id}-count`} className="mono text-sm text-aurora-cyan">{count} / 4 capacity</output>
          </div>
          <input id={`${id}-count`} type="range" min="0" max="5" step="1" value={count} onChange={event => setCount(Number(event.target.value))} aria-controls={`${id}-result`} className="mt-2 h-11 w-full cursor-pointer accent-[#4de0e0]" />
          <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-6" aria-label={`${2 + count * 10} payload bytes: a two-byte count and ${count} ten-byte orders`} role="img">
            <div className="flex min-h-20 flex-col justify-center rounded-lg border border-aurora-cyan/40 bg-aurora-cyan/10 p-2 text-center" aria-hidden>
              <span className="mono text-xs text-aurora-cyan">0{count} 00</span><span className="mt-2 text-[10px] text-ink-200">count</span>
            </div>
            {Array.from({ length: 5 }, (_, index) => (
              <div key={index} aria-hidden className={`flex min-h-20 flex-col justify-center rounded-lg border p-2 text-center transition-colors motion-reduce:transition-none ${index >= count ? 'border-dashed border-white/15 text-ink-400' : index >= 4 || (malformed && index === count - 1) ? 'border-[#ffac94]/50 bg-[#ffac94]/10 text-[#ffac94]' : 'border-aurora-lime/30 bg-aurora-lime/[0.07] text-aurora-lime'}`}>
                <span className="mono text-xs">{index < count ? `0${index + 1}` : '—'}</span><span className="mt-2 text-[10px]">{index < count ? '10 bytes' : 'unused'}</span>
              </div>
            ))}
          </div>
          <label className="mt-4 flex min-h-11 cursor-pointer items-center gap-3 text-xs text-ink-200">
            <input type="checkbox" checked={malformed} onChange={event => setMalformed(event.target.checked)} aria-controls={`${id}-result`} className="h-4 w-4 accent-[#4de0e0]" />
            Give the last element an invalid option tag
          </label>
          <div id={`${id}-result`} role="status" aria-live="polite" aria-atomic="true" className={`mt-3 min-h-32 rounded-xl border p-4 ${rejected ? 'border-[#ffac94]/30 bg-[#ffac94]/[0.04]' : 'border-aurora-lime/25 bg-aurora-lime/[0.04]'}`}>
            <div className={`flex items-center gap-2 text-sm ${rejected ? 'text-[#ffac94]' : 'text-aurora-lime'}`}>{rejected ? <X size={16} aria-hidden /> : <Check size={16} aria-hidden />}{rejected ? 'Batch refused' : 'Borrow accepted'}</div>
            <p className="mt-2 text-xs leading-relaxed text-ink-200">{reason}</p>
          </div>
          <p className="mt-3 mono text-[10px] text-ink-300">Interactive wire-format illustration · not a transaction simulator</p>
        </div>
      </section>
    </div>
  );
}
