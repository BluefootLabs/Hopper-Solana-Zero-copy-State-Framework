import { PUBLISHED_VERSION } from './release';

export const SITE = 'https://hopperzero.dev';
export const REPO = 'https://github.com/BluefootLabs/Hopper-Solana-Zero-copy-State-Framework';

export type DocCategory =
  | 'Start'
  | 'Model'
  | 'Migration'
  | 'Operations'
  | 'Safety';

export type DocMeta = {
  slug: string;
  title: string;
  description: string;
  category: DocCategory;
  sourcePath: string;
};

export const DOCS: DocMeta[] = [
  {
    slug: 'borrowed-slices',
    title: 'Borrow bounded batches',
    description: 'Checked variable-length instruction views, reusable wire contracts, and generated clients.',
    category: 'Model',
    sourcePath: 'docs/BORROWED_SLICES.md',
  },
  {
    slug: 'network-baseline',
    title: 'Current network baseline',
    description: 'October 7, 2026 feature observations, tested syscall limits and sysvar consistency findings.',
    category: 'Operations',
    sourcePath: 'docs/SOLANA_NETWORK_BASELINE.md',
  },
  {
    slug: 'function-lab',
    title: 'Test functions on Solana',
    description: 'Executable probes, independent expected values, account invariants and explicit cluster limits.',
    category: 'Safety',
    sourcePath: 'bench/function-lab/README.md',
  },
  {
    slug: 'release-readiness',
    title: 'Release readiness',
    description: 'Current execution receipts, dossier findings, and remaining release requirements.',
    category: 'Safety',
    sourcePath: 'docs/RELEASE_READINESS.md',
  },
  {
    slug: 'framework-boundaries',
    title: 'Choosing a zero-copy boundary',
    description: 'Source-pinned comparisons with Pinocchio, Pina, Quasar, and Anchor v2.',
    category: 'Migration',
    sourcePath: 'docs/FRAMEWORK_BOUNDARIES.md',
  },
  {
    slug: 'solana-baseline',
    title: 'Solana compatibility baseline',
    description: 'Finalized feature and rent observations with explicit transaction and deployment limits.',
    category: 'Operations',
    sourcePath: 'docs/SOLANA_NETWORK_BASELINE.md',
  },
  {
    slug: 'borrowed-arguments',
    title: 'Borrowed instruction arguments',
    description: 'Unreleased: validate nested zero-copy arguments and choose exact payloads or borrowed tails.',
    category: 'Safety',
    sourcePath: 'docs/BORROWED_ARGUMENTS.md',
  },
  {
    slug: 'instruction-introspection',
    title: 'Inspect prior calls on chain',
    description: 'Read a prior call, its accounts, and its privileges with caller-owned buffers and explicit authorization.',
    category: 'Safety',
    sourcePath: 'docs/INSTRUCTION_INTROSPECTION.md',
  },
  {
    slug: 'token-receipts',
    title: 'Verify token payouts',
    description: 'Set a minimum receipt for escrow releases, claims, and treasury payouts, including transfer fees.',
    category: 'Start',
    sourcePath: 'docs/TOKEN_RECEIPTS.md',
  },
  {
    slug: 'treasury',
    title: 'Delegated SOL treasury',
    description: 'Fund a treasury and enforce operator, budget, freeze, cooldown, and rent rules on withdrawals.',
    category: 'Start',
    sourcePath: 'examples/hopper-treasury/README.md',
  },
  {
    slug: 'token-escrow',
    title: 'Funded token escrow',
    description: 'Classic SPL Token custody, atomic exchange, maker refunds, and explicit token policy.',
    category: 'Start',
    sourcePath: 'examples/hopper-escrow/README.md',
  },
  {
    slug: 'governance',
    title: 'Governance and DAOs',
    description: 'Member-approved SOL custody, expiring payouts, permissionless execution, and revocation.',
    category: 'Start',
    sourcePath: 'docs/GOVERNANCE_PROGRAMS.md',
  },
  {
    slug: 'use-cases',
    title: 'Build your application',
    description: 'Trading, claims, and NFT markets: available examples, building blocks, and integrations you supply.',
    category: 'Start',
    sourcePath: 'docs/APPLICATION_USE_CASES.md',
  },
  {
    slug: 'named-initialization',
    title: 'Named initialization',
    description: 'Create typed state with named values and application-defined inputs.',
    category: 'Start',
    sourcePath: 'docs/NAMED_INITIALIZATION.md',
  },
  {
    slug: 'from-pinocchio',
    title: 'Write lower-level programs',
    description: 'Use account views, checked CPI, and syscalls directly, with explicit validation and workload tests.',
    category: 'Migration',
    sourcePath: 'docs/FROM_PINOCCHIO.md',
  },
  {
    slug: 'migration-0-4',
    title: 'Moving to Hopper 0.4',
    description: 'Matching derive versions, corrected overlays, and stricter memory bounds.',
    category: 'Migration',
    sourcePath: 'docs/MIGRATION_0_4.md',
  },
  {
    slug: 'migration-0-5',
    title: 'Moving to Hopper 0.5',
    description: 'Two readers that close unsound borrows, the versions that follow from them, and what is new.',
    category: 'Migration',
    sourcePath: 'docs/MIGRATION_0_5.md',
  },
  {
    slug: 'program-design',
    title: 'Program design',
    description: 'Design executable account, authorization, asset, and CPI contracts.',
    category: 'Safety',
    sourcePath: 'docs/PROGRAM_DESIGN.md',
  },
  {
    slug: 'byte-allowance',
    title: 'On-chain byte allowance',
    description:
      'A four-cell application quota program with captured selectors, delegate checks, revisions, and strict byte policies.',
    category: 'Start',
    sourcePath: 'docs/ONCHAIN_BYTE_POLICIES.md',
  },
  {
    slug: 'solana-network',
    title: 'Solana network compatibility',
    description:
      'September 30 local / October 1 UTC public-cluster observations, Alpenglow on devnet and testnet, and on-chain Clock semantics.',
    category: 'Operations',
    sourcePath: 'docs/SOLANA_NETWORK.md',
  },
  {
    slug: 'release-status',
    title: 'Release and audit status',
    description:
      `The published ${PUBLISHED_VERSION} registry release, verified package checksums, dated program evidence, and remaining audit work.`,
    category: 'Start',
    sourcePath: 'docs/RELEASE_0_5_VALIDATION.md',
  },
  {
    slug: 'first-five',
    title: 'First five minutes',
    description:
      'The shortest path through account declarations, typed contexts, handlers, dynamic tails, and raw escape hatches.',
    category: 'Start',
    sourcePath: 'docs/FIRST_FIVE_MINUTES.md',
  },
  {
    slug: 'start',
    title: 'Getting started serious',
    description:
      'Install Hopper, scaffold a program, and ship a complete first workflow.',
    category: 'Start',
    sourcePath: 'docs/GETTING_STARTED_SERIOUS.md',
  },
  {
    slug: 'why-hopper',
    title: 'Why Hopper',
    description:
      'Build programs that move funds, read state in place, and enforce application rules on chain.',
    category: 'Start',
    sourcePath: 'docs/WHY_HOPPER.md',
  },
  {
    slug: 'model',
    title: 'The Hopper model',
    description:
      'How Hopper loads, validates, mutates, records, migrates, and explains account state.',
    category: 'Model',
    sourcePath: 'docs/THE_HOPPER_MODEL.md',
  },
  {
    slug: 'architecture',
    title: 'Architecture',
    description:
      'The crate and runtime layers behind typed zero-copy state, schemas, receipts, and CLI inspection.',
    category: 'Model',
    sourcePath: 'docs/ARCHITECTURE.md',
  },
  {
    slug: 'layers',
    title: 'Hopper layers',
    description: 'A map of the framework, runtime, schema, SPL, CLI, and example layers.',
    category: 'Model',
    sourcePath: 'docs/HOPPER_LAYERS.md',
  },
  {
    slug: 'writing',
    title: 'Writing programs',
    description: 'Layouts, contexts, policies, receipts, and the program structure Hopper expects.',
    category: 'Start',
    sourcePath: 'docs/WRITING_HOPPER_PROGRAMS.md',
  },
  {
    slug: 'memory-access',
    title: 'Memory access',
    description: 'The safe, pod, raw, and cross-program access tiers and when each belongs in a handler.',
    category: 'Model',
    sourcePath: 'docs/MEMORY_ACCESS.md',
  },
  {
    slug: 'policy',
    title: 'Policy guarantees',
    description: 'Strict, sealed, and raw modes, plus what each access tier promises.',
    category: 'Safety',
    sourcePath: 'docs/POLICY_GUARANTEES.md',
  },
  {
    slug: 'event-cpi',
    title: 'Events over self-CPI',
    description:
      'Anchor’s emit_cpi ergonomics on a 3-byte wire: authenticated event self-CPI, measured costs, and the runtime PDA trade-off, live on devnet.',
    category: 'Model',
    sourcePath: 'examples/hopper-smoke/tests/event_cpi_sbf_e2e.rs',
  },
  {
    slug: 'composite-contexts',
    title: 'Composite contexts',
    description:
      'Nest one accounts context inside another with Anchor-style flattening, and write-sets, events, and touch maps that compose across the boundary.',
    category: 'Model',
    sourcePath: 'tests/composite_contexts_integration.rs',
  },
  {
    slug: 'lazy-migration',
    title: 'Lazy migration at bind',
    description:
      'Declare the previous layout version on a field and every instruction becomes a migration crank, typed, in place, measured live on devnet.',
    category: 'Migration',
    sourcePath: 'examples/hopper-smoke/tests/note_migration_sbf_e2e.rs',
  },
  {
    slug: 'self-describing-transactions',
    title: 'Self-describing transactions',
    description:
      'Opt-in byte-range touch maps for Hopper-tracked acquisitions, with raw escapes and partial maps kept outside completeness claims.',
    category: 'Operations',
    sourcePath: 'examples/hopper-smoke/tests/touch_map_e2e.rs',
  },
  {
    slug: 'tx-tooling',
    title: 'Manifests and tx tooling',
    description:
      'Manifest generation, versioned ELF interface binding, and the no-Node hopper tx send / tx explain loop.',
    category: 'Operations',
    sourcePath: 'examples/hopper-smoke/hopper.manifest.json',
  },
  {
    slug: 'self-audit',
    title: 'Self-audit',
    description:
      'What Hopper checks at compile time, at bind, and between releases, and what those checks do not prove.',
    category: 'Safety',
    sourcePath: 'docs/SELF_AUDIT.md',
  },
  {
    slug: 'effect-verification',
    title: 'Offline effect verification',
    description:
      'How Grillo recomputes mutation containment, what its PASS proves, and why it has no on-chain deployment rent.',
    category: 'Operations',
    sourcePath: 'docs/EFFECT_VERIFICATION.md',
  },
  {
    slug: 'token-2022',
    title: 'Token-2022 guide',
    description:
      'Validate Token-2022 ownership and extensions, and initialize exact-size mints with explicit extension plans.',
    category: 'Start',
    sourcePath: 'docs/TOKEN_2022_GUIDE.md',
  },
  {
    slug: 'crypto-capabilities',
    title: 'Crypto capabilities',
    description:
      'Hashing, precompile checks, secp recovery, and opt-in curve, Poseidon, BN254, and modular-exponentiation APIs.',
    category: 'Model',
    sourcePath: 'docs/CRYPTO_CAPABILITIES.md',
  },
  {
    slug: 'schema',
    title: 'Schema architecture',
    description:
      'Program manifests, layout IDs, Hopper IDL, Codama JSON, lossless Solana IDL projection, and compatibility diffs.',
    category: 'Operations',
    sourcePath: 'docs/SCHEMA_ARCHITECTURE.md',
  },
  {
    slug: 'onchain-schema',
    title: 'On-chain schema proposal',
    description:
      'A clearly labeled design for future manifest pointers, separate from the shipped Program Metadata IDL path.',
    category: 'Operations',
    sourcePath: 'docs/ONCHAIN_SCHEMA_PUBLICATION.md',
  },
  {
    slug: 'dynamic-fields',
    title: 'Bounded account fields',
    description:
      'Bounded strings and vectors with Hopper layout fingerprints and migration-aware capacities.',
    category: 'Migration',
    sourcePath: 'docs/BOUNDED_FIELDS.md',
  },
  {
    slug: 'collections-resizing',
    title: 'Collections and safe resizing',
    description:
      'Bounded fields, growable Seq, stable-ID Slab, and rent-safe grow or fit migrations over account bytes.',
    category: 'Migration',
    sourcePath: 'docs/COLLECTIONS_AND_RESIZING.md',
  },
  {
    slug: 'dynamic-tails',
    title: 'Dynamic account tails',
    description: 'Final TailStr and TailBytes regions for deliberate remaining-byte account designs.',
    category: 'Migration',
    sourcePath: 'docs/DYNAMIC_TAILS.md',
  },
  {
    slug: 'program-migration',
    title: 'Program migration',
    description: 'How to map account constraints, IDL expectations, and program structure into Hopper.',
    category: 'Migration',
    sourcePath: 'docs/PROGRAM_MIGRATION.md',
  },
  {
    slug: 'program-capabilities',
    title: 'Program capabilities',
    description: 'Account lifecycle, asset movement, governance, integration APIs, and their boundaries.',
    category: 'Migration',
    sourcePath: 'docs/PROGRAM_CAPABILITIES.md',
  },
  {
    slug: 'bounded-multisig',
    title: 'Bounded multisig',
    description: 'Real member signatures, bounded storage, and SOL deposits and withdrawals.',
    category: 'Migration',
    sourcePath: 'examples/hopper-bounded-multisig/README.md',
  },
  {
    slug: 'tail-lab',
    title: 'Tail lab example',
    description: 'Bounded dynamic fields, TailStr, TailBytes, init helpers, and account wrappers.',
    category: 'Start',
    sourcePath: 'examples/hopper-tail-lab/README.md',
  },
  {
    slug: 'styx-ferry-messaging',
    title: 'Styx ferry messaging',
    description:
      'Forward-secret messaging and VSL ferry proof control plane using Hopper crypto, precompile checks, and verifier CPI paths.',
    category: 'Start',
    sourcePath: 'examples/hopper-styx-ferry/README.md',
  },
  {
    slug: 'cli',
    title: 'CLI reference',
    description: 'Schema export, account inspection, explain, manager, profiling, publish checks, and client generation.',
    category: 'Operations',
    sourcePath: 'docs/CLI_REFERENCE.md',
  },
  {
    slug: 'client-generation',
    title: 'Client generation',
    description: 'Generate TypeScript, Kotlin, Python, Go, C, and off-chain Rust clients from one Hopper manifest.',
    category: 'Operations',
    sourcePath: 'docs/CLIENT_GENERATION.md',
  },
  {
    slug: 'manager',
    title: 'Hopper manager',
    description: 'Operator-facing manifest fetch, decode, identify, summary, invoke, receipt, and crank tools.',
    category: 'Operations',
    sourcePath: 'docs/HOPPER_MANAGER.md',
  },
  {
    slug: 'native-backend',
    title: 'Native backend',
    description: 'The native account-view substrate, syscall boundary, and no_std runtime shape.',
    category: 'Model',
    sourcePath: 'docs/HOPPER_NATIVE_BACKEND.md',
  },
  {
    slug: 'native-enhancements',
    title: 'Native enhancements',
    description: 'Native backend capabilities that make Hopper programs inspectable without changing the wire format.',
    category: 'Model',
    sourcePath: 'docs/HOPPER_NATIVE_ENHANCEMENTS.md',
  },
  {
    slug: 'profiling',
    title: 'Profiling',
    description: 'Static SBF ELF analysis, folded-stack output, flamegraph export, and benchmark provenance.',
    category: 'Operations',
    sourcePath: 'docs/PROFILING.md',
  },
  {
    slug: 'cu-costs',
    title: 'CU costs',
    description: 'Compute-unit notes for validation, loading, receipts, events, and access tiers.',
    category: 'Operations',
    sourcePath: 'docs/CU_COSTS.md',
  },
  {
    slug: 'protocol-examples',
    title: 'Program examples',
    description: 'Examples that combine policies, typed contexts, dynamic state, schemas, and operational tooling.',
    category: 'Start',
    sourcePath: 'docs/PROTOCOL_GRADE_EXAMPLES.md',
  },
  {
    slug: 'proc-macros',
    title: 'Proc macro policy',
    description: 'The public macro contract for account, context, program, instruction, and policy generation.',
    category: 'Safety',
    sourcePath: 'docs/PROC_MACRO_POLICY.md',
  },
  {
    slug: 'unsafe',
    title: 'Unsafe invariants',
    description: 'The audit ledger for raw-pointer boundaries and safety contracts.',
    category: 'Safety',
    sourcePath: 'docs/UNSAFE_INVARIANTS.md',
  },
  {
    slug: 'benchmarks',
    title: 'Benchmark policy',
    description: 'How Hopper reports same-provenance performance data without overclaiming.',
    category: 'Operations',
    sourcePath: 'BENCHMARKS.md',
  },
];

export const DOC_CATEGORIES: DocCategory[] = ['Start', 'Model', 'Migration', 'Operations', 'Safety'];

const sourcePathToSlug = new Map(DOCS.map((doc) => [normalizeSourcePath(doc.sourcePath), doc.slug]));
const sourceFileToSlug = new Map<string, string>(
  DOCS.filter((doc) => fileName(doc.sourcePath) !== 'readme.md').map((doc) => [fileName(doc.sourcePath), doc.slug]),
);

export function getDocBySlug(slug: string): DocMeta | undefined {
  return DOCS.find((doc) => doc.slug === slug);
}

export function getDocNeighbors(slug: string) {
  const index = DOCS.findIndex((doc) => doc.slug === slug);
  return {
    previous: index > 0 ? DOCS[index - 1] : undefined,
    next: index >= 0 && index < DOCS.length - 1 ? DOCS[index + 1] : undefined,
  };
}

export function sourceHref(sourcePath: string): string {
  const normalized = normalizeSourcePath(sourcePath);
  const kind = /\/[^/]+\.[a-z0-9]+$/i.test(`/${normalized}`) ? 'blob' : 'tree';
  return `${REPO}/${kind}/main/${normalized}`;
}

export function rewriteSourceHref(href: string): string {
  if (
    href.startsWith('/') ||
    href.startsWith('#') ||
    href.startsWith('http://') ||
    href.startsWith('https://') ||
    href.startsWith('mailto:')
  ) {
    return href;
  }

  const [withoutHash, hash = ''] = href.split('#');
  const rawPath = withoutHash.replace(/\\/g, '/');
  const normalized = normalizeSourcePath(rawPath);
  const slug = sourcePathToSlug.get(normalized) ?? sourceFileToSlug.get(fileName(normalized));
  if (slug) {
    return `/docs/${slug}${hash ? `#${hash}` : ''}`;
  }

  const sourcePath = normalized.startsWith('docs/')
    || normalized.startsWith('examples/')
    || normalized.startsWith('bench/')
    || normalized.startsWith('audit/')
    || normalized.startsWith('crates/')
    || normalized.startsWith('tools/')
    || normalized.startsWith('tests/')
    || normalized.startsWith('scripts/')
    || normalized.startsWith('src/')
    || normalized.startsWith('release/')
    || normalized === 'README.md'
    || normalized === 'BENCHMARKS.md'
    || normalized === 'CHANGELOG.md'
    ? normalized
    : `docs/${normalized}`;

  return `${sourceHref(sourcePath)}${hash ? `#${hash}` : ''}`;
}

function normalizeSourcePath(sourcePath: string): string {
  return sourcePath
    .replace(/\\/g, '/')
    .replace(/^\.\//, '')
    .replace(/^\.\.\//, '')
    .replace(/^main\//, '');
}

function fileName(sourcePath: string): string {
  return normalizeSourcePath(sourcePath).split('/').pop()?.toLowerCase() ?? sourcePath.toLowerCase();
}
