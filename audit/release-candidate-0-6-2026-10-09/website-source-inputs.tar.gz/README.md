# Hopper website

Next.js website and public documentation for the Hopper zero-copy Solana program
framework. Lead with Rust authoring, supported zero-copy account access, working
examples, and scoped validation evidence.

The homepage's state/account/handler walkthrough uses excerpts from the framework
source. `content/program-examples.json` records each source file, selectors,
starting line, and normalized SHA-256. Both code components use that data. Check
it against the framework checkout before publishing:

```sh
npm run check:examples -- --framework ../Hopper-Solana-Zero-copy-State-Framework
```

To refresh snippets, run `npm run sync:examples -- --framework <checkout>` and
review the changed source and captions. This checks source correspondence; it
does not compile Rust or prove on-chain behavior. Link excerpts to the complete
program, including initialization and validation omitted by a short example.

The instruction-buffer model includes malformed tags, truncated input, and an
extra byte. Its checked-tail switch explains the difference between exact
payloads and a separately borrowed tail. It is an illustrative browser model;
the linked Rust fixture and devnet receipts provide execution evidence.

Release readiness, source-pinned framework boundaries, and the dated Solana
baseline are mirrored from the framework docs. Keep these and the self-audit
guide synchronized. Unreleased APIs retain their next-release labels.

## Development

```sh
npm ci
npm run dev
npm run build
npm run lint
```

`lib/docs.ts` owns the guide index and source mapping. Markdown in `content/docs`
is rendered by the docs routes. `lib/release.ts` owns published version labels;
update those only after verified registry publication.

The `borrowed-arguments` guide documents unreleased recursive argument validation
and the exact-length and checked-tail APIs. Its source is
`docs/BORROWED_ARGUMENTS.md` in the framework workspace; keep both copies aligned.

The homepage's separately labeled next-release `BorrowedBuffer` models the 12-byte prefix used by the compiled
borrowed-argument fixture. Its radio controls show accepted, invalid-tag, and
truncated inputs, with text and icon feedback in a live status region. It is an
illustration, not a browser execution of the Rust parser. Unreleased APIs stay
visibly separate from the published installation command.

The model guide distinguishes account admission, application logic, optional
write policies and receipts, and Solana runtime enforcement. Keep it synchronized
with `docs/THE_HOPPER_MODEL.md`. Zero-copy claims describe supported state views;
handler argument decoding, dynamic codecs, clients, and CPIs have separate costs.

The visual system uses dark surfaces, cyan for structure, lime for actions and
accepted input, and peach for refusals. Short entrance and byte transitions
respect reduced motion; `MotionProvider` applies that preference to existing
Framer Motion components. Mobile navigation supports keyboard activation and
Escape. Keep those behaviors when editing the homepage.

The unreleased section also compares manual parsing and generated borrowed
handlers using source-synchronized excerpts. Published and unreleased examples
have explicit status fields; only published examples appear in the main code
showcase. The comparison shows Rust source, not execution in the browser.

Keep account names, instruction payloads, supported assets, and feature boundaries
aligned with the framework code. Public copy describes Hopper's own behavior.

The function-lab disclosures explain what a runtime test checks: returned bytes,
expected refusals, account invariants and cluster support. Native `details`
controls work with a keyboard and without client JavaScript. The matching guide
mirrors `bench/function-lab/README.md`; keep measured outcomes scoped to the
archived build instead of describing every framework feature as verified.
Research analysis is not product documentation. Legal attribution and exact
interoperability API names remain accurate when an integration needs them.

Use dated evidence for performance numbers. Distinguish executable asset programs
from data structures, proposed features, and application integrations. Do not
imply that byte-range state access changes Solana's whole-account locks.

Before publishing, build the site, check edited code, and verify rendered routes,
heading links, version labels, and application claims. Capture the exact production
commit and repeat the page checks against the live deployment.

The next-release section includes an accessible bounded-batch illustration.
Its count, capacity, and malformed-element states explain the wire contract;
it is not an execution simulator. The borrowed-batches guide documents the
unreleased API and generated-client limits.

To check the batch controls against a running local site, reuse a local
Playwright installation:

```sh
node scripts/check-batch-boundary.mjs --playwright /path/to/playwright \
  --base http://127.0.0.1:3191 --out .next/batch-qa
```

An optional `--browser /path/to/chromium` selects an installed executable.
The check exercises keyboard controls, malformed inputs, navigation, and
horizontal overflow at desktop/mobile widths with reduced motion enabled.
It records screenshots and the actual browser version.

The source targets Hopper 0.6.0 while install commands continue to point to the
verified 0.5.0 registry release. The migration page lists bounded-client support
and the batch panel explains that wire metadata survives Rust type aliases.
