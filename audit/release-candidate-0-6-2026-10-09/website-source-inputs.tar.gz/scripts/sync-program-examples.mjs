import { createHash } from 'node:crypto';
import { readFile, realpath, writeFile } from 'node:fs/promises';
import { dirname, isAbsolute, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const site = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const frameworkAt = args.indexOf('--framework');
if (frameworkAt < 0 || !args[frameworkAt + 1] || args[frameworkAt + 1].startsWith('--')) {
  console.error('Usage: node scripts/sync-program-examples.mjs --framework <checkout> [--check]');
  process.exit(2);
}
const remaining = args.filter((_, index) => index !== frameworkAt && index !== frameworkAt + 1);
if (remaining.some((arg) => arg !== '--check') || remaining.length > 1) {
  console.error('Only --framework <checkout> and --check are supported.');
  process.exit(2);
}

const root = await realpath(resolve(args[frameworkAt + 1]));
const path = resolve(site, 'content/program-examples.json');
const previous = await readFile(path, 'utf8');
const examples = JSON.parse(previous);
for (const example of examples) {
  const sourcePath = await realpath(resolve(root, example.filename));
  const rel = relative(root, sourcePath);
  if (isAbsolute(rel) || rel === '..' || rel.startsWith('../') || rel.startsWith('..\\')) {
    throw new Error(`Source escapes the framework checkout: ${example.filename}`);
  }
  const source = (await readFile(sourcePath, 'utf8')).replace(/\r\n/g, '\n');
  const start = source.indexOf(example.from);
  if (start < 0 || source.indexOf(example.from, start + 1) >= 0) {
    throw new Error(`${example.id}: start selector must match exactly once`);
  }
  const end = source.indexOf(example.through, start);
  if (end < 0) throw new Error(`${example.id}: end selector was not found`);
  const lines = source.slice(start, end + example.through.length).split('\n');
  const indent = lines.slice(1).filter((line) => line.trim()).reduce(
    (min, line) => Math.min(min, line.match(/^ */)[0].length),
    source.slice(source.lastIndexOf('\n', start) + 1, start).length,
  );
  example.code = lines.map((line, index) => index ? line.slice(Math.min(indent, line.match(/^ */)[0].length)) : line).join('\n');
  example.sourceLine = source.slice(0, start).split('\n').length;
  example.sourceSha256 = createHash('sha256').update(source).digest('hex');
}
const next = `${JSON.stringify(examples, null, 2)}\n`;
if (remaining.includes('--check')) {
  if (previous.replace(/\r\n/g, '\n') !== next) {
    console.error('Website examples differ from the supplied framework source. Run the sync command and review the result.');
    process.exit(1);
  }
  console.log(`${examples.length} website excerpts match their framework source and file hashes.`);
} else {
  await writeFile(path, next);
  console.log(`Updated ${examples.length} website excerpts from ${root}.`);
}
