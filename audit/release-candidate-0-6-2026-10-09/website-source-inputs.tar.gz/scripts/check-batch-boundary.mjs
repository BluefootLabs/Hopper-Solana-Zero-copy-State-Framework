// Exercise the published UI in a local Playwright browser. Browser and module
// paths are explicit so this optional check can reuse an installed test tool.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs } from 'node:util';
import { createRequire } from 'node:module';
const { values } = parseArgs({ options: {
  playwright: { type: 'string' }, browser: { type: 'string' },
  base: { type: 'string', default: 'http://127.0.0.1:3191' },
  out: { type: 'string' },
} });
if (!values.playwright || !values.out) throw new Error('Supply --playwright MODULE_PATH and --out ARTIFACT_DIRECTORY');
const { chromium } = createRequire(import.meta.url)(path.resolve(values.playwright));

(async () => {
  fs.mkdirSync(values.out, { recursive: true });
  const browser = await chromium.launch({ headless: true, ...(values.browser ? { executablePath: values.browser } : {}) });
  const errors = [];
  const results = [];
  try {
    for (const [label, width, height] of [['desktop', 1440, 1000], ['mobile', 390, 844]]) {
      const page = await browser.newPage({ viewport: { width, height }, reducedMotion: 'reduce' });
      page.on('pageerror', error => errors.push(error.message));
      await page.goto(values.base, { waitUntil: 'networkidle' });
      const panel = page.getByRole('region', { name: /More elements/ });
      const range = panel.getByRole('slider');
      const status = panel.locator('[role="status"]');
      await panel.scrollIntoViewIfNeeded();
      assert.match(await status.innerText(), /All 2 elements pass/);
      await range.focus();
      await range.press('End');
      await page.waitForFunction(() => document.querySelector('input[type="range"]').value === '5');
      assert.match(await status.innerText(), /Five elements exceed/);
      await range.press('Home');
      assert.match(await status.innerText(), /empty batch/);
      await range.press('ArrowRight'); await range.press('ArrowRight');
      const checkbox = panel.getByRole('checkbox');
      await checkbox.check();
      assert.match(await status.innerText(), /last element has an invalid/);
      await checkbox.uncheck();
      assert.match(await status.innerText(), /All 2 elements pass/);
      const size = await page.evaluate(() => ({ viewport: innerWidth, content: document.documentElement.scrollWidth }));
      assert(size.content <= size.viewport, `horizontal overflow at ${width}px: ${JSON.stringify(size)}`);
      // Keep the entire component in the capture viewport so the fixed site
      // navigation cannot obscure a stitched screenshot of a tall mobile card.
      if (label === 'mobile') await page.setViewportSize({ width, height: 1400 });
      await panel.scrollIntoViewIfNeeded();
      await panel.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
      await panel.screenshot({ path: path.join(values.out, `${label}.png`) });
      const link = panel.getByRole('link', { name: /Explore the batch contract/ });
      await link.click();
      await page.waitForURL('**/docs/borrowed-slices');
      await page.getByRole('heading', { name: 'Borrow bounded batches', exact: true }).waitFor();
      await page.waitForFunction(() => document.title.includes('Borrow bounded batches'));
      assert.match(await page.title(), /Borrow bounded batches/);
      results.push({ label, width, testHeight: height, screenshotHeight: label === 'mobile' ? 1400 : height, keyboardCountControl: true, malformedElementToggle: true, noHorizontalOverflow: true, docsNavigation: true, reducedMotion: true });
      await page.close();
    }
    assert.deepEqual(errors, []);
    const report = { allPassed: true, browser: browser.version(), results, pageErrors: errors };
    fs.writeFileSync(path.join(values.out, 'report.json'), JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify(report, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
