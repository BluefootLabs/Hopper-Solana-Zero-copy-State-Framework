/**
 * Static security headers applied to every response (including static
 * assets and the image optimizer). The per-request Content-Security-Policy
 * (which needs a fresh nonce) lives in `proxy.ts`; everything here
 * is request-independent, so it can be a flat header map that also covers
 * cacheable static responses.
 */
const securityHeaders = [
  // Force HTTPS for two years, including subdomains; eligible for the
  // browser preload list.
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload',
  },
  // Refuse MIME sniffing. A stylesheet/script is only run as what its
  // Content-Type says it is.
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  // Clickjacking defense for legacy UAs; modern ones use CSP
  // `frame-ancestors 'none'` (set in proxy).
  { key: 'X-Frame-Options', value: 'DENY' },
  // Send only the origin on cross-origin navigations; never the full path.
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  // Drop ambient access to powerful features the marketing site never uses.
  {
    key: 'Permissions-Policy',
    value:
      'camera=(), microphone=(), geolocation=(), browsing-topics=(), interest-cohort=(), payment=(), usb=(), fullscreen=(self)',
  },
  // Process isolation: no cross-origin window can grab a handle to ours,
  // and our resources are not embeddable cross-origin.
  { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
  { key: 'Cross-Origin-Resource-Policy', value: 'same-origin' },
  // Block the legacy Adobe cross-domain policy surface.
  { key: 'X-Permitted-Cross-Domain-Policies', value: 'none' },
  // Opt every browser out of DNS prefetching of third-party hostnames.
  { key: 'X-DNS-Prefetch-Control', value: 'off' },
];

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  compiler: {
    removeConsole: { exclude: ['error', 'warn'] },
  },
  experimental: {
    optimizePackageImports: ['lucide-react', 'framer-motion'],
  },
  async redirects() {
    return [
      { source: '/docs/from-anchor', destination: '/docs/program-migration', permanent: true },
      { source: '/docs/from-quasar', destination: '/docs/program-migration', permanent: true },
      { source: '/docs/hopper-vs-quasar', destination: '/docs/program-capabilities', permanent: true },
      { source: '/docs/quasar-port', destination: '/docs/bounded-multisig', permanent: true },
      { source: '/docs/dx-source-review', destination: '/docs/program-design', permanent: true },
    ];
  },
  async headers() {
    return [
      {
        source: '/:path*',
        headers: securityHeaders,
      },
    ];
  },
};

export default nextConfig;
