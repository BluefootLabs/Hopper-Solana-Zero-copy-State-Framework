import Link from 'next/link';

const CHECKS = [
  { title: 'The bytes must agree.', detail: 'Hash results and integer operations are compared with known vectors and independent arithmetic. A successful transaction alone is not a passing test.', input: '17 slices → SHA-256', expected: 'Exact digest bytes' },
  { title: 'A refusal must hold.', detail: 'Invalid lengths, missing authority, held borrows and out-of-bounds lenses must return the expected error. State tests also compare the whole account afterward.', input: 'An alias is still borrowed', expected: 'Write refused · state intact' },
  { title: 'The cluster decides.', detail: 'Compiled VM tests, live devnet execution and feature-account observations are distinct evidence. Each test names its build and scope; unsupported calls stay visible.', input: 'Exact deployed ELF', expected: 'Return bytes + account state' },
];

export function FunctionLab() {
  return (
    <div className="mt-10 rounded-2xl border border-aurora-cyan/20 bg-ink-950/60 p-5 sm:p-6">
      <p className="mono text-[10px] uppercase tracking-[0.18em] text-aurora-cyan">Inside the function lab</p>
      <h3 className="mt-2 font-display text-xl font-medium text-ink-50">Test what actually executes.</h3>
      <p className="mt-3 text-sm leading-relaxed text-ink-300">Small Solana programs put Hopper’s runtime boundaries under test. Open a check to see what counts as evidence.</p>
      <div className="mt-5 divide-y divide-white/10">
        {CHECKS.map(({ title, detail, input, expected }) => (
          <details key={title} className="group py-3">
            <summary className="cursor-pointer rounded-sm text-sm font-medium text-ink-100 transition-colors hover:text-aurora-cyan focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-aurora-cyan motion-reduce:transition-none">{title}</summary>
            <div className="pt-3">
              <div className="flex flex-wrap items-center gap-2 font-mono text-[11px] leading-relaxed">
                <span className="rounded border border-white/10 px-2 py-1 text-ink-200">{input}</span>
                <span aria-hidden="true" className="text-aurora-cyan">→</span>
                <span className="rounded border border-aurora-cyan/20 px-2 py-1 text-aurora-cyan">{expected}</span>
              </div>
              <p className="mt-3 text-xs leading-relaxed text-ink-300">{detail}</p>
            </div>
          </details>
        ))}
      </div>
      <Link href="/docs/function-lab" className="mt-3 inline-block text-sm text-aurora-cyan underline underline-offset-4">Explore the test program and its limits</Link>
    </div>
  );
}
