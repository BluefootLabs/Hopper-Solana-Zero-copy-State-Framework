import Link from 'next/link';
import { FrameworkEvidence } from '@/components/framework-evidence';
import { COUNTER, HELLO, MEASURED, fmt } from '@/lib/measurements';

const ROWS: { label: string; raw: string; framework: string }[] = [
  {
    label: 'Hello world, compute units',
    raw: fmt(HELLO.raw.cu),
    framework: fmt(HELLO.framework.cu),
  },
  {
    label: 'Hello world, program size',
    raw: `${fmt(HELLO.raw.bytes)} B`,
    framework: `${fmt(HELLO.framework.bytes)} B`,
  },
  {
    label: 'PDA counter, create',
    raw: fmt(COUNTER.raw.create),
    framework: fmt(COUNTER.framework.create),
  },
  {
    label: 'PDA counter, update',
    raw: fmt(COUNTER.raw.increment),
    framework: fmt(COUNTER.framework.increment),
  },
  {
    label: 'PDA counter, program size',
    raw: `${fmt(COUNTER.raw.bytes)} B`,
    framework: `${fmt(COUNTER.framework.bytes)} B`,
  },
];

export function Numbers() {
  return (
    <section id="numbers" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mb-10 max-w-4xl">
          <div className="mono mb-3 text-[11px] uppercase tracking-[0.2em] text-aurora-cyan">
            measured, with the source
          </div>
          <h2 className="font-display text-4xl font-medium tracking-[-0.02em] text-ink-50 md:text-5xl">
            Measure the programs your users run.
          </h2>
          <p className="mt-4 max-w-3xl text-[15px] leading-relaxed text-ink-300">
            Start with the whole action: token movement, account checks,
            refunds, and failure behavior. These dated fixtures show what was
            measured; your program needs its own budget and tests.
          </p>
        </div>

        <FrameworkEvidence />

        <div className="surface mb-6 overflow-hidden rounded-3xl">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-sm">
              <caption className="sr-only">Compute units and program sizes for the hello-world and PDA-counter programs</caption>
              <thead className="bg-white/[0.03] text-ink-300">
                <tr>
                  <th scope="col" className="px-6 py-3 font-medium">Program</th>
                  <th scope="col" className="px-6 py-3 text-right font-medium">Hopper raw</th>
                  <th scope="col" className="px-6 py-3 text-right font-medium text-aurora-cyan">Hopper framework</th>
                </tr>
              </thead>
              <tbody>
                {ROWS.map((row) => (
                  <tr key={row.label} className="border-t border-white/5 text-ink-200">
                    <th scope="row" className="px-6 py-3 font-medium">{row.label}</th>
                    <td className="px-6 py-3 text-right tabular-nums">{row.raw}</td>
                    <td className="px-6 py-3 text-right tabular-nums text-ink-50">{row.framework}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="space-y-2 border-t border-white/5 p-6 text-xs leading-relaxed text-ink-400 md:px-8">
            <p>
              The raw counter uses a 10-byte account and full PDA derivation
              on every update. The framework counter checks the
              signer, the owner, the layout, and the PDA before the handler runs;
              it checks the PDA with one hash from the bump stored in the
              account, and its account carries a 16-byte header (25 bytes).
            </p>
            <p>
              Hopper hello-world and counter fixtures,
              {MEASURED.date}, commit <span className="mono">{MEASURED.commit}</span>.
              Different account layouts and PDA validation paths affect these costs.{' '}
              <a href={MEASURED.source} className="text-aurora-cyan underline underline-offset-4">
                Reproduce it
              </a>
            </p>
            <p>
              Deployed fresh to devnet the same day, the Hopper programs were
              charged exactly these compute units, every account checked byte
              for byte.{' '}
              <a href={MEASURED.devnet} className="text-aurora-cyan underline underline-offset-4">
                The transactions
              </a>
            </p>
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-2">
          <Link href="/docs/benchmarks" className="surface rounded-2xl p-6 transition-colors hover:border-aurora-cyan/40">
            <h3 className="font-display text-xl font-medium text-ink-50">More measurements</h3>
            <p className="mt-3 text-sm leading-relaxed text-ink-300">
              Vault, treasury, multisig, and token programs, with their
              workloads, toolchains, and devnet transactions.
            </p>
          </Link>
          <Link href="/docs/release-status" className="surface rounded-2xl p-6 transition-colors hover:border-aurora-cyan/40">
            <h3 className="font-display text-xl font-medium text-ink-50">What each release proved</h3>
            <p className="mt-3 text-sm leading-relaxed text-ink-300">
              Published versions, what ran on devnet, and what is still open.
            </p>
          </Link>
        </div>
      </div>
    </section>
  );
}
