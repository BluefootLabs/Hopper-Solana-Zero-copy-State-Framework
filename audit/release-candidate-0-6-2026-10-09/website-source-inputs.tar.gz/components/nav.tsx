'use client';

import { Menu, X } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { CopyButton } from '@/components/copy-button';
import { HOPPER_ADD_COMMAND } from '@/lib/release';

const NAV_ITEMS = [
  { label: 'Why Hopper', href: '/#why' },
  { label: 'Code', href: '/#code' },
  { label: 'Numbers', href: '/#numbers' },
  { label: 'Migrate', href: '/#migrate' },
  { label: 'Docs', href: '/docs' },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuButton = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      onKeyDown={(event) => {
        if (event.key === 'Escape' && menuOpen) {
          setMenuOpen(false);
          menuButton.current?.focus();
        }
      }}
      className={`fixed top-0 z-50 w-full border-b transition-all duration-500 ${
        scrolled || menuOpen
          ? 'border-white/10 bg-ink-950/80 backdrop-blur-xl'
          : 'border-transparent bg-transparent'
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2.5">
          <HopperMark className="h-7 w-12" />
          <span className="font-display text-[15px] font-medium tracking-tight text-ink-50">
            hopper
          </span>
        </Link>

        <nav aria-label="Main navigation" className="hidden items-center gap-1 md:flex">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className="rounded-lg px-3 py-1.5 text-[13px] font-medium text-ink-300 transition-colors hover:bg-white/5 hover:text-ink-50"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <div className="hidden items-center gap-2 rounded-lg border border-white/10 bg-white/[0.02] py-1 pl-3 pr-1 text-[12px] font-medium text-ink-300 md:flex mono">
            <span className="text-aurora-cyan">$</span>
            <span className="hidden lg:inline">cargo add hopper-lang</span>
            <span className="lg:hidden">install</span>
            <CopyButton
              value={HOPPER_ADD_COMMAND}
              label="Copy full install command"
              className="h-7 w-7 border-transparent bg-transparent"
            />
          </div>
          <Link
            href="/#get-started"
            className="group inline-flex items-center gap-1.5 rounded-lg bg-ink-50 px-3.5 py-1.5 text-[13px] font-medium text-ink-950 transition-transform hover:scale-[1.02]"
          >
            Get started
            <svg
              width="12"
              height="12"
              viewBox="0 0 12 12"
              fill="none"
              className="transition-transform group-hover:translate-x-0.5"
            >
              <path
                d="M4 2l4 4-4 4"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </Link>
          <button ref={menuButton} type="button" aria-expanded={menuOpen} aria-controls="mobile-navigation" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} onClick={() => setMenuOpen(!menuOpen)} className="flex h-11 w-11 items-center justify-center rounded-lg border border-white/15 text-ink-100 md:hidden">
            {menuOpen ? <X size={20} aria-hidden /> : <Menu size={20} aria-hidden />}
          </button>
        </div>
      </div>
      <nav id="mobile-navigation" aria-label="Mobile navigation" hidden={!menuOpen} className="border-t border-white/10 bg-ink-950 px-6 py-3 md:hidden">
        {NAV_ITEMS.map((item) => (
          <Link key={item.href} href={item.href} onClick={() => setMenuOpen(false)} className="block rounded-lg px-3 py-3 text-sm text-ink-200 hover:bg-white/5">{item.label}</Link>
        ))}
      </nav>
    </header>
  );
}

export function HopperMark({ className }: { className?: string }) {
  return (
    <Image
      src="/hopper_logo_new.png"
      alt=""
      width={970}
      height={448}
      className={className}
      aria-hidden="true"
      sizes="48px"
    />
  );
}
