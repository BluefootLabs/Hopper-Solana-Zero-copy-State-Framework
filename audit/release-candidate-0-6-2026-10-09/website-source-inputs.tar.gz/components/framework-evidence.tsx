import Link from 'next/link';

const EVIDENCE =
  'https://github.com/BluefootLabs/Hopper-Solana-Zero-copy-State-Framework/tree/main/audit/devnet-evidence-2026-09-30/escrow-round12';

const OPERATIONS = [
  ['Create and fund an offer', '6,868 / 6,213'],
  ['Take the offer, refund the surplus, close the accounts', '7,836'],
  ['Cancel, refund the tokens, close the accounts', '3,586'],
];

export function FrameworkEvidence() {
  return (
    <div className="surface mb-10 overflow-hidden rounded-3xl border-aurora-cyan/20">
      <div className="p-6 md:p-8">
        <p className="mono text-[11px] uppercase tracking-[0.16em] text-aurora-cyan">Token escrow | Devnet, September 30, 2026</p>
        <h3 className="mt-3 font-display text-2xl font-medium text-ink-50">A real program, run on a real cluster.</h3>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-ink-300">
          Deposit, trade, refund, and cancel against the real SPL Token program:
          33 finalized transactions, the refusals the program is supposed to
          make among them. Every one left exactly the account state it should
          have, and the deployed program matched the tested one byte for byte.
        </p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[460px] text-left text-sm">
          <caption className="sr-only">Classic SPL Token escrow compute units on devnet</caption>
          <thead className="bg-white/[0.03] text-ink-300"><tr>
            <th scope="col" className="px-6 py-3 font-medium">On-chain action</th>
            <th scope="col" className="px-6 py-3 text-right font-medium">Compute units</th>
          </tr></thead>
          <tbody>{OPERATIONS.map(([operation, cu]) => (
            <tr key={operation} className="border-t border-white/5 text-ink-200">
              <th scope="row" className="px-6 py-3 font-medium">{operation}</th>
              <td className="px-6 py-3 text-right tabular-nums">{cu}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      <div className="p-6 text-xs leading-relaxed text-ink-400 md:px-8">
        <p>
          The escrow example at commit <span className="mono">847a0b0</span>, with
          real classic SPL Token transfers.{' '}
          <a href={EVIDENCE} className="text-aurora-cyan underline underline-offset-4">
            The transactions and checks
          </a>
          {' · '}
          <Link href="/docs/token-escrow" className="text-aurora-cyan underline underline-offset-4">
            The program
          </Link>
        </p>
      </div>
    </div>
  );
}
