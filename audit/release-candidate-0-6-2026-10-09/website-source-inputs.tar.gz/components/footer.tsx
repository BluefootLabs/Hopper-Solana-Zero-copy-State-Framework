import Link from 'next/link';
import { PUBLISHED_VERSION } from '@/lib/release';
import { HopperMark } from './nav';

const SITE = 'https://hopperzero.dev';
const REPO = 'https://github.com/BluefootLabs/Hopper-Solana-Zero-copy-State-Framework';
const DOCS = `${SITE}/docs`;
const DONATION_ADDRESS = 'F42ZovBoRJZU4av5MiESVwJWnEx8ZQVFkc1RM29zMxNT';
const DONATION_URI = `solana:${DONATION_ADDRESS}?label=solanadevdao.sol`;

const GROUPS = [
  {
    title: 'Framework',
    links: [
      { label: 'Website', href: SITE },
      { label: 'GitHub', href: REPO },
      { label: 'Docs', href: DOCS },
      { label: 'Benchmarks', href: `${DOCS}/benchmarks` },
      { label: 'Release status', href: `${DOCS}/release-status` },
    ],
  },
  {
    title: 'Guides',
    links: [
      { label: 'Getting started', href: DOCS },
      { label: 'Write lower-level programs', href: '/docs/from-pinocchio' },
      { label: 'Moving a program to Hopper', href: '/docs/program-migration' },
      { label: 'Crypto capabilities', href: `${DOCS}/crypto-capabilities` },
      { label: 'Tail lab', href: `${DOCS}#tail-lab` },
      { label: 'Collections and resizing', href: `${DOCS}/collections-resizing` },
      { label: 'Client generation', href: `${DOCS}#client-generation` },
      { label: 'Effect verification', href: `${DOCS}/effect-verification` },
      { label: 'CLI reference', href: `${DOCS}#cli` },
    ],
  },
  {
    title: 'Source',
    links: [
      { label: 'X', href: 'https://x.com/BluefootLabs' },
      { label: 'Examples', href: `${DOCS}/protocol-examples` },
      { label: 'Architecture', href: `${DOCS}/architecture` },
      { label: 'Security', href: `${REPO}/security` },
    ],
  },
];

export function Footer() {
  return (
    <footer className="relative border-t border-white/5 py-16">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-4">
          <div className="col-span-2 flex flex-col gap-4 md:col-span-1">
            <Link href={SITE} className="flex items-center gap-2.5">
              <HopperMark className="h-7 w-12" />
              <span className="font-display text-[15px] font-medium tracking-tight text-ink-50">
                hopper
              </span>
            </Link>
            <p className="max-w-xs text-[13px] leading-relaxed text-ink-400">
              Hopper {PUBLISHED_VERSION} is published on crates.io. Checked
              zero-copy state and explicit mutation contracts for Solana programs.
            </p>
            <p className="max-w-xs text-[12px] leading-relaxed text-ink-500">
              Support public-goods work:{' '}
              <a href={DONATION_URI} className="text-aurora-cyan hover:text-ink-50">
                solanadevdao.sol
              </a>{' '}
              <span className="break-all text-ink-400">{DONATION_ADDRESS}</span>
            </p>
            <div className="mono pt-1 text-[11px] uppercase tracking-wide text-ink-500">
              Source toolchain: Rust 1.96 / SBF / no_std
            </div>
          </div>
          {GROUPS.map((g) => (
            <div key={g.title}>
              <div className="mono mb-4 text-[10.5px] uppercase tracking-[0.2em] text-ink-500">
                {g.title}
              </div>
              <ul className="flex flex-col gap-2">
                {g.links.map((l) => (
                  <li key={l.label}>
                    <Link
                      href={l.href}
                      className="text-[13px] text-ink-300 transition-colors hover:text-ink-50"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-start justify-between gap-4 border-t border-white/5 pt-6 md:flex-row md:items-center">
          <div className="mono text-[11.5px] text-ink-500">
            Copyright 2026 Bluefoot Labs.
          </div>
          <div className="mono text-[11.5px] text-ink-500">
            fingerprint: <span className="text-ink-300">7f3a b102 c4e8 9210</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
