import Link from 'next/link';
import { ArrowDown, ArrowUpRight } from 'lucide-react';
import { CopyButton } from '@/components/copy-button';
import { ProgramFlow } from '@/components/program-flow';
import { COUNTER, HELLO, MEASURED, fmt } from '@/lib/measurements';
import { HOPPER_ADD_COMMAND, PUBLISHED_VERSION } from '@/lib/release';

export function Hero() {
  return (
    <section className="hero-shell relative overflow-hidden pb-12 pt-28 md:pt-40">
      <div className="hero-contours pointer-events-none absolute inset-0" aria-hidden />
      <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid items-center gap-14 lg:grid-cols-[1.05fr_1fr] lg:gap-12">
          <div className="hero-enter">
            <Link href="/docs/release-status" className="group inline-flex items-center gap-3 rounded-full border border-white/15 px-3 py-2 text-xs text-ink-200 transition-colors hover:border-aurora-lime/50">
              <span className="h-1.5 w-1.5 rounded-full bg-aurora-lime" aria-hidden />
              Hopper {PUBLISHED_VERSION} is on crates.io
              <ArrowUpRight size={13} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden />
            </Link>
            <p className="mono mb-5 mt-9 text-[11px] uppercase tracking-[0.24em] text-aurora-cyan">A Rust framework for Solana</p>
            <h1 className="font-display text-[clamp(3rem,5.6vw,5.3rem)] font-medium leading-[0.97] tracking-[-0.065em] text-ink-50">
              Your program.<br />Your rules.<br /><span className="text-aurora-lime">Direct to state.</span>
            </h1>
            <p className="mt-7 max-w-lg text-base leading-relaxed text-ink-200 md:text-lg">
              Borrow account state. Declare the checks around it. Build in Rust
              with typed handlers, or take direct control through Hopper’s native
              runtime. Your program runs on Solana.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="#get-started" className="group inline-flex items-center gap-6 rounded-xl bg-aurora-lime px-5 py-3.5 text-sm font-semibold text-ink-950 transition-colors hover:bg-[#d5ff71]">
                Start building <ArrowUpRight size={18} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden />
              </Link>
              <Link href="/docs" className="inline-flex items-center gap-2 rounded-xl border border-white/20 px-5 py-3.5 text-sm font-medium text-ink-100 transition-colors hover:bg-white/5">Explore the docs</Link>
            </div>
            <div className="mt-5 flex max-w-lg items-center gap-3 rounded-lg border border-white/10 bg-black/20 py-2 pl-4 pr-2">
              <span className="mono text-xs text-aurora-cyan" aria-hidden>$</span>
              <code className="min-w-0 flex-1 break-all text-xs leading-relaxed text-ink-200">{HOPPER_ADD_COMMAND}</code>
              <CopyButton value={HOPPER_ADD_COMMAND} label="Copy dependency command" />
            </div>
          </div>
          <ProgramFlow />
        </div>
        <div className="mt-16 grid gap-6 border-y border-white/10 py-7 sm:grid-cols-3 lg:mt-24">
          {[
            { value: `${fmt(HELLO.raw.cu)} CU`, label: 'Raw hello-world fixture' },
            { value: `${fmt(COUNTER.framework.increment)} CU`, label: 'Framework counter update' },
            { value: 'On-chain evidence', label: 'Public signatures. Recorded program hashes.' },
          ].map((stat) => (
            <div key={stat.label} className="sm:border-l sm:border-white/10 sm:pl-6 first:sm:border-0 first:sm:pl-0">
              <div className="font-display text-2xl tracking-tight text-ink-50">{stat.value}</div>
              <p className="mt-1 text-xs text-ink-300">{stat.label}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-4 text-xs leading-relaxed text-ink-300">
          <p>Fixture measurements: {MEASURED.date}, commit <code>{MEASURED.commit}</code>. <Link href="#numbers" className="underline underline-offset-4 hover:text-ink-50">Method and limits</Link></p>
          <Link href="#why" className="inline-flex items-center gap-2 text-ink-200">Explore the architecture <ArrowDown size={13} aria-hidden /></Link>
        </div>
      </div>
    </section>
  );
}
