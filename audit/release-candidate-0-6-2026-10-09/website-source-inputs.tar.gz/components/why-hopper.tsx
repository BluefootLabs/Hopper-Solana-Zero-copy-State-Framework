'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowUpRight, Binary, Layers3, ScanLine, ShieldCheck } from 'lucide-react';

const ICONS = [Binary, ShieldCheck, Layers3, ScanLine];

type Reason = {
  eyebrow: string;
  title: string;
  body: string;
  href: string;
  link: string;
};

const REASONS: Reason[] = [
  {
    eyebrow: 'borrowed account state',
    title: 'Work directly with account state.',
    body: 'Supported layouts borrow account bytes directly, so updating a field does not require deserializing the whole account. Application code and other data formats can still allocate or copy.',
    href: '/docs/memory-access',
    link: 'How accounts are read',
  },
  {
    eyebrow: 'explicit account contracts',
    title: 'Declare what an instruction accepts.',
    body: 'Typed accounts check their owner and layout. Declare signer, writable, authority, and PDA constraints alongside them. Checked borrows and CPI reject incompatible live references. Your handler defines the application rules.',
    href: '/docs/model',
    link: 'The Hopper model',
  },
  {
    eyebrow: 'one framework, top to bottom',
    title: 'Start high. Drop low where it counts.',
    body: 'Use #[program] and #[derive(Accounts)] for application handlers. Reach for runtime account views, CPI, and syscalls when you need direct control. The facade exposes both layers; lower-level code takes on the validation it bypasses.',
    href: '/docs/layers',
    link: 'The layers',
  },
  {
    eyebrow: 'inspectable behavior',
    title: 'Constrain writes. Inspect the result.',
    body: 'Optional write policies constrain tracked mutations and CPI delegation. Manifests describe declared layouts and effects; self-audit tooling checks APIs, unsafe-code coverage, and dated validation evidence. Independent review remains open.',
    href: '/docs/self-audit',
    link: 'The self-audit',
  },
];

export function WhyHopper() {
  return (
    <section id="why" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mb-14 max-w-3xl">
          <div className="mono mb-3 text-[11px] uppercase tracking-[0.2em] text-aurora-cyan">
            why hopper
          </div>
          <h2 className="font-display text-4xl font-medium tracking-[-0.02em] text-ink-50 md:text-5xl">
            Keep control as your program grows.
          </h2>
          <p className="mt-4 text-[15px] leading-relaxed text-ink-300">
            Describe your accounts and actions in Rust. Add the validation your
            application needs, then use lower-level APIs where measurement
            shows they help. The execution stays on Solana.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {REASONS.map((r, i) => {
            const Icon = ICONS[i];
            return (
              <motion.div
                key={r.title}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ delay: i * 0.06, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="surface group relative overflow-hidden rounded-3xl p-7 transition-colors hover:border-aurora-cyan/30 md:p-9"
              >
                <div className="mb-8 flex items-center justify-between">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-aurora-cyan/25 bg-aurora-cyan/[0.06] text-aurora-cyan"><Icon size={21} strokeWidth={1.5} aria-hidden /></span>
                  <span className="mono text-xs text-ink-400">0{i + 1}</span>
                </div>
                <div className="mb-4 mono text-[10px] uppercase tracking-[0.18em] text-ink-300">
                  {r.eyebrow}
                </div>
                <h3 className="font-display text-2xl font-medium tracking-[-0.01em] text-ink-50 md:text-[28px]">
                  {r.title}
                </h3>
                <p className="mt-3 text-[14.5px] leading-relaxed text-ink-300">{r.body}</p>
                <Link href={r.href} className="mt-6 inline-flex items-center gap-3 text-xs text-aurora-cyan underline underline-offset-4">
                  {r.link}<ArrowUpRight size={14} aria-hidden />
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
