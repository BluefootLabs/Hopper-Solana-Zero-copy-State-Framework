'use client';

import { useId, useState } from 'react';
import { ArrowUpRight, Braces, Check, Database } from 'lucide-react';
import examples from '@/content/program-examples.json';

const STEPS = [
  { id: 'account', label: 'State', icon: Database, detail: 'Account bytes become a typed view. WireU64 gives the counter a fixed, alignment-safe representation.' },
  { id: 'ctx', label: 'Accounts', icon: Check, detail: 'Require a writable counter owned by this program, the expected layout, and a signer matching its stored authority.' },
  { id: 'program', label: 'Handler', icon: Braces, detail: 'Borrow the counter mutably and increment it with overflow checking. Compile this Rust program to Solana SBF.' },
] as const;

export function ProgramFlow() {
  const [active, setActive] = useState(0);
  const id = useId();
  const step = STEPS[active];
  const example = examples.find((item) => item.id === step.id)!;

  return (
    <div className="hero-enter min-w-0 overflow-hidden rounded-3xl border border-white/15 bg-[#0b1317] shadow-[0_30px_100px_-40px_#000]">
      <div className="flex items-center justify-between gap-3 border-b border-white/10 px-5 py-4 sm:px-6">
        <span className="mono text-[11px] uppercase tracking-[0.16em] text-ink-200">One Rust program</span>
        <span className="rounded-full border border-aurora-cyan/30 px-2.5 py-1 text-[10px] text-aurora-cyan">Source walkthrough</span>
      </div>
      <fieldset className="px-5 pt-5 sm:px-6">
        <legend className="sr-only">Explore the counter program</legend>
        <div className="grid grid-cols-3 gap-2">
          {STEPS.map((item, index) => {
            const Icon = item.icon;
            return (
              <label key={item.id} className="relative cursor-pointer">
                <input type="radio" name={`${id}-step`} checked={active === index} onChange={() => setActive(index)} aria-controls={`${id}-source`} className="peer sr-only" />
                <span className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-white/10 px-2 text-xs text-ink-300 transition-colors peer-checked:border-aurora-lime/40 peer-checked:bg-aurora-lime/[0.06] peer-checked:text-aurora-lime peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-aurora-cyan hover:border-white/25">
                  <Icon size={14} aria-hidden />{item.label}
                </span>
              </label>
            );
          })}
        </div>
      </fieldset>
      <div id={`${id}-source`} className="px-5 pb-5 pt-4 sm:px-6">
        <div className="mb-3 flex items-center gap-2 mono text-[10px] text-ink-300"><span className="h-1.5 w-1.5 rounded-full bg-aurora-cyan" aria-hidden />counter / lib.rs</div>
        <pre tabIndex={0} aria-label={`${step.label} Rust source`} className="min-h-[252px] overflow-x-auto rounded-xl border border-white/5 bg-black/20 p-4 text-[11px] leading-5 text-ink-100 sm:text-xs"><code>{example.code}</code></pre>
        <p role="status" aria-live="polite" aria-atomic="true" className="mt-4 min-h-[66px] text-xs leading-relaxed text-ink-200">{step.detail}</p>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-4 text-xs">
          <span className="text-ink-300">Excerpt · requires initialized state</span>
          <a href={`https://github.com/BluefootLabs/Hopper-Solana-Zero-copy-State-Framework/blob/main/${example.filename}#L${example.sourceLine}`} className="inline-flex items-center gap-1 text-aurora-cyan underline underline-offset-4">Read the source<ArrowUpRight size={13} aria-hidden /></a>
        </div>
      </div>
    </div>
  );
}
