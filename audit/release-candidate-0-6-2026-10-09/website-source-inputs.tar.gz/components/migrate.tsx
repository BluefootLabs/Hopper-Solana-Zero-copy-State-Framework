import Link from 'next/link';

const PATHS = [
  {
    from: 'Application handlers', title: 'Start with typed accounts.',
    body: 'Describe account layouts, declare validation, and write the action your users need. Token and System Program builders carry out transfers; your code defines who may request them.',
    pairs: [['Account validation', '#[derive(Accounts)]'], ['Program actions', '#[program]'], ['Token movement', 'TransferChecked']],
    href: '/docs/start', link: 'Build a program',
  },
  {
    from: 'Lower-level code', title: 'Control the hot path.',
    body: 'Use account views, explicit borrow checks, CPI, and syscalls directly. Review existing layouts and authority rules when porting a program, then measure its complete workload.',
    pairs: [['Account memory', 'AccountView'], ['Signed CPI', 'invoke_signed'], ['Program addresses', 'pda helpers']],
    href: '/docs/from-pinocchio', link: 'Write a lower-level handler',
  },
];

export function Migrate() {
  return (
    <section id="migrate" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mb-10 max-w-3xl">
          <div className="mono mb-3 text-[11px] uppercase tracking-[0.2em] text-aurora-cyan">
            bring the program you have
          </div>
          <h2 className="font-display text-4xl font-medium tracking-[-0.02em] text-ink-50 md:text-5xl">
            Build at the level your program needs.
          </h2>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {PATHS.map((path) => (
            <div key={path.from} className="surface flex flex-col rounded-3xl p-7">
              <div className="mono text-[11px] uppercase tracking-[0.2em] text-ink-400">{path.from}</div>
              <h3 className="mt-3 font-display text-2xl font-medium text-ink-50 md:text-[28px]">{path.title}</h3>
              <p className="mt-3 text-[14.5px] leading-relaxed text-ink-300">{path.body}</p>
              <div className="mt-5 space-y-2 rounded-2xl border border-white/5 bg-ink-900/50 p-4">
                {path.pairs.map(([before, after]) => (
                  <div key={before} className="grid grid-cols-1 gap-1 mono text-[12px] sm:grid-cols-[1fr_auto_1fr] sm:items-center sm:gap-3">
                    <span className="break-all text-ink-400">{before}</span>
                    <span className="hidden text-aurora-cyan sm:inline" aria-hidden>→</span>
                    <span className="break-all text-ink-100">{after}</span>
                  </div>
                ))}
              </div>
              <Link href={path.href} className="mt-5 inline-block text-[13px] text-aurora-cyan underline underline-offset-4">
                {path.link}
              </Link>
            </div>
          ))}
        </div>
        <p className="mt-7 max-w-3xl text-sm leading-relaxed text-ink-300">
          Coming from Pinocchio, Pina, Quasar, or Anchor? Compare account layouts,
          validation boundaries, and integration work in the{' '}
          <Link href="/docs/framework-boundaries" className="text-aurora-cyan underline underline-offset-4">source comparison</Link>.
          {' '}Performance depends on the complete instruction and its checks.
        </p>
      </div>
    </section>
  );
}
