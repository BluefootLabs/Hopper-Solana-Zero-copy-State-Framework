import Link from 'next/link';
import { ArrowUpRight, ArrowLeftRight, Gift, Landmark, Shapes } from 'lucide-react';

const ICONS = [ArrowLeftRight, Gift, Shapes, Landmark];

const CASES = [
  {
    title: 'Token escrow',
    body: 'A working classic-token example: fund a vault, exchange the agreed tokens, cancel an offer, and refund surplus deposits.',
    href: '/docs/use-cases#trading-and-settlement',
    label: 'Working example',
  },
  {
    title: 'Token claims and rewards',
    body: 'Token CPI, receipt checks, and vesting and distribution math. Add funded custody, eligibility, and replay protection to build your claim program.',
    href: '/docs/use-cases#token-claims-and-airdrops',
    label: 'Claim building blocks',
  },
  {
    title: 'Asset integrations',
    body: 'Token Metadata creation and update helpers. Marketplace settlement, programmable-NFT transfers, and Bubblegum integration require additional application code.',
    href: '/docs/use-cases#nft-and-cnft-markets',
    label: 'Plan an integration',
  },
  {
    title: 'SOL treasuries',
    body: 'Working multisig and delegated-spending examples with real SOL transfers, member approvals, budgets, and cooldowns.',
    href: '/docs/governance',
    label: 'Working examples',
  },
];

export function UseCases() {
  return (
    <section id="use-cases" className="relative py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="max-w-3xl">
          <div className="mono mb-3 text-[11px] uppercase tracking-[0.2em] text-aurora-cyan">examples and building blocks</div>
          <h2 className="font-display text-4xl font-medium tracking-[-0.02em] text-ink-50 md:text-5xl">What will you build?</h2>
          <p className="mt-4 text-[15px] leading-relaxed text-ink-300">
            Start with a working program or a focused building block, then add
            the rules your application needs.
          </p>
        </div>
        <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {CASES.map((item, index) => {
            const Icon = ICONS[index];
            return (
              <Link key={item.title} href={item.href} className="surface group flex flex-col rounded-2xl p-6 transition-colors hover:border-aurora-lime/40">
                <div className="mb-9 flex items-center justify-between text-aurora-lime"><Icon size={25} strokeWidth={1.5} aria-hidden /><ArrowUpRight size={17} className="text-ink-300 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden /></div>
                <h3 className="font-display text-2xl text-ink-50">{item.title}</h3>
                <p className="mt-3 text-[14px] leading-relaxed text-ink-300">{item.body}</p>
                <span className="mt-auto block pt-6 text-xs text-aurora-cyan">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
