'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { CopyButton } from '@/components/copy-button';
import {
  HOPPER_CLI_INSTALL_COMMAND,
  PUBLISHED_VERSION,
  REGISTRY_OBSERVED_DATE,
  WORKSPACE_VERSION,
} from '@/lib/release';

const DONATION_ADDRESS = 'F42ZovBoRJZU4av5MiESVwJWnEx8ZQVFkc1RM29zMxNT';
const DONATION_URI = `solana:${DONATION_ADDRESS}?label=solanadevdao.sol`;

const STABLE_STEPS = [
  {
    step: '01',
    cmd: HOPPER_CLI_INSTALL_COMMAND,
    note: 'install the published CLI',
  },
  {
    step: '02',
    cmd: 'hopper init my-program --template minimal --yes',
    note: 'create a new program',
  },
  {
    step: '03',
    cmd: 'cd my-program && hopper build',
    note: 'build with your installed Solana SBF toolchain',
  },
];

export function Install() {
  return (
    <section id="get-started" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-5xl px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="surface relative overflow-hidden rounded-3xl p-10 md:p-14"
        >
          <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-aurora-violet/15 blur-3xl" aria-hidden />
          <div className="pointer-events-none absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-aurora-cyan/10 blur-3xl" aria-hidden />

          <div className="relative">
            <div className="mono mb-3 text-[11px] uppercase tracking-[0.2em] text-aurora-cyan">
              get started with the published release
            </div>
            <h2 className="font-display text-4xl font-medium tracking-[-0.02em] text-ink-50 md:text-5xl">
              Build with Hopper {PUBLISHED_VERSION}.
            </h2>
            <p className="mt-4 max-w-3xl text-[15px] leading-relaxed text-ink-300">
              Install the CLI, create a project, and build your first program.
              You will need Rust and the Solana SBF build tools; the getting-started
              guide covers setup. Version {PUBLISHED_VERSION} was verified on
              crates.io on {REGISTRY_OBSERVED_DATE}.
            </p>

            <div className="mt-8 grid grid-cols-1 gap-3 md:grid-cols-3">
              {STABLE_STEPS.map((item) => (
                <div key={item.step} className="rounded-2xl border border-white/5 bg-ink-900/60 p-5">
                  <div className="mono text-[11px] text-ink-400">{item.step}</div>
                  <div className="mt-2 flex min-w-0 items-start gap-2">
                    <div className="min-w-0 flex-1 break-all mono text-[13px] text-ink-50">
                      <span className="text-aurora-cyan">$</span> {item.cmd}
                    </div>
                    <CopyButton value={item.cmd} label={`Copy step ${item.step} command`} className="mt-0.5" />
                  </div>
                  <div className="mt-2 text-[12px] text-ink-400">{item.note}</div>
                </div>
              ))}
            </div>

            <div className="mt-5 rounded-2xl border border-aurora-violet/20 bg-aurora-violet/[0.05] p-5">
              <div className="mono text-[10.5px] uppercase tracking-[0.18em] text-aurora-violet">
                Develop against the {WORKSPACE_VERSION} source
              </div>
              <p className="mt-2 text-[13px] leading-relaxed text-ink-300">
                Clone a reviewed revision, use a path dependency for `hopper-lang`, and install the CLI with `cargo install --path tools/hopper-cli`. Pin the exact Git revision in team and CI environments.
              </p>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link href="/docs" className="inline-flex items-center gap-2 rounded-xl bg-ink-50 px-5 py-3 text-[14px] font-medium text-ink-950 transition-transform hover:scale-[1.02]">
                Read the docs
              </Link>
              <Link href="/docs/protocol-examples" className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-5 py-3 text-[14px] font-medium text-ink-100 transition-colors hover:border-white/20 hover:bg-white/[0.06]">
                See example programs
              </Link>
              <Link href="/docs/release-status" className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-5 py-3 text-[14px] font-medium text-ink-100 transition-colors hover:border-white/20 hover:bg-white/[0.06]">
                Release and audit status
              </Link>
              <a href={DONATION_URI} className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-5 py-3 text-[14px] font-medium text-ink-100 transition-colors hover:border-white/20 hover:bg-white/[0.06]">
                Support solanadevdao.sol
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
