'use client';

import { Check, Copy } from 'lucide-react';
import { useEffect, useState } from 'react';
import { clsx } from 'clsx';

type CopyState = 'idle' | 'copied' | 'failed';

type CopyButtonProps = {
  value: string;
  label: string;
  className?: string;
  showText?: boolean;
};

async function writeClipboard(value: string) {
  if (navigator.clipboard && window.isSecureContext) {
    await navigator.clipboard.writeText(value);
    return;
  }

  const textarea = document.createElement('textarea');
  const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  textarea.value = value;
  textarea.setAttribute('readonly', '');
  textarea.style.position = 'fixed';
  textarea.style.left = '-9999px';
  textarea.style.top = '0';
  document.body.appendChild(textarea);
  textarea.focus();
  textarea.select();
  let copied = false;
  try {
    copied = document.execCommand('copy');
  } finally {
    textarea.remove();
    previousFocus?.focus({ preventScroll: true });
  }

  if (!copied) {
    throw new Error('copy failed');
  }
}

export function CopyButton({ value, label, className, showText = false }: CopyButtonProps) {
  const [state, setState] = useState<CopyState>('idle');

  useEffect(() => {
    if (state === 'idle') return;
    const timeout = window.setTimeout(() => setState('idle'), 1600);
    return () => window.clearTimeout(timeout);
  }, [state]);

  const Icon = state === 'copied' ? Check : Copy;
  const text = state === 'copied' ? 'copied' : state === 'failed' ? 'failed' : 'copy';

  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await writeClipboard(value);
          setState('copied');
        } catch {
          setState('failed');
        }
      }}
      aria-label={label}
      title={label}
      className={clsx(
        'inline-flex shrink-0 items-center justify-center rounded-md border border-white/10 bg-white/[0.04] text-ink-300 transition-colors hover:bg-white/10 hover:text-ink-50',
        showText ? 'gap-2 px-3 py-1.5 text-[12px]' : 'h-8 w-8',
        state === 'copied' && 'border-aurora-lime/30 text-aurora-lime',
        state === 'failed' && 'border-red-400/30 text-red-300',
        className,
      )}
    >
      <Icon className="h-3.5 w-3.5" aria-hidden />
      {showText && <span className="mono hidden sm:inline">{text}</span>}
      <span className="sr-only" role="status" aria-live="polite">{state === 'copied' ? 'Copied to clipboard' : state === 'failed' ? 'Copy failed. Select and copy the command manually.' : ''}</span>
    </button>
  );
}
