'use client';

import { useId, useState } from 'react';
import Link from 'next/link';
import examples from '@/content/program-examples.json';

const PATHS = [
  { id: 'borrowed-generated', label: 'Generated handler' },
  { id: 'borrowed-manual', label: 'Manual entrypoint' },
] as const;

export function DispatchExample() {
  const [active, setActive] = useState(0);
  const id = useId();
  const example = examples.find((item) => item.id === PATHS[active].id)!;

  return (
    <div className="mt-7 min-w-0 overflow-hidden rounded-2xl border border-white/15 bg-[#0b1317]">
      <fieldset className="border-b border-white/10 p-3">
        <legend className="sr-only">Choose the borrowed argument entry path</legend>
        <div className="grid grid-cols-2 gap-2">
          {PATHS.map((path, index) => (
            <label key={path.id} className="cursor-pointer">
              <input type="radio" name={`${id}-path`} checked={active === index} onChange={() => setActive(index)} aria-controls={`${id}-code`} className="peer sr-only" />
              <span className="flex min-h-11 items-center justify-center rounded-lg border border-transparent px-2 text-xs text-ink-300 transition-colors hover:text-ink-50 peer-checked:border-aurora-lime/30 peer-checked:bg-aurora-lime/[0.06] peer-checked:text-aurora-lime peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-aurora-cyan">{path.label}</span>
            </label>
          ))}
        </div>
      </fieldset>
      <pre id={`${id}-code`} tabIndex={0} aria-label={`${PATHS[active].label} Rust source`} className="min-h-[272px] overflow-x-auto p-5 text-[11px] leading-5 text-ink-100"><code>{example.code}</code></pre>
      <div className="border-t border-white/10 px-5 py-4">
        <p role="status" aria-live="polite" aria-atomic="true" className="min-h-10 text-xs leading-relaxed text-ink-300">{example.caption}</p>
        <Link href="/docs/borrowed-arguments" className="mt-3 inline-block text-xs text-aurora-cyan underline underline-offset-4">Explore the wire contract and fixture</Link>
      </div>
    </div>
  );
}
