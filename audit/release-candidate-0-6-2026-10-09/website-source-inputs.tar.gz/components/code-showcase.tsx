'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { clsx } from 'clsx';
import { CopyButton } from '@/components/copy-button';

import examples from '@/content/program-examples.json';

const TABS = examples.filter((example) => example.status === 'published');

export function CodeShowcase() {
  const [active, setActive] = useState(TABS[0].id);
  const current = TABS.find((t) => t.id === active) ?? TABS[0];

  return (
    <section id="code" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mb-10 flex items-end justify-between gap-8">
          <div className="max-w-2xl">
            <div className="mono mb-3 text-[11px] uppercase tracking-[0.2em] text-aurora-cyan">
              the code
            </div>
            <h2 className="font-display text-4xl font-medium tracking-[-0.02em] text-ink-50 md:text-5xl">
              Start with a program you can read.
            </h2>
            <p className="mt-4 text-[15px] leading-relaxed text-ink-300">
              These excerpts come from the linked Rust sources. Declare state, list accounts, and write a handler. Hopper
              generates the checks and the dispatch around your Rust code, and
              lower-level APIs are available when an instruction needs explicit control.
            </p>
          </div>
        </div>

        <div className="surface relative overflow-hidden rounded-3xl">
          <div className="flex flex-wrap items-center gap-1 border-b border-white/5 bg-white/[0.02] px-3 py-2">
            {TABS.map((t) => (
              <button
                type="button"
                key={t.id}
                onClick={() => setActive(t.id)}
                aria-pressed={active === t.id}
                aria-controls="program-example"
                className={clsx(
                  'group relative min-h-11 rounded-lg px-3 py-2 text-[12.5px] font-medium transition-colors mono',
                  active === t.id
                    ? 'text-ink-50'
                    : 'text-ink-300 hover:text-ink-100',
                )}
              >
                {active === t.id && (
                  <motion.div
                    layoutId="tab-bg"
                    className="absolute inset-0 rounded-lg bg-white/[0.06]"
                    transition={{ type: 'spring', bounce: 0.15, duration: 0.5 }}
                  />
                )}
                <span className="relative">{t.label}</span>
              </button>
            ))}
            <div className="ml-auto flex min-w-0 items-center gap-2 pr-1 sm:pr-2">
              <span className="hidden min-w-0 truncate mono text-[11px] text-ink-400 sm:block">
                {current.filename}
              </span>
              <CopyButton value={current.code} label={`Copy ${current.label} code`} />
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={current.id}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.25 }}
              id="program-example"
              className="relative"
            >
              <div className="pointer-events-none absolute inset-x-0 top-0 h-px hairline" />
              <pre tabIndex={0} aria-label={`${current.label} Rust source`} className="mono overflow-x-auto p-6 text-[13px] leading-[1.7] text-ink-200 md:p-8 md:text-[14px]">
                <Highlighted code={current.code} />
              </pre>
              <div className="border-t border-white/5 bg-white/[0.02] px-6 py-3 text-[12px] text-ink-300 md:px-8">
                {current.caption}
                <a href={`https://github.com/BluefootLabs/Hopper-Solana-Zero-copy-State-Framework/blob/main/${current.filename}#L${current.sourceLine}`} className="ml-2 inline-block text-aurora-cyan underline underline-offset-4">Full source</a>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

/**
 * Lightweight syntax highlighter tuned for Rust. No external dep.
 * Matches the set Hopper code uses most: keywords, attributes,
 * macro names, string literals, comments, and type identifiers.
 */
function Highlighted({ code }: { code: string }) {
  const lines = code.split('\n');
  return (
    <code>
      {lines.map((line, i) => (
        <span key={i} className="flex">
          <span aria-hidden className="mr-5 w-6 select-none text-right text-[11px] text-ink-500">
            {i + 1}
          </span>
          <span className="flex-1">
            {tokenize(line).map((tok, j) => (
              <span key={j} className={tokClass(tok.kind)}>
                {tok.text}
              </span>
            ))}
          </span>
        </span>
      ))}
    </code>
  );
}

type Tok = { kind: string; text: string };

function tokenize(line: string): Tok[] {
  const out: Tok[] = [];
  let rest = line;
  while (rest.length > 0) {
    if (rest.startsWith('//')) {
      out.push({ kind: 'comment', text: rest });
      break;
    }
    const m = rest.match(
      /^(#\[[^\]]+\]|"[^"]*"|b"[^"]*"|'[^']*'|[a-z_][a-z0-9_]*!|[A-Z][A-Za-z0-9_]*|[a-z_][a-z0-9_]*|\d+|\s+|.)/,
    );
    if (!m) break;
    const t = m[1];
    rest = rest.slice(t.length);
    out.push({ kind: classify(t), text: t });
  }
  return out;
}

function classify(t: string): string {
  if (/^\s+$/.test(t)) return 'space';
  if (t.startsWith('#[')) return 'attr';
  if (t.startsWith('"') || t.startsWith("b\"") || t.startsWith("'")) return 'string';
  if (t.endsWith('!')) return 'macro';
  if (/^\d/.test(t)) return 'num';
  if (KEYWORDS.has(t)) return 'kw';
  if (/^[A-Z]/.test(t)) return 'type';
  return 'ident';
}

const KEYWORDS = new Set([
  'pub', 'fn', 'mod', 'use', 'struct', 'impl', 'self', 'mut', 'let', 'match',
  'if', 'else', 'return', 'for', 'in', 'while', 'loop', 'break', 'continue',
  'const', 'static', 'as', 'super', 'crate', 'where', 'async', 'await',
  'true', 'false',
]);

function tokClass(kind: string): string {
  switch (kind) {
    case 'attr':
      return 'text-aurora-lime';
    case 'kw':
      return 'text-aurora-violet';
    case 'string':
      return 'text-aurora-amber';
    case 'macro':
      return 'text-aurora-cyan';
    case 'type':
      return 'text-ink-50';
    case 'num':
      return 'text-aurora-amber';
    case 'comment':
      return 'text-ink-400 italic';
    case 'ident':
      return 'text-ink-200';
    default:
      return '';
  }
}
