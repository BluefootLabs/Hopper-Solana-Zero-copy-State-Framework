'use client';

import { useId, useState } from 'react';
import Link from 'next/link';
import { ArrowUpRight, Check, CornerDownRight, ShieldCheck, X } from 'lucide-react';

const CASES = [
  { name: 'Valid data', bytes: ['01', '01', '00', 'ff', '2a', '00', '00', '00', '00', '00', '00', '00'], error: null },
  { name: 'Invalid tag', bytes: ['01', '09', '00', 'ff', '2a', '00', '00', '00', '00', '00', '00', '00'], error: 'The first present mode contains 09. Only 01 and 07 are defined.' },
  { name: 'Truncated', bytes: ['01', '01', '00', 'ff', '2a', '00', '00', '00'], error: 'The prefix needs 12 bytes. This input contains only 8.' },
  { name: 'Extra byte', bytes: ['01', '01', '00', 'ff', '2a', '00', '00', '00', '00', '00', '00', '00', '61'], error: null },
] as const;

export function BorrowedBuffer() {
  const [active, setActive] = useState(0);
  const [tail, setTail] = useState(false);
  const id = useId();
  const current = CASES[active];
  const error = current.error ?? (active === 3 && !tail ? 'Exact parsing needs 12 bytes. This input has one extra byte; choose a borrowed tail to accept it.' : null);
  const valid = error === null;

  return (
    <div className="buffer-lab hero-enter min-w-0 rounded-3xl border border-white/15 bg-[#0b1317] shadow-[0_30px_100px_-40px_#000]">
      <div className="flex items-center justify-between gap-3 border-b border-white/10 px-5 py-4 sm:px-7">
        <span className="mono text-[11px] uppercase tracking-[0.16em] text-ink-200">Inside the instruction</span>
        <span className="rounded-full border border-aurora-cyan/30 px-2.5 py-1 text-[10px] text-aurora-cyan">Interactive model</span>
      </div>
      <div className="p-5 sm:p-7">
        <p className="font-display text-2xl tracking-tight text-ink-50 sm:text-3xl">One buffer. Typed access.</p>
        <p className="mt-2 text-sm leading-relaxed text-ink-300">Change the input. See where validation stops it.</p>
        <fieldset className="mt-6">
          <legend className="sr-only">Instruction data example</legend>
          <div className="flex flex-wrap gap-2">
            {CASES.map((example, index) => (
              <label key={example.name} className="cursor-pointer">
                <input className="peer sr-only" type="radio" name={`${id}-input`} checked={active === index} onChange={() => setActive(index)} aria-controls={`${id}-result`} />
                <span className="inline-flex min-h-11 items-center rounded-lg border border-white/15 px-3 py-2.5 text-xs text-ink-200 transition-colors hover:bg-white/5 peer-checked:border-aurora-cyan peer-checked:bg-aurora-cyan/10 peer-checked:text-aurora-cyan peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-aurora-cyan">{example.name}</span>
              </label>
            ))}
          </div>
        </fieldset>
        <label className="mt-4 flex min-h-11 cursor-pointer items-center gap-3 rounded-lg border border-white/10 px-3 py-2 text-xs text-ink-200">
          <input type="checkbox" checked={tail} onChange={(event) => setTail(event.target.checked)} aria-controls={`${id}-result`} className="h-4 w-4 shrink-0 accent-[#4de0e0]" />
          <span>Allow a borrowed tail<span className="mt-1 block mono text-[10px] text-ink-300">{tail ? 'parse_with_tail_checked' : 'parse_exact_checked'}</span></span>
        </label>
        <div className="mt-7 flex items-center justify-between mono text-[10px] uppercase tracking-widest text-ink-300">
          <span>Instruction payload</span><span>{current.bytes.length} bytes</span>
        </div>
        <div key={active} role="img" className="mt-3 grid grid-cols-6 gap-1.5 sm:grid-cols-12" aria-label={`Hex bytes: ${current.bytes.join(' ')}`}>
          {Array.from({ length: Math.max(12, current.bytes.length) }, (_, index) => (
            <span key={index} aria-hidden className={`byte-cell mono flex aspect-square items-center justify-center rounded-md border text-xs ${index >= current.bytes.length ? 'border-dashed border-white/15 text-ink-300' : active === 1 && index === 1 ? 'border-[#ffac94] bg-[#ffac94]/15 text-[#ffac94]' : index < 4 || index >= 12 ? 'border-aurora-cyan/35 bg-aurora-cyan/10 text-aurora-cyan' : 'border-aurora-lime/25 bg-aurora-lime/[0.07] text-aurora-lime'}`}>
              {current.bytes[index] ?? '—'}
            </span>
          ))}
        </div>
        <div className="mt-3 flex gap-5 mono text-[10px] text-ink-300">
          <span><span className="text-aurora-cyan">00–03</span> modes</span>
          <span><span className="text-aurora-lime">04–11</span> amount</span>
          {active === 3 && <span><span className="text-aurora-cyan">12</span> tail</span>}
        </div>
        <div className="relative my-5 flex items-center justify-center gap-3 py-4 text-ink-300" aria-hidden>
          <svg className="absolute inset-0 h-full w-full" viewBox="0 0 400 60" preserveAspectRatio="none" fill="none">
            <path d="M65 0V15Q65 30 85 30H160M335 0V15Q335 30 315 30H240M200 39V60" stroke="currentColor" strokeOpacity=".3" />
          </svg>
          <span className="relative flex items-center gap-2 bg-[#0b1317] px-3 mono text-[10px] text-aurora-cyan"><ShieldCheck size={15} /> CHECK</span>
        </div>
        <div id={`${id}-result`} role="status" aria-live="polite" aria-atomic="true" className={`min-h-[136px] rounded-xl border p-4 ${valid ? 'border-aurora-lime/25 bg-aurora-lime/[0.04]' : 'border-[#ffac94]/30 bg-[#ffac94]/[0.04]'}`}>
          <div className={`flex items-center gap-2 text-sm font-medium ${valid ? 'text-aurora-lime' : 'text-[#ffac94]'}`}>
            {valid ? <Check size={16} aria-hidden /> : <X size={16} aria-hidden />}
            {valid ? 'Borrow accepted' : 'Rejected before the update'}
          </div>
          <p className="mt-2 text-xs leading-relaxed text-ink-200">{error ?? (active === 3 ? 'The prefix reads amount = 42. The remaining byte, 61, is borrowed separately as the tail. The application decides what that tail means.' : 'A typed reference reads amount = 42 from the same bytes. The absent second option ignores its ff payload.')}</p>
          <div className="mt-3 flex items-center gap-2 mono text-[10px] text-ink-300"><CornerDownRight size={12} aria-hidden />{valid ? '&Update → original instruction buffer' : 'InvalidInstructionData'}</div>
        </div>
        <div className="mt-5 flex items-start justify-between gap-4 border-t border-white/10 pt-4 text-xs leading-relaxed">
          <p className="text-ink-300">Checked borrowed arguments<br /><span className="text-aurora-cyan">Next release · unreleased</span></p>
          <Link href="/docs/borrowed-arguments" className="inline-flex shrink-0 items-center gap-1 text-ink-100 underline decoration-white/30 underline-offset-4 hover:decoration-aurora-cyan">See the Rust <ArrowUpRight size={13} aria-hidden /></Link>
        </div>
      </div>
    </div>
  );
}
