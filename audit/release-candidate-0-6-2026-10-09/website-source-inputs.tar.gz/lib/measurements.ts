// Numbers quoted on the site, in one place. Every figure comes from
// `scripts/bench-framework-comparison.py` in the framework repository: pina's
// hello-world and PDA-counter fixtures, built with pina's release recipe and
// run once per instruction in Mollusk. Pinocchio is pina's own hand-written
// fixture, rebuilt and measured by the same script.

export const MEASURED = {
  date: '2026-09-30',
  commit: 'f6333ae',
  source:
    'https://github.com/BluefootLabs/Hopper-Solana-Zero-copy-State-Framework/tree/main/bench/framework-comparison',
  // The same four Hopper programs, deployed fresh to devnet on the same day
  // (round twelve): every compute-unit figure matched.
  devnet:
    'https://github.com/BluefootLabs/Hopper-Solana-Zero-copy-State-Framework/tree/main/audit/devnet-evidence-2026-09-30/framework-fixtures-round12',
};

export const HELLO = {
  pinocchio: { bytes: 3160, cu: 111 },
  raw: { bytes: 1456, cu: 111 },
  framework: { bytes: 1824, cu: 127 },
};

export const COUNTER = {
  pinocchio: { bytes: 6512, create: 1490, increment: 1721 },
  raw: { bytes: 6608, create: 1514, increment: 1722 },
  framework: { bytes: 8744, create: 1471, increment: 325 },
};

export const fmt = (n: number) => n.toLocaleString('en-US');
