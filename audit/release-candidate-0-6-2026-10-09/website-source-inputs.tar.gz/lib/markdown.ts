import { readFileSync } from 'node:fs';
import path from 'node:path';
import { cache } from 'react';
import { marked } from 'marked';
import { getDocBySlug, rewriteSourceHref } from '@/lib/docs';

marked.setOptions({
  async: false,
  gfm: true,
  breaks: false,
});

marked.use({
  walkTokens(token) {
    if (token.type === 'link' && 'href' in token && typeof token.href === 'string') {
      token.href = rewriteSourceHref(token.href);
    }
  },
});

export const getDocMarkdown = cache((slug: string) => {
  const doc = getDocBySlug(slug);
  if (!doc) return undefined;

  return readFileSync(path.join(process.cwd(), 'content', 'docs', `${doc.slug}.md`), 'utf8');
});

export function renderDocHtml(slug: string): string | undefined {
  const markdown = getDocMarkdown(slug);
  if (!markdown) return undefined;

  const html = marked.parse(stripLeadingTitle(markdown), { async: false }) as string;
  return addHeadingAnchors(sanitizeRenderedHtml(html));
}

function stripLeadingTitle(markdown: string): string {
  return markdown.replace(/^#\s+[^\n]+\n+/, '');
}

/**
 * Defense-in-depth scrub of the rendered doc HTML.
 *
 * The docs are trusted, author-controlled Markdown under `content/docs`,
 * and the browser-enforced Content-Security-Policy (`script-src` with a
 * per-request nonce; no `'unsafe-inline'`) is the real guarantee that no
 * injected script can run. This step exists so the one
 * `dangerouslySetInnerHTML` sink is not the *only* thing standing between
 * a stray raw-HTML snippet and the DOM. It is deliberately allow-nothing
 * for active content: normal Markdown output never contains any of the
 * elements, event handlers, or script URLs stripped here.
 *
 * The strip loop runs to a fixed point so a nested reforming trick like
 * `<scr<script>ipt>` cannot survive by re-closing after one pass.
 */
function sanitizeRenderedHtml(html: string): string {
  // Elements that can execute or reframe the document, with their content.
  const activeBlocks =
    /<(script|style|iframe|object|embed|noscript|template|svg|math)\b[\s\S]*?<\/\1>/gi;
  // Void / structural elements that never appear in rendered Markdown and
  // could redirect resource loading or the base URL.
  const activeVoids = /<\s*(base|meta|link|form|frame|frameset|applet)\b[^>]*>/gi;
  // Any inline event handler, in double-quoted, single-quoted, or bareword
  // form (`onclick="…"`, `onerror='…'`, `onload=alert(1)`).
  const eventHandlers = /\son[a-z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi;
  // Script-bearing URL schemes in any URL attribute, any quoting style.
  const scriptUrlDq = /\s(href|src|xlink:href)\s*=\s*"(?:javascript|vbscript):[^"]*"/gi;
  const scriptUrlSq = /\s(href|src|xlink:href)\s*=\s*'(?:javascript|vbscript):[^']*'/gi;
  const scriptUrlBare = /\s(href|src|xlink:href)\s*=\s*(?:javascript|vbscript):[^\s>]*/gi;

  let out = html;
  let prev: string;
  do {
    prev = out;
    out = out
      .replace(activeBlocks, '')
      .replace(activeVoids, '')
      .replace(eventHandlers, '')
      .replace(scriptUrlDq, ' $1="#"')
      .replace(scriptUrlSq, " $1='#'")
      .replace(scriptUrlBare, ' $1="#"');
  } while (out !== prev);
  return out;
}

function addHeadingAnchors(html: string): string {
  const seen = new Map<string, number>();

  return html.replace(/<h([1-6])>(.*?)<\/h\1>/g, (_match, level: string, inner: string) => {
    const text = inner.replace(/<[^>]+>/g, '');
    const base = slugify(text) || 'section';
    const count = seen.get(base) ?? 0;
    seen.set(base, count + 1);
    const id = count === 0 ? base : `${base}-${count + 1}`;
    return `<h${level} id="${id}"><a href="#${id}">${inner}</a></h${level}>`;
  });
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, 'and')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}
