export const PUBLISHED_VERSION = '0.5.0';
export const WORKSPACE_VERSION = '0.6.0';
export const REGISTRY_OBSERVED_DATE = '2026-10-01';

export const PUBLISHED_RELEASE_LABEL = `${PUBLISHED_VERSION} published registry release`;
export const WORKSPACE_RELEASE_LABEL = `${WORKSPACE_VERSION} unreleased source`;

export const HOPPER_ADD_COMMAND =
  `cargo add hopper-lang@${PUBLISHED_VERSION} --rename hopper --features proc-macros`;
export const HOPPER_CLI_INSTALL_COMMAND =
  `cargo install hopper-cli --version ${PUBLISHED_VERSION} --locked`;
