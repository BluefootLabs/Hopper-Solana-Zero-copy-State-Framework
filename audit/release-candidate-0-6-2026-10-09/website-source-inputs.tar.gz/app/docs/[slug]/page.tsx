import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Footer } from '@/components/footer';
import { Nav } from '@/components/nav';
import { DOCS, getDocBySlug, getDocNeighbors } from '@/lib/docs';
import { renderDocHtml } from '@/lib/markdown';
import { PUBLISHED_VERSION } from '@/lib/release';

type PageProps = {
  params: Promise<{ slug: string }>;
};

export function generateStaticParams() {
  return DOCS.map((doc) => ({ slug: doc.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const doc = getDocBySlug(slug);
  if (!doc) return {};

  return {
    title: `${doc.title} | Hopper docs`,
    description: doc.description,
    alternates: {
      canonical: `/docs/${doc.slug}`,
    },
  };
}

export default async function DocPage({ params }: PageProps) {
  const { slug } = await params;
  const doc = getDocBySlug(slug);
  const html = renderDocHtml(slug);

  if (!doc || !html) {
    notFound();
  }

  const { previous, next } = getDocNeighbors(slug);

  return (
    <>
      <Nav />
      <main id="main" tabIndex={-1} className="relative pt-28 pb-24 md:pt-36 md:pb-32">
        <div className="absolute inset-0 grid-bg pointer-events-none" aria-hidden />
        <div className="absolute inset-x-0 top-0 h-[420px] bg-radial pointer-events-none" aria-hidden />

        <div className="relative mx-auto grid max-w-7xl gap-10 px-6 lg:grid-cols-[260px_minmax(0,1fr)] lg:px-8">
          <aside className="hidden lg:block">
            <div className="sticky top-28 space-y-5">
              <Link href="/docs" className="mono text-[12px] text-aurora-cyan hover:text-ink-50">
                &lt;- Docs index
              </Link>
              <nav aria-label="Docs" className="space-y-1 border-l border-white/10 pl-4">
                {DOCS.map((item) => (
                  <Link
                    key={item.slug}
                    href={`/docs/${item.slug}`}
                    className={
                      item.slug === slug
                        ? 'block py-1.5 text-[13px] text-ink-50'
                        : 'block py-1.5 text-[13px] text-ink-400 transition-colors hover:text-ink-100'
                    }
                  >
                    {item.title}
                  </Link>
                ))}
              </nav>
            </div>
          </aside>

          <article className="min-w-0">
            <div className="mb-8 border-b border-white/10 pb-8">
              <div className="mono mb-3 text-[11px] uppercase tracking-[0.2em] text-aurora-cyan">
                {doc.category} / {doc.slug}
              </div>
              <h1 className="max-w-4xl font-display text-5xl font-medium leading-[1.03] tracking-[-0.03em] text-ink-50 md:text-7xl">
                {doc.title}
              </h1>
              <p className="mt-5 max-w-3xl text-[17px] leading-relaxed text-ink-300 md:text-[19px]">
                {doc.description}
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  href="/docs"
                  className="mono text-[12px] text-aurora-cyan hover:text-ink-50 lg:hidden"
                >
                  &lt;- Docs index
                </Link>
              </div>
              <div className="mt-6 rounded-2xl border border-amber-300/20 bg-amber-300/[0.05] px-4 py-3 text-[12.5px] leading-relaxed text-ink-300">
                This reference covers Hopper {PUBLISHED_VERSION}, published on
                crates.io. See the{' '}
                <Link href="/docs/release-status" className="text-aurora-cyan hover:text-ink-50">
                  release status
                </Link>{' '}
                for package verification, dated benchmarks, and remaining audit work.
              </div>
            </div>

            <div className="docs-prose" dangerouslySetInnerHTML={{ __html: html }} />

            <div className="mt-14 grid gap-4 border-t border-white/10 pt-8 md:grid-cols-2">
              {previous ? (
                <Link href={`/docs/${previous.slug}`} className="surface rounded-2xl p-5 transition-colors hover:border-white/12">
                  <div className="mono text-[11px] uppercase tracking-[0.2em] text-ink-500">Previous</div>
                  <div className="mt-2 font-display text-xl text-ink-50">{previous.title}</div>
                </Link>
              ) : (
                <div />
              )}
              {next ? (
                <Link href={`/docs/${next.slug}`} className="surface rounded-2xl p-5 text-right transition-colors hover:border-white/12">
                  <div className="mono text-[11px] uppercase tracking-[0.2em] text-ink-500">Next</div>
                  <div className="mt-2 font-display text-xl text-ink-50">{next.title}</div>
                </Link>
              ) : null}
            </div>
          </article>
        </div>
      </main>
      <Footer />
    </>
  );
}
