import type { Metadata } from 'next';
import Link from 'next/link';
import { Footer } from '@/components/footer';
import { Nav } from '@/components/nav';
import { DOC_CATEGORIES, DOCS } from '@/lib/docs';
import { PUBLISHED_VERSION } from '@/lib/release';

const QUICK_PATHS = [
  {
    label: 'First five minutes',
    href: '/docs/first-five',
    body: 'Counter, vault, dynamic multisig, token transfer, and raw escape hatch in one short path.',
  },
  {
    label: 'Why Hopper',
    href: '/docs/why-hopper',
    body: 'Build programs that move funds, read state in place, and enforce application rules on chain.',
  },
  {
    label: 'Write lower-level programs',
    href: '/docs/from-pinocchio',
    body: 'Use the native runtime directly and adopt typed accounts where they help your program.',
  },
  {
    label: 'Move a program to Hopper',
    href: '/docs/program-migration',
    body: 'From an Anchor-style program: constraints, account wrappers, initialization, and IDL expectations.',
  },
  {
    label: 'Client generation',
    href: '/docs/client-generation',
    body: 'Generate TS, Kotlin, Python, Go, C, and Rust readers from one Hopper manifest.',
  },
  {
    label: 'Release and audit status',
    href: '/docs/release-status',
    body: 'Published packages, measured behavior, and the remaining scope of security review.',
  },
];

export const metadata: Metadata = {
  title: 'Hopper docs | Zero-copy Solana framework',
  description:
    'Hopper documentation for zero-copy Solana programs, migration guides, CLI reference, safety invariants, and benchmark policy.',
  alternates: {
    canonical: '/docs',
  },
};

export default function DocsPage() {
  const groupedDocs = DOC_CATEGORIES.map((category) => ({
    category,
    docs: DOCS.filter((doc) => doc.category === category),
  }));

  return (
    <>
      <Nav />
      <main id="main" tabIndex={-1} className="relative pt-32 pb-24 md:pt-40 md:pb-32">
        <div className="absolute inset-0 grid-bg pointer-events-none" aria-hidden />
        <div className="absolute inset-x-0 top-0 h-[420px] bg-radial pointer-events-none" aria-hidden />

        <div className="relative mx-auto max-w-7xl px-6 lg:px-8">
          <div className="max-w-3xl">
            <div className="mono mb-3 text-[11px] uppercase tracking-[0.2em] text-aurora-cyan">
              docs
            </div>
            <h1 className="font-display text-5xl font-medium leading-[1.02] tracking-[-0.03em] text-ink-50 md:text-7xl">
              Hopper docs
            </h1>
            <p className="mt-6 text-[17px] leading-relaxed text-ink-300 md:text-[19px]">
              Start with your first program, then go as deep as you need:
              account layouts, CPIs and tokens, migrating existing programs,
              the CLI, and the self-audit.
            </p>
          </div>

          <div className="mt-12 border-y border-white/5 py-4">
            <p className="text-[13px] text-ink-400">
              These docs cover the published {PUBLISHED_VERSION} release, except
              where a page says it describes <span className="mono">main</span>.
              Benchmarks carry their date and commit.
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {QUICK_PATHS.map((path) => (
              <Link
                key={path.href}
                href={path.href}
                className="surface group rounded-2xl p-5 transition-colors hover:border-white/12"
              >
                <div className="mono text-[10.5px] uppercase tracking-[0.2em] text-aurora-cyan">
                  start here
                </div>
                <h2 className="mt-3 font-display text-xl font-medium tracking-[-0.01em] text-ink-50">
                  {path.label}
                </h2>
                <p className="mt-2 text-[13.5px] leading-relaxed text-ink-300">
                  {path.body}
                </p>
                <div className="mt-4 mono text-[12px] text-aurora-cyan transition-transform group-hover:translate-x-1">
                  Open guide -&gt;
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-14 space-y-12">
            {groupedDocs.map(({ category, docs }) => (
              <section key={category} aria-labelledby={`category-${category.toLowerCase()}`}>
                <div className="mb-4 flex items-end justify-between gap-4">
                  <h2
                    id={`category-${category.toLowerCase()}`}
                    className="font-display text-3xl font-medium tracking-[-0.02em] text-ink-50"
                  >
                    {category}
                  </h2>
                  <div className="hidden h-px flex-1 bg-white/10 md:block" />
                </div>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  {docs.map((doc) => (
                    <Link
                      id={doc.slug}
                      key={doc.slug}
                      href={`/docs/${doc.slug}`}
                      className="surface group rounded-2xl p-7 transition-colors hover:border-white/12"
                    >
                      <div className="mono text-[11px] uppercase tracking-[0.2em] text-ink-500">
                        {doc.slug}
                      </div>
                      <h3 className="mt-4 font-display text-2xl font-medium tracking-[-0.01em] text-ink-50">
                        {doc.title}
                      </h3>
                      <p className="mt-3 text-[14.5px] leading-relaxed text-ink-300">
                        {doc.description}
                      </p>
                      <div className="mt-5 mono text-[12px] text-aurora-cyan transition-transform group-hover:translate-x-1">
                        Read web doc -&gt;
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
