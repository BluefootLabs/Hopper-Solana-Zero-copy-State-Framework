import type { Metadata, Viewport } from 'next';
import { headers } from 'next/headers';
import { PUBLISHED_VERSION } from '@/lib/release';
import { MotionProvider } from '@/components/motion-provider';
import './globals.css';

export const metadata: Metadata = {
  title: 'Hopper | Rust programs. Zero-copy state. Solana.',
  description:
    `Build token escrow, payments, claims, and treasury programs in Rust with zero-copy accounts and on-chain validation. Hopper ${PUBLISHED_VERSION} is on crates.io.`,
  metadataBase: new URL('https://hopperzero.dev'),
  applicationName: 'Hopper',
  keywords: [
    'Solana',
    'zero-copy',
    'Solana framework',
    'Solana programs',
    'Rust',
    'Anchor',
    'SBF',
    'Token-2022',
    'compute units',
  ],
  authors: [
    {
      name: 'Bluefoot Labs',
      url: 'https://hopperzero.dev',
    },
  ],
  alternates: {
    canonical: '/',
  },
  icons: {
    icon: '/hopper_logo_new.png',
    shortcut: '/hopper_logo_new.png',
    apple: '/hopper_logo_new.png',
  },
  openGraph: {
    title: 'Hopper | Rust programs. Zero-copy state. Solana.',
    description:
      'Token movement, typed account access, and application rules enforced on Solana.',
    type: 'website',
    url: 'https://hopperzero.dev',
    siteName: 'Hopper Zero',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Hopper | Rust programs. Zero-copy state. Solana.',
    description: 'Build Solana programs that move tokens and enforce your rules on chain.',
    site: '@BluefootLabs',
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: '#050507',
  width: 'device-width',
  initialScale: 1,
  colorScheme: 'dark',
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Reading the request headers opts the tree into dynamic rendering so the
  // App Router injects the per-request CSP nonce (set by middleware)
  // onto its own inline hydration scripts. Without this the pages would be
  // statically prerendered with no nonce, and the strict `script-src`
  // (nonce + `strict-dynamic`, no `'unsafe-inline'`) would block Next's own
  // scripts. The trade is that HTML documents render per request; static
  // assets (JS/CSS/images) are still cached at the edge.
  await headers();

  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className="bg-ink-950 text-ink-100 min-h-screen antialiased noise overflow-x-hidden">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-ink-50 focus:px-3 focus:py-2 focus:text-[13px] focus:text-ink-950"
        >
          Skip to content
        </a>
        <MotionProvider>{children}</MotionProvider>
      </body>
    </html>
  );
}
