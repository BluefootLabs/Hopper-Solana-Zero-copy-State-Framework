import { Nav } from '@/components/nav';
import { Hero } from '@/components/hero';
import { WhyHopper } from '@/components/why-hopper';
import { CodeShowcase } from '@/components/code-showcase';
import { Numbers } from '@/components/numbers';
import { Migrate } from '@/components/migrate';
import { UseCases } from '@/components/use-cases';
import { Install } from '@/components/install';
import { Footer } from '@/components/footer';
import { NextRelease } from '@/components/next-release';

export default function HomePage() {
  return (
    <>
      <Nav />
      <main id="main" className="relative">
        <Hero />
        <WhyHopper />
        <CodeShowcase />
        <UseCases />
        <Numbers />
        <Migrate />
        <NextRelease />
        <Install />
      </main>
      <Footer />
    </>
  );
}
