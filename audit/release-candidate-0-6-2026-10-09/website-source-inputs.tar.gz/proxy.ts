import { NextRequest, NextResponse } from 'next/server';

/**
 * Per-request Content-Security-Policy with a fresh nonce.
 *
 * The nonce lets us run a strict `script-src` (no `'unsafe-inline'`): only
 * Next.js's own bootstrap script, which the App Router stamps with this
 * nonce automatically once it sees the nonce in the CSP request header,
 * may execute, and `'strict-dynamic'` lets that trusted script load the
 * hashed chunk files without us enumerating each one. Any injected inline
 * `<script>` (e.g. through the Markdown render sink) is refused by the
 * browser regardless of what slips past server-side sanitization.
 *
 * `style-src` keeps `'unsafe-inline'`: framer-motion injects element style
 * attributes at runtime and Shiki emits inline `style="…"` on highlighted
 * tokens, neither of which a nonce can cover. Style injection cannot
 * execute code, so this is the accepted, low-risk relaxation.
 *
 * This file uses the Next 16 proxy convention and its Node.js runtime.
 */
export function proxy(request: NextRequest) {
  const isDev = process.env.NODE_ENV !== 'production';

  // Web Crypto and btoa are available in Next 16's required Node 20.9+ runtime.
  const nonce = btoa(crypto.randomUUID());

  const csp = [
    `default-src 'self'`,
    // In dev, Next's Fast Refresh needs eval; never in production.
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic'${isDev ? " 'unsafe-eval'" : ''}`,
    `style-src 'self' 'unsafe-inline'`,
    `img-src 'self' data: blob:`,
    `font-src 'self' data:`,
    // HMR websocket in dev only; the site makes no external requests.
    `connect-src 'self'${isDev ? ' ws: wss:' : ''}`,
    `object-src 'none'`,
    `base-uri 'self'`,
    `form-action 'self'`,
    `frame-ancestors 'none'`,
    `frame-src 'none'`,
    `manifest-src 'self'`,
    `worker-src 'self' blob:`,
    // Force TLS for any subresource; harmless on http://localhost, so
    // scope it to production to avoid dev noise.
    ...(isDev ? [] : ['upgrade-insecure-requests']),
  ].join('; ');

  // Forward the nonce and CSP on the request so the App Router can read the
  // nonce and stamp its own scripts. Return the CSP on the response so the
  // browser enforces it.
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-nonce', nonce);
  requestHeaders.set('content-security-policy', csp);

  const response = NextResponse.next({ request: { headers: requestHeaders } });
  response.headers.set('content-security-policy', csp);
  return response;
}

export const config = {
  matcher: [
    {
      // Run on document navigations only, never on static assets, the
      // image optimizer, or route prefetches. A prefetch would mint a
      // different nonce than the eventual navigation and break the CSP.
      source:
        '/((?!api|_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml|.*\\.(?:png|jpg|jpeg|gif|svg|ico|webp|avif|css|js|map|txt|xml|json|woff|woff2|ttf|otf)$).*)',
      missing: [
        { type: 'header', key: 'next-router-prefetch' },
        { type: 'header', key: 'purpose', value: 'prefetch' },
      ],
    },
  ],
};
