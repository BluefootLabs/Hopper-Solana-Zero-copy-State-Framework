import type { Config } from 'tailwindcss';

const config: Config = {
  content: {
    relative: true,
    files: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  },
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Geist', 'Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"Geist Mono"', '"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
        display: ['"Space Grotesk"', 'Geist', 'ui-sans-serif', 'sans-serif'],
      },
      colors: {
        ink: {
          950: '#050507',
          900: '#0A0A0D',
          800: '#101015',
          700: '#17171E',
          600: '#22222C',
          500: '#2E2E3B',
          400: '#89939F',
          300: '#A1AAB6',
          200: '#C7C7D6',
          100: '#E9E9F0',
          50: '#F6F6FA',
        },
        aurora: {
          cyan: '#4DE0E0',
          lime: '#C4F542',
          violet: '#9B7BFF',
          amber: '#FFB547',
        },
      },
      backgroundImage: {
        grid: 'linear-gradient(to right, rgba(255,255,255,0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.04) 1px, transparent 1px)',
        'grid-light': 'linear-gradient(to right, rgba(0,0,0,0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(0,0,0,0.04) 1px, transparent 1px)',
        radial: 'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(155,123,255,0.12), transparent 60%)',
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(255,255,255,0.06), 0 1px 0 0 rgba(255,255,255,0.04) inset, 0 20px 60px -20px rgba(77,224,224,0.18)',
        ring: '0 0 0 1px rgba(255,255,255,0.08)',
      },
      animation: {
        marquee: 'marquee 40s linear infinite',
        drift: 'drift 12s ease-in-out infinite',
        pulseLine: 'pulseLine 3s ease-in-out infinite',
      },
      keyframes: {
        marquee: {
          from: { transform: 'translateX(0)' },
          to: { transform: 'translateX(-50%)' },
        },
        drift: {
          '0%, 100%': { transform: 'translate3d(0,0,0)' },
          '50%': { transform: 'translate3d(0,-8px,0)' },
        },
        pulseLine: {
          '0%, 100%': { opacity: '0.4' },
          '50%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};

export default config;
