//! # Program B -- Cross-Program Vault Reader
//!
//! Reads Program A's `Vault` account using `hopper_interface!`.
//!
//! **This crate has NO dependency on Program A.** It declares its own
//! view with the same name, fields, types, sizes, and version as Program
//! A's `Vault`. Because `hopper_interface!` produces a deterministic
//! `LAYOUT_ID` from that declaration (SHA-256 based), `load_cross_program()`
//! can verify ABI compatibility at runtime without any compile-time coupling.
//!
//! ## How It Works
//!
//! 1. Program A defines `Vault` with `hopper_layout!` → produces `LAYOUT_ID_A`.
//! 2. Program B defines its view with `hopper_interface!` using the same
//!    name and field spec → produces `LAYOUT_ID_B`.
//! 3. Same name + same fields + same ordering + same types + same sizes →
//!    `LAYOUT_ID_A == LAYOUT_ID_B`.
//! 4. `Vault::load_cross_program()` checks `owner == PROGRAM_A_ID` and
//!    `layout_id == LAYOUT_ID_B`. Both pass. Read succeeds.
//! 5. If Program A changes its `Vault` layout, `LAYOUT_ID_A` changes,
//!    and `load_cross_program()` rejects the account → no silent schema drift.
//!
//! ## Important
//!
//! The layout name is part of the hash input, so the view has to name
//! the layout it reads. This example calls the view `Vault`, the name
//! Program A uses. To give the local type another name, write
//! `pub struct VaultView as Vault`: the type is `VaultView` and the
//! fingerprint is `Vault`'s.

#![cfg_attr(target_os = "solana", no_std)]
#![allow(dead_code, unused_variables)]

use hopper::prelude::*;
use hopper::systems::*;

#[cfg(target_os = "solana")]
mod __hopper_sbf {
    hopper::no_allocator!();
    hopper::nostd_panic_handler!();
}

// --- Interface View -------------------------------------------------
//
// This struct is declared independently -- no import from Program A.
// Because the field names, types, sizes, and version are identical to
// Program A's Vault, the computed LAYOUT_ID will match.

hopper_interface! {
    /// Read-only view of Program A's Vault account.
    ///
    /// Same byte layout as Program A's `Vault`. The `LAYOUT_ID` fingerprint
    /// is deterministic: same fields → same hash → `load_foreign` succeeds.
    pub struct Vault, disc = 1, version = 1 {
        authority: TypedAddress<Authority> = 32,
        balance:   WireU64                = 8,
        bump:      u8                     = 1,
    }
}

// --- Errors ---------------------------------------------------------

hopper_error! {
    base = 7000;
    VaultReadFailed,
    InsufficientVaultBalance,
}

// --- Entrypoint -----------------------------------------------------

#[cfg(target_os = "solana")]
program_entrypoint!(process_instruction);

fn process_instruction(
    program_id: &Address,
    accounts: &[AccountView],
    instruction_data: &[u8],
) -> ProgramResult {
    hopper::hopper_dispatch! {
        program_id, accounts, instruction_data;
        0 => process_read_vault,
        1 => process_check_vault_min_balance,
    }
}

// --- Read Vault Balance (basic cross-program read) ------------------

fn program_a_id<'a>(accounts: &'a [AccountView]) -> Result<&'a Address, ProgramError> {
    if accounts.len() < 2 {
        return Err(ProgramError::NotEnoughAccountKeys);
    }
    let program_a = &accounts[0];
    program_a.check_executable()?;
    Ok(program_a.address())
}

fn process_read_vault(
    _program_id: &Address,
    accounts: &[AccountView],
    _data: &[u8],
) -> ProgramResult {
    let program_a_id = program_a_id(accounts)?;
    let vault_account = &accounts[1];

    // Tier 2: Cross-program read.
    // Validates: owner == passed Program A id, layout_id matches, exact size.
    let verified = Vault::load_cross_program(vault_account, program_a_id)?;
    let vault = verified.get();

    // Access Program A's vault data -- zero copies, zero deserialization.
    let _balance = vault.balance.get();
    let _authority = vault.authority.as_bytes();

    Ok(())
}

// --- Check Vault Minimum Balance (with TrustProfile) ----------------

fn process_check_vault_min_balance(
    _program_id: &Address,
    accounts: &[AccountView],
    data: &[u8],
) -> ProgramResult {
    let program_a_id = program_a_id(accounts)?;
    let vault_account = &accounts[1];

    // Parse minimum balance threshold from instruction data.
    if data.len() < 8 {
        return Err(ProgramError::InvalidInstructionData);
    }
    let min_balance = u64::from_le_bytes([
        data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7],
    ]);

    // Use a TrustProfile for configurable validation.
    // Strict: owner + layout_id + exact size + reject closed.
    let profile = TrustProfile::strict(program_a_id, &Vault::LAYOUT_ID, Vault::LEN);
    let verified = Vault::load_with_profile(vault_account, &profile)?;
    let vault = verified.get();

    // Business logic: ensure vault meets minimum balance.
    hopper_require!(vault.balance.get() >= min_balance, InsufficientVaultBalance);

    Ok(())
}
