//! `#[hopper_program]`, instruction dispatch codegen.
//!
//! Annotate a module to generate the Hopper entrypoint bridge plus a
//! `process_instruction` dispatcher based on instruction data discriminators.
//!
//! ```ignore
//! #[hopper_program]
//! mod vault {
//!     #[instruction(0)]
//!     fn initialize(ctx: &mut Context<'_>) -> ProgramResult { ... }
//!
//!     #[instruction(1)]
//!     fn deposit(ctx: Context<Deposit>, amount: u64) -> ProgramResult { ... }
//!     fn withdraw(ctx: Ctx<Withdraw>, amount: u64) -> ProgramResult { ... }
//!
//!     // Context declared with `#[instruction(amount: u64, nonce: u8)]`:
//!     // `ctx_args = 2` forwards the first two decoded args into
//!     // `Swap::bind_with_args(ctx, amount, nonce)?` so seed / constraint
//!     // expressions in the context struct can reference them by name.
//!     #[instruction(2, ctx_args = 2)]
//!     fn swap(ctx: Context<Swap>, amount: u64, nonce: u8) -> ProgramResult { ... }
//! }
//! ```

use proc_macro2::TokenStream;
use quote::{format_ident, quote, ToTokens};
use syn::{
    parse2, punctuated::Punctuated, spanned::Spanned, Attribute, Expr, ExprLit, FnArg,
    GenericArgument, Ident, Item, ItemFn, ItemMod, Lit, Meta, Pat, Path, PathArguments, Result,
    Token, Type, TypePath,
};

/// A discovered instruction handler.
///
/// The discriminator is a `Vec<u8>` with length 1 for the legacy
/// single-byte form and length `N` (up to 8) for the multi-byte form.
/// Anchor programs use 8-byte SHA-256 prefixes; Quasar lets the author
/// pick any length. Hopper caps at 8 bytes because longer prefixes
/// cost CU at the dispatcher with no real uniqueness benefit past a
/// decent hash. Dispatch matches on the prefix of instruction_data.
#[derive(Debug)]
struct Handler {
    discriminator: Vec<u8>,
    fn_name: Ident,
    binding: ContextBinding,
    /// Authored value-argument names, parallel to `arg_types`. A
    /// non-identifier pattern (destructuring, `_`) falls back to the
    /// positional `arg{i}` so the manifest row is always well-formed.
    arg_names: Vec<String>,
    arg_types: Vec<Type>,
    /// Whether the handler carries the `#[receipt]` modifier, the
    /// per-instruction truth behind the manifest's `receipt_expected`
    /// column (a receipt is emitted on the Ok path iff the author
    /// opted in; the context-level `RECEIPT_EXPECTED` const only says
    /// the context is receipt-scope *capable*).
    receipt: bool,
    /// Maximum ordered account suffix accepted by this handler.
    remaining_accounts_max: Option<Expr>,
    instruction_policy: InstructionPolicyArgs,
}

#[derive(Default)]
struct HandlerModifiers {
    pipeline: bool,
    receipt: bool,
    invariants: Vec<InvariantSpec>,
    /// `#[access_control(expr)]` pre-handler gates. Each expression is
    /// evaluated in handler scope (so it can reference `ctx`, any args,
    /// and any typed accessors) and must evaluate to `bool`. A false
    /// result bails with `ProgramError::MissingRequiredSignature` -
    /// the canonical Anchor default for access-control failures -
    /// unless the user wraps the call in a manual `require!(expr, err)`.
    /// Multiple attributes are ANDed in declaration order.
    access_control: Vec<Expr>,
    remaining_accounts_max: Option<Expr>,
}

/// A single `#[invariant(...)]` attribute on a handler.
///
/// Supports two forms:
/// - `#[invariant(cond)]`. bare condition, a violation returns
///   `ProgramError::InvalidAccountData` and leaves the receipt's
///   failure payload empty.
/// - `#[invariant(cond, err = MyError::Variant)]`. typed error
///   variant (declared via `#[hopper::error_code]`). On violation the
///   handler returns `ProgramError::Custom(MyError::Variant.code())`
///   and the receipt is stamped with the variant's code, its index
///   in `INVARIANT_TABLE`, and `FailureStage::Invariant`, closing the
///   on-chain → off-chain invariant chain.
struct InvariantSpec {
    condition: Expr,
    error_variant: Option<Expr>,
}

#[derive(Debug)]
enum ContextBinding {
    Raw,
    Typed { spec: Path },
}

/// Parsed `#[hopper::program(...)]` attribute arguments. Stored as
/// explicit per-field `Option<bool>` so a caller can supply partial
/// overrides (`#[hopper::program(strict = false)]` still implies the
/// other defaults from `HopperProgramPolicy::default_policy()`).
///
/// Named shorthand (`strict`, `raw`, `sealed`) pre-fills every field
/// to the matching `HopperProgramPolicy::*` constant; an explicit
/// `name = value` after the shorthand overrides individual levers.
#[derive(Default)]
struct ProgramPolicyArgs {
    strict: Option<bool>,
    enforce_token_checks: Option<bool>,
    allow_unsafe: Option<bool>,
    entrypoint: Option<bool>,
    max_accounts: Option<usize>,
    profile: Option<ProgramProfile>,
    manifest: Option<ManifestProfile>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ProgramProfile {
    Tiny,
    Strict,
    Audit,
    Raw,
}

/// Which of the three metadata tiers a program opts into. Mirrors
/// `hopper_core::manifest::ManifestProfile`; parsed from
/// `#[hopper::program(manifest = "offchain" | "onchain" | "governed")]`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ManifestProfile {
    Offchain,
    Onchain,
    Governed,
}

impl ProgramPolicyArgs {
    /// Resolve unset levers from `HopperProgramPolicy::STRICT`.
    fn strict(&self) -> bool {
        self.strict.unwrap_or(true)
    }
    fn enforce_token_checks(&self) -> bool {
        self.enforce_token_checks.unwrap_or(true)
    }
    fn allow_unsafe(&self) -> bool {
        self.allow_unsafe.unwrap_or(true)
    }
    fn entrypoint(&self) -> bool {
        self.entrypoint.unwrap_or(true)
    }
    fn max_accounts(&self) -> Option<usize> {
        self.max_accounts
    }
    fn profile_tokens(&self) -> TokenStream {
        match self.profile.unwrap_or(ProgramProfile::Strict) {
            ProgramProfile::Tiny => quote! { ::hopper::__runtime::HopperProgramProfile::TINY },
            ProgramProfile::Strict => quote! { ::hopper::__runtime::HopperProgramProfile::STRICT },
            ProgramProfile::Audit => quote! { ::hopper::__runtime::HopperProgramProfile::AUDIT },
            ProgramProfile::Raw => quote! { ::hopper::__runtime::HopperProgramProfile::RAW },
        }
    }

    fn is_tiny_profile(&self) -> bool {
        matches!(self.profile, Some(ProgramProfile::Tiny))
    }

    fn manifest_tokens(&self) -> TokenStream {
        match self.manifest.unwrap_or(ManifestProfile::Offchain) {
            ManifestProfile::Offchain => {
                quote! { ::hopper::manifest::ManifestProfile::Offchain }
            }
            ManifestProfile::Onchain => {
                quote! { ::hopper::manifest::ManifestProfile::Onchain }
            }
            ManifestProfile::Governed => {
                quote! { ::hopper::manifest::ManifestProfile::Governed }
            }
        }
    }
}

impl HandlerModifiers {
    fn is_empty(&self) -> bool {
        !self.pipeline
            && !self.receipt
            && self.invariants.is_empty()
            && self.access_control.is_empty()
    }
}

/// Parsed per-handler `#[instruction(N, unsafe_memory, skip_token_checks, allow_arbitrary_cpi, ctx_args = K)]`
/// flags. Bare flag form only: `unsafe_memory` equivalent to
/// `unsafe_memory = true`.
///
/// `ctx_args = K` ties the handler to a typed context spec that was
/// declared with `#[instruction(name: Type, ...)]`. It tells the
/// dispatch codegen: "the first `K` decoded args belong to the context
/// binder. thread them to `bind_with_args(...)`. and *all* decoded
/// args (including those K) are still forwarded to the handler
/// function". This is the program-side half of Audit Task #20: it
/// closes the gap where a `#[hopper::context]` with instruction args
/// couldn't compose with the `ctx: Context<MyAccounts>` sugar because
/// the args-less `bind(...)` is intentionally not emitted for such
/// specs.
///
/// Validation rules applied later in `prepare_handler`:
/// - `ctx_args > 0` requires the leading parameter to be a typed
///   context (not `&mut Context<'_>`).
/// - `ctx_args` must be ≤ the number of handler value args, otherwise
///   the decoder would be asked for more than exist.
/// - `ctx_args` defaults to `0`, preserving the legacy behavior where
///   dispatch calls `bind(ctx)?` on argument-free context specs.
#[derive(Default, Clone, Copy, Debug)]
struct InstructionPolicyArgs {
    unsafe_memory: bool,
    skip_token_checks: bool,
    allow_arbitrary_cpi: bool,
    ctx_args: u8,
}

pub fn expand(attr: TokenStream, item: TokenStream) -> Result<TokenStream> {
    let policy = parse_program_policy(attr)?;
    let mut input: ItemMod = parse2(item.clone()).map_err(|_| {
        syn::Error::new_spanned(
            &item,
            "hopper_program expects a module, e.g. `mod vault { ... }`",
        )
    })?;

    let mut handlers: Vec<Handler> = Vec::new();
    if input.content.is_none() {
        return Err(syn::Error::new_spanned(
            &input,
            "hopper_program requires an inline module body",
        ));
    }
    let (_, items) = input.content.as_mut().expect("checked above");

    for module_item in items.iter_mut() {
        if let Item::Fn(method) = module_item {
            if let Some(mut handler) = prepare_handler(method, policy.is_tiny_profile())? {
                method
                    .attrs
                    .retain(|attr| !attr.path().is_ident("instruction"));
                handler.fn_name = method.sig.ident.clone();
                handlers.push(handler);
            }
        }
    }

    if policy.is_tiny_profile() {
        for handler in &handlers {
            if handler.discriminator.len() != 1 {
                return Err(syn::Error::new_spanned(
                    &input,
                    format!(
                        "profile = \"tiny\" requires one-byte instruction discriminators; `{}` uses {} bytes",
                        handler.fn_name,
                        handler.discriminator.len()
                    ),
                ));
            }
        }
    }

    if handlers.is_empty() {
        return Err(syn::Error::new_spanned(
            &input,
            "hopper_program requires at least one #[instruction(N)] function",
        ));
    }

    // Sort for deterministic codegen AND correct dispatch ordering:
    // longer discriminators first so a 4-byte prefix can't be shadowed
    // by a 1-byte prefix it happens to start with. Within a length,
    // sort by bytes so the emitted `if` chain is stable.
    handlers.sort_by(|a, b| {
        b.discriminator
            .len()
            .cmp(&a.discriminator.len())
            .then_with(|| a.discriminator.cmp(&b.discriminator))
    });

    // Exact-duplicate detection. Two handlers with the same bytes is
    // always a bug, no matter the length.
    for i in 0..handlers.len() {
        for j in (i + 1)..handlers.len() {
            if handlers[i].discriminator == handlers[j].discriminator {
                return Err(syn::Error::new_spanned(
                    &input,
                    format!(
                        "duplicate instruction discriminator {:02x?}: `{}` and `{}`",
                        handlers[i].discriminator, handlers[i].fn_name, handlers[j].fn_name,
                    ),
                ));
            }
        }
    }

    // Prefix-shadow detection. If handler A's discriminator is a
    // strict prefix of handler B's, then B's bytes coming in would
    // match A's prefix first (in the sorted-by-length-desc emission,
    // B runs first, which is correct ordering, but the program author
    // probably didn't intend it). Flag it so the author either
    // lengthens A or shortens B.
    for i in 0..handlers.len() {
        for j in 0..handlers.len() {
            if i == j {
                continue;
            }
            let short = &handlers[i].discriminator;
            let long = &handlers[j].discriminator;
            if short.len() < long.len() && long.starts_with(short) {
                return Err(syn::Error::new_spanned(
                    &input,
                    format!(
                        "instruction discriminator {:02x?} (`{}`) is a prefix of {:02x?} (`{}`). Either lengthen the shorter one or shorten the longer one so the dispatcher can distinguish them unambiguously.",
                        short, handlers[i].fn_name, long, handlers[j].fn_name,
                    ),
                ));
            }
        }
    }

    // ── Self-CPI event sink (`event_cpi`) ──────────────────────────────
    //
    // `#[hopper::context(event_cpi)]` advertises `EVENT_CPI = true` on
    // the spec type (the same const-advertisement shape as
    // `EMIT_TOUCH_MAP`). The dispatcher cannot know at MACRO time
    // whether any bound context opted in, contexts are usually
    // declared outside the module; so it emits a module const
    // `__HOPPER_EVENT_CPI_ENABLED` that ORs `EVENT_CPI` across every
    // typed context spec referenced by a handler, and guards the
    // reserved `[0xE0, 0x1E]` event sink behind it. The OR resolves at
    // type-check time and const-folds:
    //
    // - some bound context opted in → marker-prefixed instruction data
    //   routes to the runtime's authenticated `handle_event_sink`
    //   (marker + signer + on-chain PDA pin), so the author writes no
    //   sentinel handler at all;
    // - no context opted in → the guard folds to `false`, the sink
    //   helper collapses to the same `InvalidInstructionData` the
    //   fallthrough arm returns, and the dispatch hot path is
    //   untouched (unknown-discriminator semantics are preserved
    //   byte-for-byte).
    //
    // Programs with ONLY raw `&mut Context<'_>` handlers have no typed
    // spec to consult, so nothing is emitted and their expansion stays
    // byte-identical; raw handlers keep the documented manual-sentinel
    // path (the same exclusion the touch-map emit documents).
    let mut typed_specs: Vec<Path> = Vec::new();
    for handler in &handlers {
        if let ContextBinding::Typed { spec } = &handler.binding {
            if !typed_specs
                .iter()
                .any(|seen| quote!(#seen).to_string() == quote!(#spec).to_string())
            {
                typed_specs.push(spec.clone());
            }
        }
    }
    // A user discriminator that collides with the reserved marker,
    // exactly `[0xE0]` (which would shadow every marker-prefixed
    // payload) or anything starting `[0xE0, 0x1E]` (which would shadow
    // specific events), cannot coexist with a live sink. Whether any
    // context opted in is unknowable here, so the collision lowers to a
    // const-assert on `__HOPPER_EVENT_CPI_ENABLED` that fails the
    // downstream build ONLY when both the colliding discriminator and
    // an opted-in context exist; the sink arm itself is withheld.
    let marker_conflict = handlers.iter().any(|h| {
        h.discriminator.as_slice() == [0xE0]
            || (h.discriminator.len() >= 2
                && h.discriminator[0] == 0xE0
                && h.discriminator[1] == 0x1E)
    });
    let event_sink_live = !typed_specs.is_empty() && !marker_conflict;

    // Fast path: every discriminator is exactly one byte. Emit the
    // dense `match data[0] { b => handler, ... }` form so the compiler
    // keeps the jump-table optimization. Anchor programs that never
    // touched the multi-byte syntax see byte-for-byte identical
    // codegen to the pre-multi-byte Hopper.
    let all_single_byte = handlers.iter().all(|h| h.discriminator.len() == 1);
    // Tiny profile: the count-exact entrypoint calls a per-instruction
    // `__hopper_exact_*` helper that returns the entry's `u64` code itself,
    // so the entry is `call; exit` with no result test and no success code
    // held across the call. That helper is the out-of-line frame; the
    // `Result` helper inlines into it. The scanning `process_instruction`
    // that also names the `Result` helpers is never called from a tiny
    // program's SBF entrypoint, so inlining them there cannot grow a frame
    // that runs on chain.
    let tiny = policy.is_tiny_profile();
    let dispatch_inline = if tiny {
        quote! { #[inline(always)] }
    } else {
        quote! { #[inline(never)] }
    };
    let dispatch_helpers: Vec<(Vec<u8>, Ident, Item)> = handlers
        .iter()
        .map(|h| {
            let helper = format_ident!("__hopper_dispatch_{}", h.fn_name);
            let invocation = handler_invocation(h);
            // `pub(crate)` so the count-exact entrypoint emitted beside the
            // module (tiny profile) can name the helper directly.
            let item = syn::parse2(quote! {
                #[doc(hidden)]
                #dispatch_inline
                pub(crate) fn #helper(
                    ctx: &mut ::hopper::prelude::Context<'_>,
                    data: &[u8],
                ) -> ::core::result::Result<(), ::hopper::__runtime::ProgramError> {
                    #invocation
                }
            })?;
            Ok::<_, syn::Error>((h.discriminator.clone(), helper, item))
        })
        .collect::<Result<_>>()?;
    let exact_helpers: Vec<Item> = if tiny {
        handlers
            .iter()
            .map(|h| {
                let helper = format_ident!("__hopper_dispatch_{}", h.fn_name);
                let exact = format_ident!("__hopper_exact_{}", h.fn_name);
                syn::parse2(quote! {
                    #[doc(hidden)]
                    #[inline(never)]
                    pub(crate) fn #exact(
                        ctx: &mut ::hopper::prelude::Context<'_>,
                        data: &[u8],
                    ) -> u64 {
                        match #helper(ctx, data) {
                            ::core::result::Result::Ok(()) => ::hopper::__runtime::__hopper_native::SUCCESS,
                            ::core::result::Result::Err(error) => ::hopper::__runtime::entry_refusal(error),
                        }
                    }
                })
            })
            .collect::<syn::Result<_>>()?
    } else {
        Vec::new()
    };

    // Fn-pointer-table eligibility: every discriminator is one byte
    // AND together they form the dense range 0..=N-1. The handlers are
    // already sorted bytes-ascending within the single-byte length
    // class (see the sort above), so "index == byte" is a complete
    // contiguity test: N distinct sorted bytes matching 0..N leave no
    // gaps and no offset.
    let contiguous_from_zero = all_single_byte
        && handlers
            .iter()
            .enumerate()
            .all(|(index, h)| usize::from(h.discriminator[0]) == index);

    // Instruction-level disassembly (CU-path audit, 2026-07-07) showed the
    // indirect `callx` costs ~7 instructions of setup plus lost inlining,
    // a small dispatch `match` (2 instructions for N=1) beats the table
    // until roughly 6-10 arms. Only emit the table when it can win.
    const MIN_TABLE_DISPATCH_ARMS: usize = 8;
    let table_worthwhile = handlers.len() >= MIN_TABLE_DISPATCH_ARMS;

    // Slow path entries for the multi-byte case. Emitted as an
    // ordered `if data.starts_with(&[...]) { ... } else if ...` chain
    // because `match` in Rust cannot branch on a variable-length slice
    // prefix.
    let dispatch_body = if contiguous_from_zero && table_worthwhile && policy.is_tiny_profile() {
        // `profile = "tiny"` + dense 0..=N-1 discriminators: dispatch
        // through a static fn-pointer table instead of a `match`. On
        // sBPF, LLVM lowers the indirect call to a single `callx`
        // (~5 CU), beating the compare-and-branch ladder the `match`
        // form can degrade into. The table is a `static`, so it is
        // const-evaluated into rodata - no lazy init, no_std-safe.
        //
        // Error semantics are byte-identical to the `match` form:
        // empty data and any byte >= N both return
        // `ProgramError::InvalidInstructionData`. Argument decoding is
        // untouched because the table holds the exact same
        // `__hopper_dispatch_*` helpers the match arms call.
        let table_len = handlers.len();
        let helper_idents: Vec<&Ident> = dispatch_helpers
            .iter()
            .map(|(_, helper, _)| helper)
            .collect();
        // Sink integration for the table form: the marker's first byte
        // (0xE0 = 224) is out of the dense 0..N range whenever the
        // table is sink-eligible (a table covering 224 means a handler
        // OWNS `[0xE0]`, which `marker_conflict` catches), so the check
        // lives inside the existing >= bounds-miss branch, zero cost
        // for every real instruction.
        let table_sink_check: TokenStream = if event_sink_live {
            quote! {
                if __hopper_disc == 0xE0usize {
                    return __hopper_dispatch_event_sink(ctx, data);
                }
            }
        } else {
            TokenStream::new()
        };
        quote! {
            if data.is_empty() {
                return ::core::result::Result::Err(
                    ::hopper::__runtime::ProgramError::InvalidInstructionData,
                );
            }
            static __HOPPER_DISPATCH_TABLE: [
                for<'ctx, 'view, 'data> fn(
                    &'ctx mut ::hopper::prelude::Context<'view>,
                    &'data [u8],
                ) -> ::core::result::Result<(), ::hopper::__runtime::ProgramError>;
                #table_len
            ] = [ #(#helper_idents),* ];
            let __hopper_disc = data[0] as usize;
            if __hopper_disc >= #table_len {
                #table_sink_check
                return ::core::result::Result::Err(
                    ::hopper::__runtime::ProgramError::InvalidInstructionData,
                );
            }
            __HOPPER_DISPATCH_TABLE[__hopper_disc](ctx, data)
        }
    } else if all_single_byte {
        let match_arms: Vec<TokenStream> = handlers
            .iter()
            .zip(dispatch_helpers.iter())
            .map(|(h, (_, helper, _))| {
                let byte = h.discriminator[0];
                quote! { #byte => #helper(ctx, data), }
            })
            .collect();
        // Sink integration for the match form: one more literal arm on
        // the marker's first byte, before the fallthrough. The arm is a
        // plain helper call like every other, so the jump-table shape
        // survives; the helper itself validates the second marker byte.
        // `marker_conflict` guarantees no user arm already claims 0xE0.
        let match_sink_arm: TokenStream = if event_sink_live {
            quote! { 0xE0u8 => __hopper_dispatch_event_sink(ctx, data), }
        } else {
            TokenStream::new()
        };
        quote! {
            if data.is_empty() {
                return ::core::result::Result::Err(
                    ::hopper::__runtime::ProgramError::InvalidInstructionData,
                );
            }
            match data[0] {
                #(#match_arms)*
                #match_sink_arm
                _ => ::core::result::Result::Err(
                    ::hopper::__runtime::ProgramError::InvalidInstructionData,
                ),
            }
        }
    } else {
        // Prefix-match chain, longest first.
        let arms: Vec<TokenStream> = handlers
            .iter()
            .zip(dispatch_helpers.iter())
            .map(|(h, (_, helper, _))| {
                let bytes = &h.discriminator;
                let byte_lits: Vec<u8> = bytes.clone();
                quote! {
                    if data.starts_with(&[ #(#byte_lits),* ]) {
                        return #helper(ctx, data);
                    }
                }
            })
            .collect();
        // Sink integration for the chain form: one more prefix test
        // after every user arm (order is safe: `marker_conflict` bars
        // any user discriminator that is `[0xE0]` or `[0xE0, 0x1E, ..]`,
        // so no earlier arm can shadow the marker and the marker cannot
        // shadow any user arm).
        let chain_sink_check: TokenStream = if event_sink_live {
            quote! {
                if data.starts_with(&[0xE0u8, 0x1Eu8]) {
                    return __hopper_dispatch_event_sink(ctx, data);
                }
            }
        } else {
            TokenStream::new()
        };
        quote! {
            #(#arms)*
            #chain_sink_check
            ::core::result::Result::Err(
                ::hopper::__runtime::ProgramError::InvalidInstructionData,
            )
        }
    };

    // Apply per-handler policy: when the program disallows unsafe and
    // the handler does not opt back in via `unsafe_memory`, emit
    // `#[deny(unsafe_code)]` on the handler. Surfacing it as an
    // attribute (rather than wrapping the function body) keeps the
    // policy visible in `cargo expand` output.
    if !policy.allow_unsafe() {
        for module_item in items.iter_mut() {
            let Item::Fn(method) = module_item else {
                continue;
            };
            let Some(handler) = handlers.iter().find(|h| h.fn_name == method.sig.ident) else {
                continue;
            };
            if handler.instruction_policy.unsafe_memory {
                continue;
            }
            method.attrs.push(syn::parse_quote!(#[deny(unsafe_code)]));
        }
    }

    // Emit per-handler `<HANDLER>_POLICY: HopperInstructionPolicy`
    // constants so downstream code can branch on them at compile time
    // the same way it branches on `HOPPER_PROGRAM_POLICY`.
    for handler in handlers.iter() {
        let const_name = format_ident!("{}_POLICY", handler.fn_name.to_string().to_uppercase());
        let unsafe_memory = handler.instruction_policy.unsafe_memory;
        let skip_token_checks = handler.instruction_policy.skip_token_checks;
        let allow_arbitrary_cpi = handler.instruction_policy.allow_arbitrary_cpi;
        let ctx_args = handler.instruction_policy.ctx_args;
        items.push(syn::parse_quote! {
            #[allow(non_upper_case_globals, dead_code)]
            pub const #const_name: ::hopper::__runtime::HopperInstructionPolicy =
                ::hopper::__runtime::HopperInstructionPolicy {
                    unsafe_memory: #unsafe_memory,
                    skip_token_checks: #skip_token_checks,
                    allow_arbitrary_cpi: #allow_arbitrary_cpi,
                    ctx_args: #ctx_args,
                };
        });
    }

    // Emit the program-level policy const at module scope so handlers
    // can consult it via `super::HOPPER_PROGRAM_POLICY.<lever>`.
    let strict = policy.strict();
    let enforce_token_checks = policy.enforce_token_checks();
    let allow_unsafe = policy.allow_unsafe();
    let profile = policy.profile_tokens();
    items.push(syn::parse_quote! {
        #[allow(dead_code)]
        pub const HOPPER_PROGRAM_POLICY: ::hopper::__runtime::HopperProgramPolicy =
            ::hopper::__runtime::HopperProgramPolicy {
                strict: #strict,
                enforce_token_checks: #enforce_token_checks,
                allow_unsafe: #allow_unsafe,
            };
    });

    items.push(syn::parse_quote! {
        #[allow(dead_code)]
        pub const HOPPER_PROGRAM_PROFILE: ::hopper::__runtime::HopperProgramProfile = #profile;
    });

    let manifest_profile = policy.manifest_tokens();
    items.push(syn::parse_quote! {
        /// Which metadata tier this program opts into (Tier 2/3).
        /// Defaults to `Offchain`; set with `#[hopper::program(manifest = "...")]`.
        #[allow(dead_code)]
        pub const HOPPER_PROGRAM_MANIFEST_PROFILE: ::hopper::manifest::ManifestProfile =
            #manifest_profile;
    });

    // ── Manifest schema statics (Phase B) ──────────────────────────────
    //
    // Everything `hopper::program_manifest!` needs from the program side,
    // emitted with zero authoring:
    //
    // - `__HOPPER_INSTRUCTION_DESCRIPTORS`: one `InstructionDescriptor`
    //   row per TYPED handler (`ctx: Ctx<Spec>` / `Context<Spec>`), in
    //   dispatch order. RAW `&mut Context<'_>` handlers are skipped,
    //   their account shape is opaque to the schema layer (no spec type
    //   to consult), the same exclusion the touch-map/event-sink emits
    //   document. `tag` remains byte zero for compact/legacy lookup while
    //   `discriminator` publishes the exact 1..=8-byte dispatch prefix.
    // - per-row account lists CONVERTED at const-eval from the spec's
    //   `SCHEMA_METADATA.accounts` through the module-level LEN-const
    //   copy-loop pattern (`__HOPPER_SCHEMA_ACCOUNTS`'s shape), so
    //   composed/optional/event_cpi contexts of ANY flattened length
    //   convert without small-literal assumptions and the published
    //   list can never drift from the enforced one.
    // - `__HOPPER_CONTEXT_DESCRIPTORS`: each distinct bound spec's
    //   `SCHEMA_METADATA`, verbatim.
    //
    // Columns the macro cannot know are never fabricated: `args` sizes
    // come from a fixed wire-size table (`0` = unknown), `capabilities`
    // / `policy_pack` stay empty, and `cu_estimate` stays `0` (see the
    // field's contract in hopper-schema).
    let mut instruction_rows: Vec<TokenStream> = Vec::new();
    for handler in &handlers {
        let ContextBinding::Typed { spec } = &handler.binding else {
            continue;
        };
        let fn_name = &handler.fn_name;
        let fn_name_str = fn_name.to_string();
        let tag_byte = handler.discriminator[0];
        let discriminator = &handler.discriminator;
        let accounts_len_ident = format_ident!("__HOPPER_IX_{}_ACCOUNTS_LEN", fn_name);
        let accounts_arr_ident = format_ident!("__HOPPER_IX_{}_ACCOUNTS", fn_name);

        // Length lives at MODULE level (same rationale as the context
        // macro's `__HOPPER_{Name}_WRITE_RANGES_LEN`): an array length is
        // an anonymous const, and routing it through a named const keeps
        // the copy-loop below fully concrete for any account count.
        items.push(syn::parse_quote! {
            #[doc(hidden)]
            #[allow(non_upper_case_globals, dead_code)]
            pub const #accounts_len_ident: usize =
                #spec::SCHEMA_METADATA.accounts.len();
        });
        items.push(syn::parse_quote! {
            /// Manifest `AccountEntry` rows for one typed handler,
            /// converted at const-eval from the bound context's
            /// `SCHEMA_METADATA.accounts`. `name` / `writable` /
            /// `signer` / `layout_ref` / `seeds` carry over verbatim.
            #[doc(hidden)]
            #[allow(non_upper_case_globals, dead_code)]
            pub const #accounts_arr_ident:
                [::hopper::hopper_schema::AccountEntry; #accounts_len_ident] = {
                let __src = #spec::SCHEMA_METADATA.accounts;
                // Descriptor count and the module-level length const are
                // the same contract; a mismatch is a macro bug and must
                // fail the build, not ship a lying manifest.
                assert!(
                    __src.len() == #accounts_len_ident,
                    "instruction account conversion must cover the context's full descriptor set"
                );
                let mut __out =
                    [::hopper::hopper_schema::AccountEntry::PROVIDED; #accounts_len_ident];
                let mut __i = 0;
                while __i < __src.len() {
                    __out[__i] = ::hopper::hopper_schema::AccountEntry {
                        name: __src[__i].name,
                        writable: __src[__i].writable,
                        signer: __src[__i].signer,
                        layout_ref: __src[__i].layout_ref,
                        seeds: __src[__i].seeds,
                    };
                    __i += 1;
                }
                __out
            };
        });

        // The context binder receives the first `ctx_args` decoded handler
        // values by position, while parametric Effect ABI rules identify
        // selectors by their context argument names. Pin both views together
        // at const-eval so reordering `(b, a)` in a handler cannot make the
        // runtime authorize one cell while an independent verifier resolves
        // another.
        let ctx_args = handler.instruction_policy.ctx_args as usize;
        let bound_arg_names = &handler.arg_names[..ctx_args];
        items.push(syn::parse_quote! {
            const _: () = {
                let __context_args = #spec::CONTEXT_ARGS;
                let __handler_args: &[&str] = &[#(#bound_arg_names),*];
                assert!(
                    __context_args.len() == __handler_args.len(),
                    "ctx_args must equal the typed context's declared instruction-argument count",
                );
                let mut __i = 0usize;
                while __i < __context_args.len() {
                    assert!(
                        ::hopper::hopper_schema::const_str_eq(
                            __context_args[__i].0,
                            __handler_args[__i],
                        ),
                        "handler/context instruction arguments must have identical names and order",
                    );
                    __i += 1;
                }
            };
        });

        let arg_rows: Vec<TokenStream> = handler
            .arg_names
            .iter()
            .zip(handler.arg_types.iter())
            .map(|(arg_name, arg_ty)| {
                let canonical = arg_ty.to_token_stream().to_string().replace(' ', "");
                let (size, encoding) = arg_wire_metadata(arg_ty);
                quote! {
                    ::hopper::hopper_schema::ArgDescriptor {
                        name: #arg_name,
                        canonical_type: #canonical,
                        size: #size,
                        encoding: #encoding,
                    }
                }
            })
            .collect();

        let remaining_accounts = match &handler.remaining_accounts_max {
            Some(max) => quote! {
                ::core::option::Option::Some(
                    ::hopper::hopper_schema::RemainingAccountsDescriptor {
                        max: (#max) as u16,
                    }
                )
            },
            None => quote! { ::core::option::Option::None },
        };

        // `receipt_expected` is the HANDLER's `#[receipt]` opt-in, not
        // the context's `RECEIPT_EXPECTED` const: the latter only says
        // the context is receipt-scope capable (it is `true` for any
        // context with a mutable account), while a receipt is actually
        // emitted iff the author put `#[receipt]` on this handler.
        let receipt_flag = handler.receipt;

        instruction_rows.push(quote! {
            ::hopper::hopper_schema::InstructionDescriptor {
                name: #fn_name_str,
                tag: #tag_byte,
                discriminator: &[#(#discriminator),*],
                args: &[ #(#arg_rows),* ],
                accounts: &#accounts_arr_ident,
                remaining_accounts: #remaining_accounts,
                capabilities: &[],
                policy_pack: "",
                receipt_expected: #receipt_flag,
                strict_writes: #spec::STRICT_WRITES,
                write_ranges: #spec::WRITE_RANGES,
                parametric_write_ranges: #spec::PARAMETRIC_WRITE_RANGES,
                mutation_complete: #spec::MUTATION_COMPLETE,
                lamport_accounts: #spec::LAMPORT_ACCOUNTS,
                cu_estimate: 0,
            }
        });
    }
    items.push(syn::parse_quote! {
        /// Instruction rows for `hopper::program_manifest!`, one per
        /// typed handler, wired from the same generated consts the
        /// runtime enforces (`SCHEMA_METADATA`, `STRICT_WRITES`,
        /// `WRITE_RANGES`, `MUTATION_COMPLETE`, `LAMPORT_ACCOUNTS`)
        /// plus the handler's own `#[receipt]` opt-in. Raw
        /// `&mut Context<'_>` handlers publish no row (their shape is
        /// opaque); multi-byte discriminators publish byte 0 as legacy `tag`
        /// and the complete prefix as `discriminator`;
        /// `cu_estimate` stays 0 (never fabricated).
        #[doc(hidden)]
        #[allow(dead_code)]
        pub static __HOPPER_INSTRUCTION_DESCRIPTORS:
            &[::hopper::hopper_schema::InstructionDescriptor] = &[
            #(#instruction_rows),*
        ];
    });
    // Each row is the spec's own `SCHEMA_METADATA` plus the names of the
    // handlers bound to it, so a manifest consumer can join an instruction
    // to its context by name rather than by account shape (two contexts
    // with the same shape would otherwise be indistinguishable).
    let context_rows: Vec<TokenStream> = typed_specs
        .iter()
        .map(|spec| {
            let spec_key = quote!(#spec).to_string();
            let names: Vec<String> = handlers
                .iter()
                .filter(|h| match &h.binding {
                    ContextBinding::Typed { spec: bound } => quote!(#bound).to_string() == spec_key,
                    ContextBinding::Raw => false,
                })
                .map(|h| h.fn_name.to_string())
                .collect();
            quote! {
                ::hopper::hopper_schema::accounts::ContextDescriptor {
                    instructions: &[ #(#names),* ],
                    ..#spec::SCHEMA_METADATA
                }
            }
        })
        .collect();
    items.push(syn::parse_quote! {
        /// Context descriptors for `hopper::program_manifest!`, each
        /// distinct typed spec's `SCHEMA_METADATA` with the bound handler
        /// names filled in, in first-bound order.
        #[doc(hidden)]
        #[allow(dead_code)]
        pub static __HOPPER_CONTEXT_DESCRIPTORS:
            &[::hopper::hopper_schema::accounts::ContextDescriptor] = &[
            #(#context_rows),*
        ];
    });

    // Self-CPI event sink plumbing (only when a typed spec exists to
    // consult; raw-only programs emit nothing and stay byte-identical).
    if !typed_specs.is_empty() {
        // `false || A::EVENT_CPI || B::EVENT_CPI || ...`, built by
        // folding rather than a `quote!` separator so the expression is
        // a plain const-evaluable OR chain over the deduplicated specs.
        let mut event_cpi_or: TokenStream = quote! { false };
        for spec in &typed_specs {
            event_cpi_or = quote! { #event_cpi_or || #spec::EVENT_CPI };
        }
        items.push(syn::parse_quote! {
            /// Whether any typed context bound by this program's
            /// handlers opted into `#[hopper::context(event_cpi)]`.
            ///
            /// Resolved at type-check time by ORing each spec's
            /// `EVENT_CPI` const, then const-folded: `true` arms the
            /// reserved `[0xE0, 0x1E]` event sink in the dispatcher;
            /// `false` collapses the sink to the ordinary
            /// unknown-discriminator error, costing nothing.
            #[doc(hidden)]
            #[allow(dead_code)]
            pub const __HOPPER_EVENT_CPI_ENABLED: bool = #event_cpi_or;
        });

        if marker_conflict {
            // The colliding discriminator is only fatal when a context
            // actually opted in; a program that never uses event_cpi
            // keeps its 0xE0-prefixed instruction untouched.
            items.push(syn::parse_quote! {
                const _: () = assert!(
                    !__HOPPER_EVENT_CPI_ENABLED,
                    "an instruction discriminator collides with the reserved Hopper \
                     CPI-event marker [0xE0, 0x1E] while a #[hopper::context(event_cpi)] \
                     context is bound by this program; renumber the instruction (any \
                     discriminator that is exactly [0xE0] or starts with [0xE0, 0x1E]) \
                     or drop the event_cpi option"
                );
            });
        }

        if event_sink_live && tiny {
            items.push(syn::parse_quote! {
                /// The event sink's count-exact entry helper: the entry
                /// code, as the per-instruction `__hopper_exact_*` helpers
                /// return it.
                #[doc(hidden)]
                #[inline(never)]
                #[allow(dead_code)]
                pub(crate) fn __hopper_exact_event_sink(
                    ctx: &mut ::hopper::prelude::Context<'_>,
                    data: &[u8],
                ) -> u64 {
                    match __hopper_dispatch_event_sink(ctx, data) {
                        ::core::result::Result::Ok(()) => ::hopper::__runtime::__hopper_native::SUCCESS,
                        ::core::result::Result::Err(error) => ::hopper::__runtime::entry_refusal(error),
                    }
                }
            });
        }

        if event_sink_live {
            items.push(syn::parse_quote! {
                /// Reserved `[0xE0, 0x1E]` self-CPI event sink.
                ///
                /// Const-guarded: when no bound context opted into
                /// `event_cpi` this collapses to the same
                /// `InvalidInstructionData` the dispatcher's fallthrough
                /// arm returns (and the arm that calls it is
                /// dead-code-eliminated). When live, it delegates to the
                /// runtime's authenticated sink: full marker check,
                /// event-authority signer requirement, and the on-chain
                /// PDA address pin.
                #[inline(never)]
                #[allow(dead_code)]
                pub(crate) fn __hopper_dispatch_event_sink(
                    ctx: &mut ::hopper::prelude::Context<'_>,
                    data: &[u8],
                ) -> ::core::result::Result<(), ::hopper::__runtime::ProgramError> {
                    if !__HOPPER_EVENT_CPI_ENABLED {
                        return ::core::result::Result::Err(
                            ::hopper::__runtime::ProgramError::InvalidInstructionData,
                        );
                    }
                    ::hopper::__runtime::cpi_event::handle_event_sink(ctx, data)
                }
            });
        }
    }

    for (_, _, helper) in dispatch_helpers {
        items.push(helper);
    }
    for helper in exact_helpers {
        items.push(helper);
    }

    // The dispatcher is a few instructions (discriminator read, match or
    // table `callx`); every handler body lives behind an `#[inline(never)]`
    // `__hopper_dispatch_*` helper with its own frame, so inlining the
    // dispatcher into the bridge cannot grow any frame past the helper's.
    // It removes one call/return and one round of argument reloads from
    // every instruction (measured 2026-09-21 on the hello fixture).
    items.push(syn::parse_quote! {
        #[inline(always)]
        pub fn process_instruction(
            ctx: &mut ::hopper::prelude::Context<'_>,
        ) -> ::core::result::Result<(), ::hopper::__runtime::ProgramError> {
            let data = ctx.instruction_data();
            #dispatch_body
        }
    });

    let program_mod = input.ident.clone();
    let bridge_fn = format_ident!("__hopper_process_instruction_{}", program_mod);
    // `fast_entrypoint!` is feature-aware: without `simd-0321` it is an
    // exact alias for the scanning `program_entrypoint!` (byte-identical
    // default builds); with the feature it emits the r2 two-argument
    // entrypoint, null-checked back to the scanning parse on any runtime
    // that leaves r2 zero. Emitting it here (fixed 2026-07-21) is what
    // makes the `simd-0321` feature reach macro programs at all, the
    // previous hardcoded `program_entrypoint!` silently ignored it. The
    // feature stays opt-in: post-fusion A/Bs measured the r2 path
    // CU-neutral (+/- 2) on in-repo programs for ~368 bytes of dual-path
    // `.text`; its real value is as the base of the SIMD-0449 table path.
    let entrypoint_macro = match policy.max_accounts() {
        Some(max_accounts) => quote! { ::hopper::fast_entrypoint!(#bridge_fn, #max_accounts); },
        None => quote! { ::hopper::fast_entrypoint!(#bridge_fn); },
    };
    // `profile = "tiny"`: count-exact entry. The discriminator is read from
    // the SIMD-0321 `r2` pointer before any account is touched, and the
    // matched arm materializes exactly its context's declared bound
    // (`ACCOUNT_COUNT`, plus a declared `#[remaining_accounts(max)]`), so
    // the transaction-sized pointer table and the walk to the instruction
    // tail disappear from the entry path. Raw `&mut Context` handlers keep
    // the full bound (`max_accounts` or the transaction maximum) because
    // they may read any account. Undeclared extra accounts are not
    // materialized on this path; declare them with `#[remaining_accounts]`.
    let exact_entrypoint: Option<TokenStream> = if policy.is_tiny_profile() {
        let raw_bound = match policy.max_accounts() {
            Some(max_accounts) => quote! { #max_accounts },
            None => quote! { ::hopper::__runtime::MAX_TX_ACCOUNTS },
        };
        let mut arms: Vec<TokenStream> = handlers
            .iter()
            .map(|h| {
                let disc = h.discriminator[0];
                let helper = format_ident!("__hopper_exact_{}", h.fn_name);
                let bound = match (&h.binding, &h.remaining_accounts_max) {
                    (ContextBinding::Typed { spec }, Some(max)) => {
                        quote! { <#spec>::ACCOUNT_COUNT + (#max) }
                    }
                    (ContextBinding::Typed { spec }, None) => quote! { <#spec>::ACCOUNT_COUNT },
                    (ContextBinding::Raw, _) => raw_bound.clone(),
                };
                quote! { (#disc, #bound, #program_mod::#helper) }
            })
            .collect();
        if event_sink_live {
            // Guarded by the program's resolved `event_cpi` constant: when
            // no bound context opted in, the arm folds away and 0xE0 takes
            // the unknown-discriminator refusal, exactly what the collapsed
            // sink would have returned, without a compare on every entry.
            arms.push(quote! {
                (0xE0u8 if #program_mod::__HOPPER_EVENT_CPI_ENABLED, #raw_bound, #program_mod::__hopper_exact_event_sink)
            });
        }
        Some(quote! { ::hopper::hopper_exact_entrypoint! { #(#arms),* } })
    } else {
        None
    };
    // The bridge owns the `Context` frame (about 1 KiB: the segment borrow
    // registry). With the default 254-slot account table the entrypoint
    // frame is already 2 KiB, so the bridge stays a separate frame to keep
    // both under the 4 KiB SBF v1 limit. A program that declares a small
    // `max_accounts` has room to spare, and inlining the bridge into the
    // entrypoint drops a call/return and the argument shuffle per
    // instruction.
    const BRIDGE_INLINE_MAX_ACCOUNTS: usize = 64;
    let bridge_inline: TokenStream = match policy.max_accounts() {
        Some(max) if max <= BRIDGE_INLINE_MAX_ACCOUNTS => quote! { #[inline(always)] },
        _ => quote! { #[inline(never)] },
    };
    let entrypoint_bridge = if let (true, Some(exact)) = (policy.entrypoint(), exact_entrypoint) {
        quote! {
            #[allow(unexpected_cfgs)]
            #[cfg(target_os = "solana")]
            #exact
        }
    } else if policy.entrypoint() {
        quote! {
            #[allow(unexpected_cfgs)]
            #[cfg(target_os = "solana")]
            #entrypoint_macro

            #[doc(hidden)]
            #bridge_inline
            fn #bridge_fn(
                program_id: &::hopper::__runtime::Address,
                accounts: &[::hopper::__runtime::AccountView<'_>],
                instruction_data: &[u8],
            ) -> ::core::result::Result<(), ::hopper::__runtime::ProgramError> {
                let mut ctx = ::hopper::prelude::Context::new(program_id, accounts, instruction_data);
                #program_mod::process_instruction(&mut ctx)
            }
        }
    } else {
        quote! {}
    };

    let expanded = quote! {
        #input
        #entrypoint_bridge
    };

    Ok(expanded)
}

/// Parse `#[hopper::program(...)]` attribute args.
///
/// Accepts:
/// - empty args: defaults to `HopperProgramPolicy::STRICT`
/// - bare shorthand: `strict` | `raw` | `sealed`
/// - explicit levers: `strict = bool`, `enforce_token_checks = bool`, `allow_unsafe = bool`, `entrypoint = bool`, `max_accounts = usize`, `profile = "tiny|strict|audit|raw"`
/// - any combination (shorthand sets defaults; explicit levers override)
fn parse_program_policy(attr: TokenStream) -> Result<ProgramPolicyArgs> {
    let mut policy = ProgramPolicyArgs::default();
    if attr.is_empty() {
        return Ok(policy);
    }

    let metas: Punctuated<Meta, Token![,]> =
        syn::parse::Parser::parse2(Punctuated::<Meta, Token![,]>::parse_terminated, attr)?;

    for meta in metas {
        match meta {
            Meta::Path(path) => match path_ident(&path)?.as_str() {
                "strict" => {
                    policy.strict.get_or_insert(true);
                    policy.enforce_token_checks.get_or_insert(true);
                    policy.allow_unsafe.get_or_insert(true);
                    policy.profile.get_or_insert(ProgramProfile::Strict);
                }
                "sealed" => {
                    policy.strict.get_or_insert(true);
                    policy.enforce_token_checks.get_or_insert(true);
                    policy.allow_unsafe.get_or_insert(false);
                    policy.profile.get_or_insert(ProgramProfile::Audit);
                    // Explicit `sealed` locks allow_unsafe off even if
                    // defaulting left it unset as true.
                    policy.allow_unsafe = Some(false);
                }
                "raw" => {
                    policy.strict = Some(false);
                    policy.enforce_token_checks = Some(false);
                    policy.allow_unsafe.get_or_insert(true);
                    policy.profile.get_or_insert(ProgramProfile::Raw);
                }
                other => {
                    return Err(syn::Error::new(
                        path.span(),
                        format!(
                            "unknown program policy shorthand `{other}`; expected `strict`, `sealed`, or `raw`",
                        ),
                    ));
                }
            },
            Meta::NameValue(nv) => {
                let name = path_ident(&nv.path)?;
                if name == "profile" {
                    policy.profile = Some(expect_profile_lit(&nv.value)?);
                    if matches!(policy.profile, Some(ProgramProfile::Raw)) {
                        policy.strict = Some(false);
                        policy.enforce_token_checks = Some(false);
                        policy.allow_unsafe.get_or_insert(true);
                    }
                    continue;
                }
                if name == "max_accounts" {
                    policy.max_accounts = Some(expect_usize_lit(&nv.value, "max_accounts")?);
                    continue;
                }
                if name == "manifest" {
                    policy.manifest = Some(expect_manifest_lit(&nv.value)?);
                    continue;
                }
                let value = expect_bool_lit(&nv.value)?;
                match name.as_str() {
                    "strict" => policy.strict = Some(value),
                    "enforce_token_checks" => policy.enforce_token_checks = Some(value),
                    "allow_unsafe" => policy.allow_unsafe = Some(value),
                    "entrypoint" => policy.entrypoint = Some(value),
                    other => {
                        return Err(syn::Error::new(
                            nv.path.span(),
                            format!(
                                "unknown program policy lever `{other}`; expected `strict`, `enforce_token_checks`, `allow_unsafe`, `entrypoint`, `max_accounts`, `profile`, or `manifest`",
                            ),
                        ));
                    }
                }
            }
            Meta::List(list) => {
                return Err(syn::Error::new(
                    list.span(),
                    "hopper::program policy expects bare flags or `name = bool` pairs",
                ));
            }
        }
    }

    Ok(policy)
}

fn expect_profile_lit(expr: &Expr) -> Result<ProgramProfile> {
    if let Expr::Lit(ExprLit {
        lit: Lit::Str(value),
        ..
    }) = expr
    {
        match value.value().as_str() {
            "tiny" => Ok(ProgramProfile::Tiny),
            "strict" => Ok(ProgramProfile::Strict),
            "audit" => Ok(ProgramProfile::Audit),
            "raw" => Ok(ProgramProfile::Raw),
            other => Err(syn::Error::new(
                value.span(),
                format!(
                    "unknown program profile `{other}`; expected `tiny`, `strict`, `audit`, or `raw`"
                ),
            )),
        }
    } else {
        Err(syn::Error::new(
            expr.span(),
            "expected a string literal (`tiny`, `strict`, `audit`, or `raw`)",
        ))
    }
}

fn expect_manifest_lit(expr: &Expr) -> Result<ManifestProfile> {
    if let Expr::Lit(ExprLit {
        lit: Lit::Str(value),
        ..
    }) = expr
    {
        match value.value().as_str() {
            "offchain" => Ok(ManifestProfile::Offchain),
            "onchain" => Ok(ManifestProfile::Onchain),
            "governed" => Ok(ManifestProfile::Governed),
            other => Err(syn::Error::new(
                value.span(),
                format!(
                    "unknown manifest profile `{other}`; expected `offchain`, `onchain`, or `governed`"
                ),
            )),
        }
    } else {
        Err(syn::Error::new(
            expr.span(),
            "manifest expects a string literal (`offchain`, `onchain`, or `governed`)",
        ))
    }
}

fn path_ident(path: &Path) -> Result<String> {
    path.get_ident()
        .map(|ident| ident.to_string())
        .ok_or_else(|| syn::Error::new(path.span(), "expected a bare identifier"))
}

fn expect_bool_lit(expr: &Expr) -> Result<bool> {
    if let Expr::Lit(ExprLit {
        lit: Lit::Bool(b), ..
    }) = expr
    {
        Ok(b.value)
    } else {
        Err(syn::Error::new(
            expr.span(),
            "expected a boolean literal (`true` or `false`)",
        ))
    }
}

fn expect_usize_lit(expr: &Expr, name: &str) -> Result<usize> {
    if let Expr::Lit(ExprLit {
        lit: Lit::Int(int), ..
    }) = expr
    {
        int.base10_parse::<usize>()
            .map_err(|_| syn::Error::new(expr.span(), format!("`{name}` must fit in usize")))
    } else {
        Err(syn::Error::new(
            expr.span(),
            format!("expected an integer literal for `{name}`"),
        ))
    }
}

/// Extract a u8 literal for `ctx_args = K`. The cap matches the
/// Hopper-wide 255-item limit already used by `#[hopper::error_code]`
/// receipts and SchemaExport positional slots. Anything larger almost
/// certainly indicates a typo rather than a 256-arg handler.
fn expect_u8_lit(expr: &Expr) -> Result<u8> {
    if let Expr::Lit(ExprLit {
        lit: Lit::Int(int), ..
    }) = expr
    {
        int.base10_parse::<u8>()
            .map_err(|_| syn::Error::new(expr.span(), "`ctx_args` must fit in a u8 (0..=255)"))
    } else {
        Err(syn::Error::new(
            expr.span(),
            "expected an integer literal for `ctx_args`",
        ))
    }
}

/// Best-effort wire size in bytes for one typed handler argument,
/// resolved from a fixed table over the type's last path segment.
///
/// This feeds `ArgDescriptor.size` in the generated manifest rows. The
/// table covers exactly the fixed-size `DecodeInstructionArg`
/// implementations (primitives, their `Wire*` twins, 32-byte address
/// types, and `[u8; N]`-style arrays with literal lengths). Anything
/// else, variable-length args (`&[u8]`, `BoundedString`,
/// `BoundedVec`), const-generic lengths, unknown user types, returns
/// `0`, the documented "unknown" sentinel: a size is never fabricated.
fn arg_wire_size(ty: &Type) -> u16 {
    match ty {
        // `&[u8; N]` decodes as a borrowed fixed array: same wire size
        // as the owned form. (`&[u8]` recurses into `Type::Slice`,
        // which falls through to 0, its length is caller-defined.)
        Type::Reference(reference) => arg_wire_size(&reference.elem),
        Type::Array(array) => {
            let elem = arg_wire_size(&array.elem);
            let len = match &array.len {
                Expr::Lit(ExprLit {
                    lit: Lit::Int(int), ..
                }) => int.base10_parse::<u16>().unwrap_or(0),
                _ => 0,
            };
            elem.saturating_mul(len)
        }
        Type::Path(TypePath { path, .. }) => {
            let Some(last) = path.segments.last() else {
                return 0;
            };
            match last.ident.to_string().as_str() {
                "u8" | "i8" | "bool" | "WireBool" | "EnumByte" => 1,
                "u16" | "i16" | "WireU16" | "WireI16" => 2,
                "u32" | "i32" | "WireU32" | "WireI32" => 4,
                "u64" | "i64" | "WireU64" | "WireI64" => 8,
                "u128" | "i128" | "WireU128" | "WireI128" => 16,
                "Address" | "Pubkey" | "TypedAddress" | "UntypedAddress" => 32,
                _ => 0,
            }
        }
        _ => 0,
    }
}

/// Publish both the resolved maximum size and the encoding shape. Unlike the
/// legacy `arg_wire_size` table, the returned tokens are evaluated in the
/// program crate, so const-generic capacities such as `MAX_ROUTE_DATA` remain
/// exact instead of collapsing to zero in the proc-macro process.
fn arg_wire_metadata(ty: &Type) -> (TokenStream, TokenStream) {
    let unwrapped = match ty {
        Type::Reference(reference) => &*reference.elem,
        other => other,
    };

    let legacy_size = arg_wire_size(unwrapped);
    let size = if matches!(unwrapped, Type::Array(_) | Type::Path(_)) {
        // Borrowed user layouts publish their size through the same decoder
        // that consumes them. Type aliases therefore keep the wire contract.
        quote! {{
            let size = <#ty as ::hopper::__macro_support::DecodeInstructionArg>::WIRE_SIZE;
            assert!(size <= u16::MAX as usize, "instruction argument exceeds manifest size range");
            size as u16
        }}
    } else {
        quote! { #legacy_size }
    };
    let encoding = if matches!(unwrapped, Type::Array(_) | Type::Path(_)) {
        quote! { <#ty as ::hopper::__macro_support::DecodeInstructionArg>::ENCODING }
    } else {
        quote! { ::hopper::hopper_schema::ArgEncoding::Fixed }
    };
    (size, encoding)
}

fn prepare_handler(function: &mut ItemFn, tiny_profile: bool) -> Result<Option<Handler>> {
    if !function
        .attrs
        .iter()
        .any(|attr| attr_has_name(attr, "instruction"))
    {
        return Ok(None);
    }

    let modifiers = extract_handler_modifiers(&mut function.attrs)?;
    if tiny_profile && !modifiers.is_empty() {
        return Err(syn::Error::new_spanned(
            &function.sig,
            "profile = \"tiny\" does not allow #[pipeline], #[receipt], #[invariant], or #[access_control] handler modifiers; use profile = \"strict\" or profile = \"audit\" for modifier instrumentation",
        ));
    }

    let (discriminator, instruction_policy) = extract_instruction_attribute(&function.attrs)?
        .ok_or_else(|| {
            syn::Error::new_spanned(
                &function.sig,
                "hopper_program requires #[instruction(N)] on each generated handler",
            )
        })?;

    if function.sig.inputs.is_empty() {
        return Err(syn::Error::new_spanned(
            &function.sig,
            "hopper_program handlers must start with either `ctx: &mut Context<'_>`, `ctx: Context<MyAccounts>`, or `ctx: Ctx<MyAccounts>`",
        ));
    }

    let mut inputs = function.sig.inputs.iter_mut();
    let first = inputs.next().expect("checked above");
    let binding = classify_context_binding(first)?;

    let mut arg_names = Vec::new();
    let mut arg_types = Vec::new();
    for (index, input) in inputs.enumerate() {
        match input {
            FnArg::Typed(pat_type) => {
                arg_names.push(match pat_type.pat.as_ref() {
                    Pat::Ident(pat_ident) => pat_ident.ident.to_string(),
                    _ => format!("arg{index}"),
                });
                arg_types.push((*pat_type.ty).clone());
            }
            FnArg::Receiver(receiver) => {
                return Err(syn::Error::new_spanned(
                    receiver,
                    "hopper_program does not support methods; use free functions inside the module",
                ));
            }
        }
    }

    // `ctx_args = K` is only valid when the handler's leading arg is a
    // typed `Context<MyAccounts>`. the `&mut Context<'_>` raw form
    // doesn't have a `bind_with_args` to route to. And K must not
    // exceed the handler's own value-arg count, because we decode one
    // arg per slot and the first K go to the binder.
    let ctx_args = instruction_policy.ctx_args as usize;
    if ctx_args > 0 {
        if matches!(binding, ContextBinding::Raw) {
            return Err(syn::Error::new_spanned(
                &function.sig,
                "`ctx_args = ...` requires a typed `Context<MyAccounts>` parameter, not `&mut Context<'_>`",
            ));
        }
        if ctx_args > arg_types.len() {
            return Err(syn::Error::new_spanned(
                &function.sig,
                format!(
                    "`ctx_args = {ctx_args}` exceeds the handler's {} value argument(s)",
                    arg_types.len(),
                ),
            ));
        }
    }

    apply_handler_modifiers(function, &binding, &modifiers)?;

    Ok(Some(Handler {
        discriminator,
        fn_name: function.sig.ident.clone(),
        binding,
        arg_names,
        arg_types,
        receipt: modifiers.receipt,
        remaining_accounts_max: modifiers.remaining_accounts_max,
        instruction_policy,
    }))
}

fn handler_invocation(handler: &Handler) -> TokenStream {
    let fn_name = &handler.fn_name;
    let ctx_args = handler.instruction_policy.ctx_args as usize;

    // Fast path: no instruction args at all.
    if handler.arg_types.is_empty() {
        return match &handler.binding {
            // Raw `&mut Context<'_>` handlers have no typed context spec
            // to name, so there is no `EMIT_TOUCH_MAP` const to consult
            // and this form never emits a touch map (documented). Keep
            // the prior codegen shape byte-for-byte.
            ContextBinding::Raw => quote! { #fn_name(ctx) },
            // Typed context, args-less: bind, run the handler, and on the
            // Ok path only, const-guard the self-describing touch-map
            // emit (touch-map). See `ok_path_touch_map_emit` for the rationale.
            ContextBinding::Typed { spec } => {
                let emit = ok_path_touch_map_emit(spec);
                quote! {{
                    #fn_name(#spec::bind(ctx)?)?;
                    #emit
                    ::core::result::Result::Ok(())
                }}
            }
        };
    }

    let arg_idents: Vec<Ident> = (0..handler.arg_types.len())
        .map(|index| format_ident!("__hopper_arg_{index}"))
        .collect();
    let decode_stmts: Vec<_> = handler
        .arg_types
        .iter()
        .zip(arg_idents.iter())
        .map(|(arg_ty, arg_ident)| {
            quote! {
                let #arg_ident: #arg_ty =
                    <#arg_ty as ::hopper::__macro_support::DecodeInstructionArg>::decode(
                        &mut __hopper_decoder,
                    )?;
            }
        })
        .collect();

    // Build the context expression. `ctx_args == 0` keeps the legacy
    // `bind(ctx)?` (or raw `ctx`). `ctx_args > 0` routes to
    // `bind_with_args(ctx, arg0, ..., arg{K-1})?`. the same decoded
    // values are *also* reused as handler arguments, so the pattern
    // matches Anchor's "seeds refer to an arg the handler also sees"
    // ergonomics but with real typed bindings.
    //
    // `emit` is the Ok-path, const-guarded touch-map finish call (touch-map);
    // it is empty for raw contexts, which have no typed spec to name.
    let (ctx_expr, emit) = match (&handler.binding, ctx_args) {
        (ContextBinding::Raw, _) => (quote! { ctx }, TokenStream::new()),
        (ContextBinding::Typed { spec }, 0) => {
            (quote! { #spec::bind(ctx)? }, ok_path_touch_map_emit(spec))
        }
        (ContextBinding::Typed { spec }, k) => {
            let binder_args = &arg_idents[..k];
            (
                quote! { #spec::bind_with_args(ctx, #(#binder_args),*)? },
                ok_path_touch_map_emit(spec),
            )
        }
    };

    // Raw contexts keep the exact prior tail expression (`handler(ctx,
    // args)`); typed contexts split it so the touch-map emit lands on the
    // Ok path only. `emit` is empty for the raw case, so its branch is
    // still `handler(...)` with no epilogue.
    let call = match &handler.binding {
        ContextBinding::Raw => quote! { #fn_name(#ctx_expr, #(#arg_idents),*) },
        ContextBinding::Typed { .. } => quote! {
            #fn_name(#ctx_expr, #(#arg_idents),*)?;
            #emit
            ::core::result::Result::Ok(())
        },
    };

    // Skip the discriminator prefix so the arg decoder starts at the
    // first payload byte. `disc_len` is the source of truth; it is
    // computed from the parsed bytes (1 for single-byte, N for
    // multi-byte). Single-byte programs keep the exact old offset.
    let disc_len = handler.discriminator.len();
    quote! {{
        let mut __hopper_decoder = ::hopper::__macro_support::Decoder::new(&data[#disc_len..]);
        #(#decode_stmts)*
        __hopper_decoder.finish()?;
        #call
    }}
}

/// Touch-map support: the Ok-path, const-guarded self-describing touch-map
/// emit that a dispatch helper runs after its typed handler returns Ok.
///
/// `<Spec>::EMIT_TOUCH_MAP` is a `const bool` the `#[hopper::context]`
/// macro emits on the spec type: `true` only when the author opted in
/// via `#[hopper::context(emit_touch_map)]`, `false` otherwise. Because
/// the guard is a `const`, the compiler dead-code-eliminates the whole
/// `if` (zero instructions) for every context that did not opt in, so
/// this taxes nobody on the golden path.
///
/// It runs ONLY on the Ok path, the dispatch helper places it after
/// `handler(...)?`, so any `Err` (via `?`, `require!`, a failed
/// invariant, an access-control gate) short-circuits before reaching it.
/// A failed, rolled-back instruction therefore never emits a
/// self-describing record advertising Write ranges it did not keep. This
/// is the fix for the failed-instruction emission regression where a `Drop`-based emit fired on
/// every scope exit, including error returns. `ctx` is borrowable here
/// because the bound context (which reborrowed `&mut ctx`) was moved into
/// the handler and dropped when it returned, so the reborrow has ended.
fn ok_path_touch_map_emit(spec: &Path) -> TokenStream {
    quote! {
        if #spec::EMIT_TOUCH_MAP {
            ctx.finish_with_touch_map();
        }
    }
}

fn classify_context_binding(arg: &mut FnArg) -> Result<ContextBinding> {
    let FnArg::Typed(pat_type) = arg else {
        return Err(syn::Error::new_spanned(
            arg,
            "hopper_program handlers must use a typed context parameter, not a method receiver",
        ));
    };

    if is_raw_context_ref(&pat_type.ty) {
        return Ok(ContextBinding::Raw);
    }

    if let Some(spec) = extract_typed_context_spec(&pat_type.ty)? {
        let spec = strip_context_type_args(spec);
        let bound_ty = bind_type_for(&spec)?;
        *pat_type.ty = bound_ty;
        mark_pattern_mutable(&mut pat_type.pat)?;
        return Ok(ContextBinding::Typed { spec });
    }

    Err(syn::Error::new_spanned(
        &pat_type.ty,
        "hopper_program handlers must start with either `ctx: &mut Context<'_>`, `ctx: Context<MyAccounts>`, or `ctx: Ctx<MyAccounts>`",
    ))
}

/// Parse an `#[invariant(...)]` attribute on a handler.
///
/// Accepts:
/// - `#[invariant(expr)]`. condition only.
/// - `#[invariant(expr, err = MyError::Variant)]`. condition plus
///   typed error variant. The variant must come from an enum decorated
///   with `#[hopper::error_code]` so that `.code()` and `.invariant_idx()`
///   exist on it at expansion time.
///
/// Additional positional args or repeated `err =` keys are rejected
/// so mistakes surface early rather than silently emit stray code.
fn parse_invariant_attr(attr: &Attribute) -> Result<InvariantSpec> {
    let args = attr.parse_args_with(Punctuated::<Expr, Token![,]>::parse_terminated)?;
    let mut items = args.into_iter();
    let condition = items.next().ok_or_else(|| {
        syn::Error::new_spanned(attr, "#[invariant(...)] requires a boolean condition")
    })?;

    let mut error_variant: Option<Expr> = None;
    for extra in items {
        if let Expr::Assign(ref assign) = extra {
            if let Expr::Path(ref left) = *assign.left {
                if left.path.is_ident("err") {
                    if error_variant.is_some() {
                        return Err(syn::Error::new_spanned(
                            &extra,
                            "#[invariant(...)]: `err = ...` may only be set once",
                        ));
                    }
                    error_variant = Some((*assign.right).clone());
                    continue;
                }
            }
        }
        return Err(syn::Error::new_spanned(
            extra,
            "#[invariant(cond[, err = MyError::Variant])] supports only `err = ...` after the condition",
        ));
    }

    Ok(InvariantSpec {
        condition,
        error_variant,
    })
}

fn extract_handler_modifiers(attrs: &mut Vec<Attribute>) -> Result<HandlerModifiers> {
    let mut modifiers = HandlerModifiers::default();
    let mut retained = Vec::with_capacity(attrs.len());

    for attr in attrs.drain(..) {
        if attr_has_name(&attr, "pipeline") {
            modifiers.pipeline = true;
            continue;
        }
        if attr_has_name(&attr, "receipt") {
            if !matches!(attr.meta, syn::Meta::Path(_)) {
                return Err(syn::Error::new_spanned(
                    attr,
                    "receipt does not take arguments yet; use bare #[receipt]",
                ));
            }
            modifiers.receipt = true;
            continue;
        }
        if attr_has_name(&attr, "invariant") {
            modifiers.invariants.push(parse_invariant_attr(&attr)?);
            continue;
        }
        if attr_has_name(&attr, "access_control") {
            // `#[access_control(expr)]` - parse the expression inside
            // the parens. Anchor's spelling. Multiple attributes are
            // allowed and each gate is evaluated in declaration order;
            // the first false bails the handler.
            let expr: Expr = attr.parse_args().map_err(|e| {
                syn::Error::new(
                    e.span(),
                    "#[access_control(expr)] requires a boolean expression inside the parens",
                )
            })?;
            modifiers.access_control.push(expr);
            continue;
        }
        if attr_has_name(&attr, "remaining_accounts") {
            if modifiers.remaining_accounts_max.is_some() {
                return Err(syn::Error::new_spanned(
                    attr,
                    "#[remaining_accounts(...)] may only be declared once",
                ));
            }
            let entries = attr.parse_args_with(Punctuated::<Meta, Token![,]>::parse_terminated)?;
            let mut max = None;
            for entry in entries {
                match entry {
                    Meta::NameValue(value) if value.path.is_ident("max") => {
                        if max.is_some() {
                            return Err(syn::Error::new_spanned(
                                value,
                                "remaining_accounts max may only be set once",
                            ));
                        }
                        max = Some(value.value);
                    }
                    other => {
                        return Err(syn::Error::new_spanned(
                            other,
                            "expected #[remaining_accounts(max = CONST)]",
                        ));
                    }
                }
            }
            modifiers.remaining_accounts_max = Some(max.ok_or_else(|| {
                syn::Error::new_spanned(&attr, "remaining_accounts requires `max = CONST`")
            })?);
            continue;
        }
        retained.push(attr);
    }

    *attrs = retained;
    Ok(modifiers)
}

fn apply_handler_modifiers(
    function: &mut ItemFn,
    binding: &ContextBinding,
    modifiers: &HandlerModifiers,
) -> Result<()> {
    if !modifiers.pipeline
        && !modifiers.receipt
        && modifiers.invariants.is_empty()
        && modifiers.access_control.is_empty()
    {
        return Ok(());
    }

    let ctx_ident = context_ident(function)?;
    let raw_ctx = raw_context_expr(&ctx_ident, binding);
    let original_block = function.block.clone();

    if modifiers.receipt && matches!(binding, ContextBinding::Raw) {
        return Err(syn::Error::new_spanned(
            &function.sig,
            "#[receipt] currently requires a typed Hopper context so receipt segments can be derived from #[hopper_context]",
        ));
    }

    let pipeline_checks = if modifiers.pipeline {
        quote! {
            #raw_ctx.require_unique_writable_accounts()?;
            #raw_ctx.require_unique_signer_accounts()?;
        }
    } else {
        TokenStream::new()
    };

    let receipt_begin = if modifiers.receipt {
        match binding {
            ContextBinding::Typed { spec } => quote! {
                let __hopper_receipt_scope = #spec::begin_receipt_scope::<256>(&#raw_ctx)?;
            },
            ContextBinding::Raw => TokenStream::new(),
        }
    } else {
        TokenStream::new()
    };

    let receipt_finish = if modifiers.receipt {
        quote! {
            __hopper_receipt_scope.finish(
                &#raw_ctx,
                __hopper_invariants_passed,
                __hopper_invariants_checked,
                __hopper_failure_info,
            )?;
        }
    } else {
        TokenStream::new()
    };

    // Build the failure-capture block for each invariant. Two flavors:
    //
    // 1. Bare condition (`#[invariant(cond)]`). on violation we preserve
    //    the legacy behavior: `ProgramError::InvalidAccountData`, no
    //    failure payload recorded.
    //
    // 2. Typed-error form (`#[invariant(cond, err = MyError::Variant)]`)
    //. on violation we extract `.code()` and `.invariant_idx()` from
    //    the variant (methods emitted by `#[hopper::error_code]`), stamp the
    //    receipt's failure slot when a receipt is in scope, and return
    //    `ProgramError::Custom(code)`. This is what makes the invariant
    //    name visible to off-chain consumers without a hand-written
    //    lookup table.
    //
    // When `#[receipt]` is not on the handler, the failure stamp has
    // nowhere to go and we skip the assignment. that also avoids an
    // `unused_assignments` warning from the generated code.
    let receipt_enabled = modifiers.receipt;
    let invariant_checks: Vec<_> = modifiers
        .invariants
        .iter()
        .map(|spec| {
            let cond = &spec.condition;
            let on_fail = match &spec.error_variant {
                Some(err) => {
                    let stamp = if receipt_enabled {
                        quote! {
                            __hopper_failure_info = ::core::option::Option::Some((
                                __hopper_err_code,
                                __hopper_err_idx,
                                ::hopper::receipt::FailureStage::Invariant,
                            ));
                        }
                    } else {
                        TokenStream::new()
                    };
                    quote! {
                        let __hopper_err_variant = #err;
                        let __hopper_err_code: u32 = __hopper_err_variant.code();
                        let __hopper_err_idx: u8 = __hopper_err_variant.invariant_idx();
                        #stamp
                        __hopper_modifier_error = ::core::option::Option::Some(
                            ::hopper::__runtime::ProgramError::Custom(__hopper_err_code),
                        );
                    }
                }
                None => quote! {
                    __hopper_modifier_error = ::core::option::Option::Some(
                        ::hopper::__runtime::ProgramError::InvalidAccountData,
                    );
                },
            };
            quote! {
                if __hopper_modifier_error.is_none() {
                    let __hopper_invariant_value = (|| -> ::core::result::Result<bool, ::hopper::__runtime::ProgramError> {
                        Ok(#cond)
                    })()?;
                    __hopper_invariants_checked = __hopper_invariants_checked.saturating_add(1);
                    if !__hopper_invariant_value {
                        __hopper_invariants_passed = false;
                        #on_fail
                    }
                }
            }
        })
        .collect();

    // Only declare `__hopper_failure_info` when a receipt scope will
    // consume it, otherwise the generated code would have an unused
    // variable. The variable must exist in scope for any
    // `__hopper_failure_info = Some(...)` assignment the checks emit,
    // so its declaration gates off the typed-error stamp above.
    let failure_info_decl = if receipt_enabled {
        quote! {
            let mut __hopper_failure_info: ::core::option::Option<(
                u32,
                u8,
                ::hopper::receipt::FailureStage,
            )> = None;
        }
    } else {
        TokenStream::new()
    };

    // Pre-handler access-control gates. Emitted before the pipeline
    // checks so a denied caller never even reaches the deduplication
    // pass. Each gate is an expression that evaluates in the handler's
    // scope (so it can reference `ctx`, any typed accessors, and all
    // handler arguments). A false result returns
    // `ProgramError::MissingRequiredSignature` - the canonical default
    // Anchor uses. Users who want a specific error can wrap the gate
    // in `require!(expr, MyError::NotAllowed)` inside the body
    // instead.
    let access_control_gates: Vec<_> = modifiers
        .access_control
        .iter()
        .map(|expr| {
            quote! {
                if !(#expr) {
                    return ::core::result::Result::Err(
                        ::hopper::__runtime::ProgramError::MissingRequiredSignature,
                    );
                }
            }
        })
        .collect();

    *function.block = syn::parse_quote!({
        #(#access_control_gates)*
        #pipeline_checks
        #receipt_begin
        let mut __hopper_invariants_passed = true;
        let mut __hopper_invariants_checked: u16 = 0;
        let __hopper_result = (|| #original_block)();

        match __hopper_result {
            Ok(__hopper_value) => {
                let mut __hopper_modifier_error: ::core::option::Option<::hopper::__runtime::ProgramError> = None;
                #failure_info_decl
                #(#invariant_checks)*
                #receipt_finish
                if let ::core::option::Option::Some(__hopper_error) = __hopper_modifier_error {
                    Err(__hopper_error)
                } else {
                    Ok(__hopper_value)
                }
            }
            Err(__hopper_error) => Err(__hopper_error),
        }
    });

    Ok(())
}

fn context_ident(function: &ItemFn) -> Result<Ident> {
    let Some(first) = function.sig.inputs.first() else {
        return Err(syn::Error::new_spanned(
            &function.sig,
            "hopper_program handlers require a leading context parameter",
        ));
    };
    let FnArg::Typed(pat_type) = first else {
        return Err(syn::Error::new_spanned(
            first,
            "hopper_program handlers must use a simple context identifier when execution modifiers are present",
        ));
    };
    let Pat::Ident(ident) = pat_type.pat.as_ref() else {
        return Err(syn::Error::new_spanned(
            pat_type.pat.as_ref(),
            "execution modifiers require a simple identifier like `ctx` for the first parameter",
        ));
    };
    Ok(ident.ident.clone())
}

fn raw_context_expr(ctx_ident: &Ident, binding: &ContextBinding) -> TokenStream {
    match binding {
        ContextBinding::Raw => quote! { #ctx_ident },
        ContextBinding::Typed { .. } => quote! { #ctx_ident.raw() },
    }
}

fn attr_has_name(attr: &Attribute, name: &str) -> bool {
    attr.path()
        .segments
        .last()
        .map(|segment| segment.ident == name)
        .unwrap_or(false)
}

fn is_raw_context_ref(ty: &Type) -> bool {
    let Type::Reference(reference) = ty else {
        return false;
    };
    if reference.mutability.is_none() {
        return false;
    }
    is_context_path(reference.elem.as_ref())
}

fn is_context_path(ty: &Type) -> bool {
    matches!(
        ty,
        Type::Path(TypePath { qself: None, path })
            if path.segments.last().map(|segment| segment.ident == "Context" || segment.ident == "Ctx").unwrap_or(false)
    )
}

fn extract_typed_context_spec(ty: &Type) -> Result<Option<Path>> {
    let Type::Path(TypePath { qself: None, path }) = ty else {
        return Ok(None);
    };
    let Some(last) = path.segments.last() else {
        return Ok(None);
    };
    if last.ident != "Context" && last.ident != "Ctx" {
        return Ok(None);
    }

    let PathArguments::AngleBracketed(args) = &last.arguments else {
        return Err(syn::Error::new_spanned(
            last,
            "typed Hopper handlers use `Context<MyAccounts>` or `Ctx<MyAccounts>`",
        ));
    };

    let mut spec = None;
    for arg in &args.args {
        if let GenericArgument::Type(Type::Path(type_path)) = arg {
            if spec.is_some() {
                return Err(syn::Error::new_spanned(
                    arg,
                    "typed Hopper handlers accept exactly one context type argument",
                ));
            }
            spec = Some(type_path.path.clone());
        }
    }

    spec.map(Some).ok_or_else(|| {
        syn::Error::new_spanned(
            args,
            "typed Hopper handlers require a path type, e.g. `Context<Deposit>`",
        )
    })
}

fn bind_type_for(spec: &Path) -> Result<Type> {
    let mut bound = spec.clone();
    let Some(last) = bound.segments.last_mut() else {
        return Err(syn::Error::new_spanned(
            spec,
            "expected a concrete context type path",
        ));
    };
    last.arguments = PathArguments::None;
    last.ident = format_ident!("{}Ctx", last.ident);

    Ok(syn::parse_quote! { #bound<'_, '_> })
}

fn strip_context_type_args(mut spec: Path) -> Path {
    if let Some(last) = spec.segments.last_mut() {
        last.arguments = PathArguments::None;
    }
    spec
}

fn mark_pattern_mutable(pattern: &mut Box<Pat>) -> Result<()> {
    let Pat::Ident(ident) = pattern.as_mut() else {
        return Err(syn::Error::new_spanned(
            pattern.as_ref(),
            "typed Hopper context parameters must use a simple identifier pattern",
        ));
    };
    if ident.mutability.is_none() {
        ident.mutability = Some(Default::default());
    }
    Ok(())
}

/// Extract the discriminator plus any per-handler policy flags from
/// `#[instruction(N)]`, `#[instruction(discriminator = [0x1a, 0xf4])]`,
/// or either plus trailing `unsafe_memory` / `skip_token_checks` /
/// `allow_arbitrary_cpi` /
/// `ctx_args = K` levers.
///
/// Two discriminator forms are accepted:
///
/// - **Single byte.** `#[instruction(3)]` parses as a `u8` literal.
///   Dispatch emits a classic `match data[0]` so the compiler keeps
///   its jump-table optimization. This is the legacy shape and the
///   recommended one for programs with ≤256 instructions.
/// - **Multi-byte.** `#[instruction(discriminator = [0x1a, 0xf4, 0x3c, 0x2d])]`
///   parses as a byte-array literal (up to 8 bytes). Dispatch emits
///   a `data.starts_with(&[...])` chain ordered longest-prefix-first.
///   Used for Anchor-style 8-byte SHA-256 discriminators, namespaced
///   program ports, or any multi-program interop surface where a
///   single byte cannot be guaranteed unique across ABIs.
///
/// Returns the discriminator as `Vec<u8>` so both forms feed the
/// same downstream dispatch/codegen paths.
fn extract_instruction_attribute(
    attrs: &[Attribute],
) -> Result<Option<(Vec<u8>, InstructionPolicyArgs)>> {
    for attr in attrs {
        if !attr_has_name(attr, "instruction") {
            continue;
        }

        let tokens = match &attr.meta {
            syn::Meta::List(list) => list.tokens.clone(),
            _ => {
                return Err(syn::Error::new_spanned(
                    attr,
                    "hopper_program requires #[instruction(N, ...flags)] or #[instruction(discriminator = [bytes], ...flags)]",
                ));
            }
        };

        use syn::parse::{ParseStream, Parser};

        let parser = |input: ParseStream<'_>| -> Result<(Vec<u8>, InstructionPolicyArgs)> {
            // Peek to decide single-byte vs multi-byte form. A leading
            // `discriminator` identifier signals the array form; anything
            // else (integer literal, bare flag, nothing) falls through to
            // the single-byte / legacy path.
            let disc: Vec<u8> = if input.peek(syn::Ident)
                && input
                    .fork()
                    .parse::<Ident>()
                    .map(|i| i == "discriminator")
                    .unwrap_or(false)
            {
                let _: Ident = input.parse()?;
                let _: Token![=] = input.parse()?;
                let arr: syn::ExprArray = input.parse()?;
                if arr.elems.is_empty() {
                    return Err(syn::Error::new_spanned(
                        &arr,
                        "discriminator array must not be empty",
                    ));
                }
                if arr.elems.len() > 8 {
                    return Err(syn::Error::new_spanned(
                        &arr,
                        "discriminator array may be at most 8 bytes; longer prefixes cost CU at the dispatcher with no meaningful uniqueness benefit",
                    ));
                }
                let mut bytes = Vec::with_capacity(arr.elems.len());
                for elem in &arr.elems {
                    match elem {
                        Expr::Lit(ExprLit {
                            lit: Lit::Int(int), ..
                        }) => {
                            bytes.push(int.base10_parse::<u8>().map_err(|_| {
                                syn::Error::new_spanned(
                                    elem,
                                    "discriminator bytes must fit in u8 (0..=255)",
                                )
                            })?);
                        }
                        _ => {
                            return Err(syn::Error::new_spanned(
                                elem,
                                "discriminator array entries must be u8 integer literals",
                            ));
                        }
                    }
                }
                bytes
            } else {
                let disc_lit: Lit = input.parse()?;
                match disc_lit {
                    Lit::Int(lit_int) => vec![lit_int.base10_parse::<u8>()?],
                    other => {
                        return Err(syn::Error::new(
                            other.span(),
                            "instruction discriminator must be an integer literal or `discriminator = [bytes]`",
                        ));
                    }
                }
            };

            let mut policy = InstructionPolicyArgs::default();
            while input.peek(Token![,]) {
                input.parse::<Token![,]>()?;
                if input.is_empty() {
                    break;
                }
                let meta: Meta = input.parse()?;
                match meta {
                    Meta::Path(path) => match path_ident(&path)?.as_str() {
                        "unsafe_memory" => policy.unsafe_memory = true,
                        "skip_token_checks" => policy.skip_token_checks = true,
                        "allow_arbitrary_cpi" => policy.allow_arbitrary_cpi = true,
                        other => {
                            return Err(syn::Error::new(
                                path.span(),
                                format!(
                                    "unknown instruction policy flag `{other}`; expected `unsafe_memory`, `skip_token_checks`, `allow_arbitrary_cpi`, or `ctx_args = K`",
                                ),
                            ));
                        }
                    },
                    Meta::NameValue(nv) => {
                        let name = path_ident(&nv.path)?;
                        match name.as_str() {
                            "unsafe_memory" => {
                                policy.unsafe_memory = expect_bool_lit(&nv.value)?;
                            }
                            "skip_token_checks" => {
                                policy.skip_token_checks = expect_bool_lit(&nv.value)?;
                            }
                            "allow_arbitrary_cpi" => {
                                policy.allow_arbitrary_cpi = expect_bool_lit(&nv.value)?;
                            }
                            // `ctx_args = K`. forward the first K decoded
                            // instruction args to the typed context's
                            // `bind_with_args(...)`. A u8 cap matches the
                            // Hopper runtime's schema-wide 255-item limit
                            // (same cap as error variants) and sidesteps
                            // any argument-count collision with a huge
                            // handler signature.
                            "ctx_args" => {
                                let count = expect_u8_lit(&nv.value)?;
                                policy.ctx_args = count;
                            }
                            other => {
                                return Err(syn::Error::new(
                                    nv.path.span(),
                                    format!(
                                        "unknown instruction policy lever `{other}`; expected `unsafe_memory`, `skip_token_checks`, `allow_arbitrary_cpi`, or `ctx_args`",
                                    ),
                                ));
                            }
                        }
                    }
                    Meta::List(list) => {
                        return Err(syn::Error::new(
                            list.span(),
                            "instruction policy expects bare flags or `name = bool` pairs",
                        ));
                    }
                }
            }
            Ok((disc, policy))
        };

        let (disc, policy) = parser.parse2(tokens)?;
        return Ok(Some((disc, policy)));
    }
    Ok(None)
}

// ─────────────────────────────────────────────────────────────────────
// Regression tests for `#[instruction(N, ctx_args = K, ...)]` parsing
// and `handler_invocation` routing. These live in the proc-macro crate
// itself so they exercise `extract_instruction_attribute` /
// `handler_invocation` with real `syn` inputs, catching grammar-level
// regressions (parser rejects `ctx_args`, wrong error message shape,
// wrong bind target) before the framework-wide build ever runs.
// ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod ctx_args_tests {
    use super::*;
    use syn::parse_quote;

    fn extract(attr: Attribute) -> (Vec<u8>, InstructionPolicyArgs) {
        extract_instruction_attribute(&[attr])
            .expect("parse succeeded")
            .expect("attr present")
    }

    #[test]
    fn ctx_args_zero_is_default_when_absent() {
        let (disc, pol) = extract(parse_quote!(#[instruction(0)]));
        assert_eq!(disc, vec![0u8]);
        assert_eq!(pol.ctx_args, 0);
        assert!(!pol.unsafe_memory);
        assert!(!pol.skip_token_checks);
        assert!(!pol.allow_arbitrary_cpi);
    }

    #[test]
    fn single_byte_discriminator_becomes_one_element_vec() {
        let (disc, _) = extract(parse_quote!(#[instruction(42)]));
        assert_eq!(disc, vec![42u8]);
    }

    #[test]
    fn multi_byte_discriminator_parses_to_byte_vec() {
        let (disc, _) = extract(parse_quote!(
            #[instruction(discriminator = [0x1a, 0xf4, 0x3c, 0x2d])]
        ));
        assert_eq!(disc, vec![0x1a, 0xf4, 0x3c, 0x2d]);
    }

    #[test]
    fn multi_byte_rejects_empty_array() {
        let res = extract_instruction_attribute(&[parse_quote!(
            #[instruction(discriminator = [])]
        )]);
        let err = res.expect_err("empty array should error");
        assert!(err.to_string().contains("empty"));
    }

    #[test]
    fn multi_byte_rejects_oversize_array() {
        let res = extract_instruction_attribute(&[parse_quote!(
            #[instruction(discriminator = [1, 2, 3, 4, 5, 6, 7, 8, 9])]
        )]);
        let err = res.expect_err("9-byte array should error");
        assert!(err.to_string().contains("8 bytes"));
    }

    #[test]
    fn multi_byte_accepts_flags_after_array() {
        let (disc, pol) = extract(parse_quote!(
            #[instruction(discriminator = [0xde, 0xad, 0xbe, 0xef], unsafe_memory, ctx_args = 1)]
        ));
        assert_eq!(disc, vec![0xde, 0xad, 0xbe, 0xef]);
        assert!(pol.unsafe_memory);
        assert_eq!(pol.ctx_args, 1);
    }

    #[test]
    fn ctx_args_is_threaded_from_attribute() {
        let (_, pol) = extract(parse_quote!(#[instruction(1, ctx_args = 2)]));
        assert_eq!(pol.ctx_args, 2);
    }

    #[test]
    fn ctx_args_coexists_with_other_flags() {
        let (_, pol) = extract(parse_quote!(
            #[instruction(3, unsafe_memory, ctx_args = 1, skip_token_checks, allow_arbitrary_cpi)]
        ));
        assert!(pol.unsafe_memory);
        assert!(pol.skip_token_checks);
        assert!(pol.allow_arbitrary_cpi);
        assert_eq!(pol.ctx_args, 1);
    }

    #[test]
    fn arbitrary_cpi_flag_accepts_name_value_form() {
        let (_, pol) = extract(parse_quote!(
            #[instruction(7, allow_arbitrary_cpi = true)]
        ));
        assert!(pol.allow_arbitrary_cpi);

        let (_, pol) = extract(parse_quote!(
            #[instruction(8, allow_arbitrary_cpi = false)]
        ));
        assert!(!pol.allow_arbitrary_cpi);
    }

    #[test]
    fn ctx_args_rejects_non_integer_literal() {
        let result =
            extract_instruction_attribute(&[parse_quote!(#[instruction(0, ctx_args = "two")])]);
        let err = result.expect_err("should reject string literal");
        let msg = err.to_string();
        assert!(
            msg.contains("integer literal"),
            "unexpected error message: {msg}",
        );
    }

    #[test]
    fn ctx_args_rejects_u8_overflow() {
        let result =
            extract_instruction_attribute(&[parse_quote!(#[instruction(0, ctx_args = 256)])]);
        let err = result.expect_err("should reject 256");
        let msg = err.to_string();
        assert!(msg.contains("u8"), "unexpected error message: {msg}");
    }

    #[test]
    fn unknown_flag_lists_ctx_args_in_suggestion() {
        let result =
            extract_instruction_attribute(&[parse_quote!(#[instruction(0, unknown_flag)])]);
        let err = result.expect_err("should reject unknown flag");
        let msg = err.to_string();
        assert!(
            msg.contains("ctx_args"),
            "diagnostic must mention ctx_args: {msg}",
        );
    }

    // Parse a handler function body end-to-end through `prepare_handler`
    // to verify the combined ctx_args + typed context validation path.
    fn run_prepare(mut function: syn::ItemFn) -> Result<Handler> {
        prepare_handler(&mut function, false).map(|o| o.expect("handler discovered"))
    }

    #[test]
    fn ctx_args_without_typed_context_errors_clearly() {
        let f: syn::ItemFn = parse_quote! {
            #[instruction(0, ctx_args = 1)]
            fn handler(ctx: &mut Context<'_>, amount: u64) -> ProgramResult { Ok(()) }
        };
        let err = run_prepare(f).expect_err("should reject raw context + ctx_args");
        let msg = err.to_string();
        assert!(msg.contains("typed"), "want 'typed' in error: {msg}");
    }

    #[test]
    fn ctx_args_exceeding_arity_errors_clearly() {
        let f: syn::ItemFn = parse_quote! {
            #[instruction(0, ctx_args = 3)]
            fn handler(ctx: Context<Swap>, amount: u64) -> ProgramResult { Ok(()) }
        };
        let err = run_prepare(f).expect_err("should reject ctx_args > arity");
        let msg = err.to_string();
        assert!(msg.contains("exceeds"), "want 'exceeds' in error: {msg}");
    }

    #[test]
    fn ctx_args_valid_typed_context_builds() {
        let f: syn::ItemFn = parse_quote! {
            #[instruction(0, ctx_args = 2)]
            fn handler(ctx: Context<Swap>, amount: u64, nonce: u8) -> ProgramResult { Ok(()) }
        };
        let h = run_prepare(f).expect("should accept typed context + matching ctx_args");
        assert_eq!(h.instruction_policy.ctx_args, 2);
        assert!(matches!(h.binding, ContextBinding::Typed { .. }));
        assert_eq!(h.arg_types.len(), 2);
    }

    #[test]
    fn handler_invocation_threads_ctx_args_to_bind_with_args() {
        let h = Handler {
            discriminator: vec![0u8],
            fn_name: format_ident!("swap"),
            binding: ContextBinding::Typed {
                spec: parse_quote!(Swap),
            },
            arg_names: vec!["amount".into(), "nonce".into(), "flag".into()],
            arg_types: vec![
                parse_quote!(u64),
                parse_quote!(u8),
                parse_quote!(::core::primitive::bool),
            ],
            receipt: false,
            remaining_accounts_max: None,
            instruction_policy: InstructionPolicyArgs {
                unsafe_memory: false,
                skip_token_checks: false,
                allow_arbitrary_cpi: false,
                ctx_args: 2,
            },
        };
        let raw = handler_invocation(&h).to_string();
        // Normalize whitespace. `quote`'s pretty-printer inserts spaces
        // between every token, so raw `.contains` against a readable
        // snippet is brittle. We collapse runs of whitespace and drop
        // space around grouping punctuation before substring-matching
        // the semantic shape.
        let out: String = raw
            .split_whitespace()
            .collect::<Vec<_>>()
            .join(" ")
            .replace(" (", "(")
            .replace("( ", "(")
            .replace(" )", ")")
            .replace(") ", ")")
            .replace(" ,", ",")
            .replace(", ", ",")
            .replace(" ::", "::")
            .replace(":: ", "::");

        assert!(
            out.contains("Swap::bind_with_args(ctx,__hopper_arg_0,__hopper_arg_1)?"),
            "missing bind_with_args call: {out}",
        );
        assert!(out.contains("swap("), "handler name should appear: {out}");
        assert!(
            out.contains("__hopper_arg_2"),
            "third arg should reach handler: {out}",
        );
        // Extra belt-and-suspenders: the legacy bind(ctx)? MUST NOT
        // appear here. that would silently bypass the args-aware
        // validation path.
        assert!(
            !out.contains("Swap::bind(ctx)"),
            "legacy bind(ctx)? should not appear alongside ctx_args: {out}",
        );
    }

    #[test]
    fn handler_invocation_without_ctx_args_preserves_legacy_bind() {
        let h = Handler {
            discriminator: vec![0u8],
            fn_name: format_ident!("deposit"),
            binding: ContextBinding::Typed {
                spec: parse_quote!(Deposit),
            },
            arg_names: vec!["amount".into()],
            arg_types: vec![parse_quote!(u64)],
            receipt: false,
            remaining_accounts_max: None,
            instruction_policy: InstructionPolicyArgs::default(),
        };
        let raw = handler_invocation(&h).to_string();
        let out: String = raw
            .split_whitespace()
            .collect::<Vec<_>>()
            .join(" ")
            .replace(" (", "(")
            .replace("( ", "(")
            .replace(" )", ")")
            .replace(") ", ")")
            .replace(" ,", ",")
            .replace(" ::", "::")
            .replace(":: ", "::");

        assert!(
            out.contains("Deposit::bind(ctx)?"),
            "legacy bind should still be used when ctx_args = 0: {out}",
        );
        assert!(
            !out.contains("bind_with_args"),
            "bind_with_args must not appear when ctx_args = 0: {out}",
        );
    }

    #[test]
    fn handler_invocation_raw_ctx_never_calls_bind() {
        let h = Handler {
            discriminator: vec![0u8],
            fn_name: format_ident!("raw"),
            binding: ContextBinding::Raw,
            arg_names: vec![],
            arg_types: vec![],
            receipt: false,
            remaining_accounts_max: None,
            instruction_policy: InstructionPolicyArgs::default(),
        };
        let out = handler_invocation(&h).to_string();
        assert!(
            !out.contains("bind"),
            "raw ctx handler must not reference any bind*: {out}",
        );
        assert!(
            out.contains("raw (ctx)"),
            "raw ctx dispatch expected: {out}"
        );
    }

    /// Token-per-space normalization so structural assertions are stable
    /// against `quote`'s pretty-printer spacing.
    fn tokens(ts: TokenStream) -> String {
        ts.to_string()
            .split_whitespace()
            .collect::<Vec<_>>()
            .join(" ")
    }

    /// touch-map regression (failed-instruction emission regression fix): an args-less TYPED handler emits
    /// the self-describing touch-map finish call on the **Ok path only**.
    /// The generated shape runs `handler(Spec::bind(ctx)?)?` first, so any
    /// `Err` short-circuits via `?` BEFORE the const-guarded
    /// `finish_with_touch_map()`, a failed instruction emits nothing.
    /// The guard is `if Spec::EMIT_TOUCH_MAP { ... }`, a `const` the
    /// compiler dead-code-eliminates when the context did not opt in.
    #[test]
    fn handler_invocation_argless_typed_emits_ok_only_touch_map() {
        let h = Handler {
            discriminator: vec![0u8],
            fn_name: format_ident!("report"),
            binding: ContextBinding::Typed {
                spec: parse_quote!(Report),
            },
            arg_names: vec![],
            arg_types: vec![],
            receipt: false,
            remaining_accounts_max: None,
            instruction_policy: InstructionPolicyArgs::default(),
        };
        let out = tokens(handler_invocation(&h));
        // One substring pins the whole ordering: the handler's `?`
        // (Err short-circuit) precedes the const-guarded finish, which
        // precedes the final `Ok(())`.
        assert!(
            out.contains(
                "? ; if Report :: EMIT_TOUCH_MAP { ctx . finish_with_touch_map () ; } \
                 :: core :: result :: Result :: Ok (())"
            ),
            "args-less typed handler must emit the Ok-only, const-guarded touch map: {out}",
        );
    }

    /// The same Ok-only shape for the args + `bind_with_args` form (the
    /// typed-context sugar with `ctx_args`): the finish call still lands
    /// after `handler(...)?`, guarded by the const, before `Ok(())`.
    #[test]
    fn handler_invocation_with_args_emits_ok_only_touch_map() {
        let h = Handler {
            discriminator: vec![0u8],
            fn_name: format_ident!("swap"),
            binding: ContextBinding::Typed {
                spec: parse_quote!(Swap),
            },
            arg_names: vec!["amount".into(), "nonce".into()],
            arg_types: vec![parse_quote!(u64), parse_quote!(u8)],
            receipt: false,
            remaining_accounts_max: None,
            instruction_policy: InstructionPolicyArgs {
                unsafe_memory: false,
                skip_token_checks: false,
                allow_arbitrary_cpi: false,
                ctx_args: 2,
            },
        };
        let out = tokens(handler_invocation(&h));
        assert!(
            out.contains(
                ") ? ; if Swap :: EMIT_TOUCH_MAP { ctx . finish_with_touch_map () ; } \
                 :: core :: result :: Result :: Ok (())"
            ),
            "with-args typed handler must emit the Ok-only, const-guarded touch map: {out}",
        );
    }

    /// A RAW `&mut Context<'_>` handler has no typed context spec to name,
    /// so it can consult no `EMIT_TOUCH_MAP` const and must emit no touch
    /// map; this form simply never self-describes. Its codegen also stays
    /// byte-for-byte the prior tail expression.
    #[test]
    fn handler_invocation_raw_never_emits_touch_map() {
        let argless = Handler {
            discriminator: vec![0u8],
            fn_name: format_ident!("raw0"),
            binding: ContextBinding::Raw,
            arg_names: vec![],
            arg_types: vec![],
            receipt: false,
            remaining_accounts_max: None,
            instruction_policy: InstructionPolicyArgs::default(),
        };
        let with_args = Handler {
            discriminator: vec![0u8],
            fn_name: format_ident!("raw1"),
            binding: ContextBinding::Raw,
            arg_names: vec!["amount".into()],
            arg_types: vec![parse_quote!(u64)],
            receipt: false,
            remaining_accounts_max: None,
            instruction_policy: InstructionPolicyArgs::default(),
        };
        for h in [argless, with_args] {
            let out = handler_invocation(&h).to_string();
            assert!(
                !out.contains("EMIT_TOUCH_MAP"),
                "raw ctx handler must not consult a touch-map const: {out}",
            );
            assert!(
                !out.contains("finish_with_touch_map"),
                "raw ctx handler must not emit a touch map: {out}",
            );
        }
    }
}

// ─────────────────────────────────────────────────────────────────────
// Macro-expansion tests for the fn-pointer-table dispatch fast path
// (`profile = "tiny"` + contiguous single-byte discriminators 0..=N-1).
// These drive `expand` end-to-end with real module token streams and
// substring-match the normalized output, so a regression in the
// eligibility predicate (table emitted for a gappy range, or the match
// silently replaced outside tiny) fails here before any consumer crate
// builds.
// ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod dispatch_table_tests {
    use super::*;

    /// Expand `#[hopper_program(#attr)] mod ...` and normalize the
    /// token-stream string the same way the ctx_args tests do, so
    /// substring assertions are stable against `quote`'s spacing.
    fn expand_normalized(attr: TokenStream, module: TokenStream) -> String {
        let raw = expand(attr, module)
            .expect("program expansion should succeed")
            .to_string();
        raw.split_whitespace()
            .collect::<Vec<_>>()
            .join(" ")
            .replace(" (", "(")
            .replace("( ", "(")
            .replace(" )", ")")
            .replace(") ", ")")
            .replace(" [", "[")
            .replace("[ ", "[")
            .replace(" ]", "]")
            .replace("] ", "]")
            .replace(" ,", ",")
            .replace(", ", ",")
            .replace(" ::", "::")
            .replace(":: ", "::")
            .replace(" .", ".")
            .replace(". ", ".")
    }

    #[test]
    fn tiny_profile_emits_the_count_exact_entrypoint() {
        // Token-level comparison: strip every space so the check does not
        // depend on how the token stream is printed.
        fn compact(out: &str) -> String {
            out.chars().filter(|c| !c.is_whitespace()).collect()
        }
        // A typed handler contributes its context's `ACCOUNT_COUNT`, a raw
        // handler the transaction maximum (or `max_accounts`), and a handler
        // with a declared remaining-account ceiling adds it to the bound.
        let out = compact(&expand_normalized(
            quote!(profile = "tiny"),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn typed(ctx: Ctx<Deposit>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn raw(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(2)]
                    #[remaining_accounts(max = 4)]
                    fn extras(ctx: Ctx<Sweep>) -> ProgramResult { Ok(()) }
                }
            },
        ));
        assert!(
            out.contains("hopper_exact_entrypoint!{"),
            "tiny profile must use the count-exact entrypoint: {out}"
        );
        assert!(
            out.contains("(0u8,<Deposit>::ACCOUNT_COUNT,vault::__hopper_exact_typed)"),
            "typed arm carries the context bound: {out}"
        );
        assert!(
            out.contains("(1u8,::hopper::__runtime::MAX_TX_ACCOUNTS,vault::__hopper_exact_raw)"),
            "raw arm keeps the transaction maximum: {out}"
        );
        assert!(
            out.contains("(2u8,<Sweep>::ACCOUNT_COUNT+(4),vault::__hopper_exact_extras)"),
            "declared remaining accounts widen the bound: {out}"
        );
        assert!(
            !out.contains("fast_entrypoint!"),
            "the scanning entrypoint must not also be emitted: {out}"
        );

        // `max_accounts` bounds only the raw arm on this path.
        let out = compact(&expand_normalized(
            quote!(profile = "tiny", max_accounts = 7),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn raw(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        ));
        assert!(
            out.contains("(0u8,7usize,vault::__hopper_exact_raw)"),
            "raw arm takes max_accounts: {out}"
        );

        // The other profiles keep the scanning entrypoint and the bridge.
        let out = compact(&expand_normalized(
            quote!(),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn typed(ctx: Ctx<Deposit>) -> ProgramResult { Ok(()) }
                }
            },
        ));
        assert!(out.contains("fast_entrypoint!"), "{out}");
        assert!(!out.contains("hopper_exact_entrypoint!"), "{out}");
    }

    #[test]
    fn contiguous_tiny_emits_fn_pointer_table() {
        // 8 arms: exactly the MIN_TABLE_DISPATCH_ARMS threshold, where the
        // indirect-call setup starts beating the compare ladder.
        let out = expand_normalized(
            quote!(profile = "tiny", entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn i0(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn i1(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(2)]
                    fn i2(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(3)]
                    fn i3(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(4)]
                    fn i4(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(5)]
                    fn i5(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(6)]
                    fn i6(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(7)]
                    fn i7(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("static __HOPPER_DISPATCH_TABLE"),
            "contiguous tiny should emit the dispatch table: {out}",
        );
        assert!(
            !out.contains("match data[0"),
            "contiguous tiny must not fall back to the match ladder: {out}",
        );
        // Bounds check + empty-data check preserve error semantics.
        assert!(
            out.contains("if data.is_empty()"),
            "empty-data guard must survive: {out}",
        );
        assert!(
            out.contains("if __hopper_disc >= 8usize"),
            "unknown-discriminator bounds check must gate the table: {out}",
        );
        assert!(
            out.contains("__HOPPER_DISPATCH_TABLE[__hopper_disc](ctx,data)"),
            "indirect call through the table expected: {out}",
        );
    }

    #[test]
    fn table_entries_are_ordered_by_discriminator_not_declaration() {
        // `beta` is declared first but carries discriminator 1;
        // `alpha` carries 0. Slot i of the table must be disc i.
        let out = expand_normalized(
            quote!(profile = "tiny", entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(1)]
                    fn beta(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(0)]
                    fn alpha(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(2)]
                    fn f2(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(3)]
                    fn f3(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(4)]
                    fn f4(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(5)]
                    fn f5(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(6)]
                    fn f6(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(7)]
                    fn f7(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("[__hopper_dispatch_alpha,__hopper_dispatch_beta,"),
            "table slots must follow discriminator order: {out}",
        );
    }

    #[test]
    fn small_dispatch_tiny_keeps_match_below_threshold() {
        // Below MIN_TABLE_DISPATCH_ARMS the compare ladder is cheaper than
        // the callx setup (CU-path audit 2026-07-07: predicted +8..13 CU
        // regression for tiny N), so small programs keep the match.
        let out = expand_normalized(
            quote!(profile = "tiny", entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn only(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            !out.contains("static __HOPPER_DISPATCH_TABLE"),
            "N=1 must not pay the fn-pointer table: {out}",
        );
    }

    #[test]
    fn non_contiguous_tiny_falls_back_to_match() {
        let out = expand_normalized(
            quote!(profile = "tiny", entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn initialize(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(2)]
                    fn withdraw(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            !out.contains("__HOPPER_DISPATCH_TABLE"),
            "gappy discriminators must not get a table: {out}",
        );
        assert!(
            out.contains("match data[0]"),
            "gappy tiny keeps the match dispatch: {out}",
        );
    }

    #[test]
    fn tiny_range_not_starting_at_zero_falls_back_to_match() {
        let out = expand_normalized(
            quote!(profile = "tiny", entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(1)]
                    fn first(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(2)]
                    fn second(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            !out.contains("__HOPPER_DISPATCH_TABLE"),
            "range 1..=2 does not start at 0 and must not get a table: {out}",
        );
        assert!(
            out.contains("match data[0]"),
            "offset tiny range keeps the match dispatch: {out}",
        );
    }

    #[test]
    fn contiguous_non_tiny_profile_keeps_match() {
        for attr in [
            quote!(entrypoint = false),
            quote!(profile = "strict", entrypoint = false),
            quote!(profile = "audit", entrypoint = false),
            quote!(profile = "raw", entrypoint = false),
        ] {
            let out = expand_normalized(
                attr,
                quote! {
                    mod vault {
                        #[instruction(0)]
                        fn initialize(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                        #[instruction(1)]
                        fn deposit(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    }
                },
            );
            assert!(
                !out.contains("__HOPPER_DISPATCH_TABLE"),
                "only profile = \"tiny\" opts into the table: {out}",
            );
            assert!(
                out.contains("match data[0]"),
                "non-tiny single-byte keeps the match dispatch: {out}",
            );
        }
    }

    #[test]
    fn multi_byte_non_tiny_keeps_prefix_chain() {
        // Multi-byte discriminators are rejected under tiny, so the
        // table interplay only needs checking on the default profile:
        // the starts_with chain must be untouched.
        let out = expand_normalized(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(discriminator = [0x1a, 0xf4])]
                    fn ported(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(5)]
                    fn native(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            !out.contains("__HOPPER_DISPATCH_TABLE"),
            "multi-byte programs never get the table: {out}",
        );
        assert!(
            out.contains("data.starts_with"),
            "multi-byte keeps the prefix chain: {out}",
        );
    }

    #[test]
    fn table_dispatch_preserves_argument_decoding_helpers() {
        // The table stores the same `__hopper_dispatch_*` helpers the
        // match arms call, so arg decoding stays inside the helpers.
        let out = expand_normalized(
            quote!(profile = "tiny", entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn initialize(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn deposit(ctx: &mut Context<'_>, amount: u64) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("fn __hopper_dispatch_deposit"),
            "helper fns must still be emitted: {out}",
        );
        assert!(
            out.contains("DecodeInstructionArg"),
            "arg decoding must still run inside the helper: {out}",
        );
    }

    // ── Self-CPI event sink (`event_cpi`) dispatch integration ─────────

    /// A program with typed handlers arms the const-guarded event sink:
    /// the `__HOPPER_EVENT_CPI_ENABLED` OR over its context specs, the
    /// sink helper delegating to the runtime's authenticated
    /// `handle_event_sink`, and a `0xE0` match arm ahead of the
    /// fallthrough. The user arms are untouched.
    #[test]
    fn typed_handler_program_arms_the_event_sink_in_the_match_form() {
        let out = expand_normalized(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn init(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn poke(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("pub const __HOPPER_EVENT_CPI_ENABLED : bool = false || Init::EVENT_CPI"),
            "the enable const must OR the typed specs' EVENT_CPI: {out}",
        );
        assert!(
            out.contains("fn __hopper_dispatch_event_sink"),
            "the sink helper must be emitted: {out}",
        );
        assert!(
            out.contains("0xE0u8 => __hopper_dispatch_event_sink(ctx,data)"),
            "the match form must gain the marker arm: {out}",
        );
        assert!(
            out.contains("cpi_event::handle_event_sink(ctx,data)"),
            "the sink must delegate to the runtime's authenticated handler: {out}",
        );
        assert!(
            out.contains("if ! __HOPPER_EVENT_CPI_ENABLED"),
            "the sink must be const-guarded so non-participating programs fold it away: {out}",
        );
    }

    /// A program whose handlers are all raw `&mut Context<'_>` has no
    /// typed spec to consult: NOTHING event-sink-related is emitted and
    /// the dispatch output stays byte-identical to the pre-feature
    /// shape (raw programs keep the documented manual-sentinel path).
    #[test]
    fn raw_only_program_emits_no_event_sink_plumbing() {
        let out = expand_normalized(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn initialize(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn deposit(ctx: &mut Context<'_>, amount: u64) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            !out.contains("__HOPPER_EVENT_CPI_ENABLED"),
            "raw-only programs must not emit the enable const: {out}",
        );
        assert!(
            !out.contains("event_sink") && !out.contains("0xE0"),
            "raw-only programs must not emit any sink arm or helper: {out}",
        );
    }

    /// Two handlers binding the same context spec consult its
    /// `EVENT_CPI` const exactly once in the OR chain.
    #[test]
    fn shared_context_spec_is_consulted_once() {
        let out = expand_normalized(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn first(ctx: Context<Shared>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn second(ctx: Context<Shared>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert_eq!(
            out.matches("Shared::EVENT_CPI").count(),
            1,
            "a spec bound by several handlers must appear once in the OR: {out}",
        );
    }

    /// The tiny fn-pointer table keeps its shape; the marker check rides
    /// the existing bounds-miss branch (0xE0 = 224 is always >= a
    /// sink-eligible table's length), so real instructions pay nothing.
    #[test]
    fn tiny_table_program_checks_the_marker_in_the_bounds_miss_branch() {
        let out = expand_normalized(
            quote!(profile = "tiny", entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn i0(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn i1(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                    #[instruction(2)]
                    fn i2(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                    #[instruction(3)]
                    fn i3(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                    #[instruction(4)]
                    fn i4(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                    #[instruction(5)]
                    fn i5(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                    #[instruction(6)]
                    fn i6(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                    #[instruction(7)]
                    fn i7(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("static __HOPPER_DISPATCH_TABLE"),
            "the fn-pointer table must survive the sink integration: {out}",
        );
        assert!(
            out.contains(
                "if __hopper_disc == 0xE0usize { return __hopper_dispatch_event_sink(ctx,data); }"
            ),
            "the marker check must live inside the >= bounds-miss branch: {out}",
        );
    }

    /// Multi-byte programs get the sink as one more prefix test after
    /// every user arm in the starts_with chain.
    #[test]
    fn multi_byte_typed_program_appends_the_chain_sink() {
        let out = expand_normalized(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(discriminator = [0x1a, 0xf4])]
                    fn ported(ctx: Context<Ported>) -> ProgramResult { Ok(()) }
                    #[instruction(5)]
                    fn native(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("if data.starts_with(&[0xE0u8,0x1Eu8])"),
            "the chain form must append the marker prefix test: {out}",
        );
        assert!(
            out.contains("fn __hopper_dispatch_event_sink"),
            "the sink helper must be emitted for the chain form: {out}",
        );
    }

    /// A user discriminator colliding with the reserved marker lowers to
    /// a const-assert that fires only when a bound context actually
    /// opted in; the sink arm itself is withheld so the user's
    /// instruction keeps its bytes when nothing opted in.
    #[test]
    fn marker_colliding_discriminator_lowers_to_a_const_assert() {
        let out = expand_normalized(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn init(ctx: Context<Init>) -> ProgramResult { Ok(()) }
                    #[instruction(224)]
                    fn legacy(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("__HOPPER_EVENT_CPI_ENABLED"),
            "the enable const must still be emitted for the assert to consult: {out}",
        );
        assert!(
            out.contains("renumber the instruction"),
            "the collision must lower to a const-assert with a pointed message: {out}",
        );
        assert!(
            !out.contains("fn __hopper_dispatch_event_sink"),
            "a colliding program must not emit the (shadowed) sink helper: {out}",
        );
        assert!(
            !out.contains("0xE0u8 => "),
            "a colliding program must not gain a marker arm: {out}",
        );
    }
}

// ─────────────────────────────────────────────────────────────────────
// Macro-expansion tests for the manifest schema statics (Phase B):
// `__HOPPER_INSTRUCTION_DESCRIPTORS` / `__HOPPER_CONTEXT_DESCRIPTORS`
// plus the per-handler const-eval account conversion. Pins match the
// space-stripped expansion (the same normalization the state-macro
// tests use), so a regression in the emission shape fails here before
// any consumer crate builds.
// ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod manifest_statics_tests {
    use super::*;

    /// Space-stripped expansion: exact-token pins without `quote`
    /// pretty-printer spacing noise.
    fn expand_spaceless(attr: TokenStream, module: TokenStream) -> String {
        expand(attr, module)
            .expect("program expansion should succeed")
            .to_string()
            .replace(char::is_whitespace, "")
    }

    fn two_handler_program() -> String {
        expand_spaceless(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn initialize(ctx: Ctx<Initialize>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn deposit(ctx: Ctx<Deposit>, amount: u64) -> ProgramResult { Ok(()) }
                }
            },
        )
    }

    #[test]
    fn typed_handlers_emit_one_instruction_row_each_in_tag_order() {
        let out = two_handler_program();
        assert!(
            out.contains(
                "pubstatic__HOPPER_INSTRUCTION_DESCRIPTORS:\
                 &[::hopper::hopper_schema::InstructionDescriptor]=&["
            ),
            "the instruction static must be emitted: {out}",
        );
        let init_pos = out
            .find("name:\"initialize\",tag:0u8")
            .expect("initialize row present");
        let deposit_pos = out
            .find("name:\"deposit\",tag:1u8")
            .expect("deposit row present");
        assert!(
            init_pos < deposit_pos,
            "instruction rows must be in dispatch (tag) order: {out}",
        );
    }

    #[test]
    fn account_conversion_uses_the_module_level_len_const_copy_loop() {
        let out = two_handler_program();
        // Length const at module level, fed by the spec's own
        // SCHEMA_METADATA, no small-literal assumptions anywhere, so
        // composed/optional/event_cpi contexts of any flattened length
        // convert unchanged.
        assert!(
            out.contains(
                "pubconst__HOPPER_IX_initialize_ACCOUNTS_LEN:usize=\
                 Initialize::SCHEMA_METADATA.accounts.len();"
            ),
            "module-level LEN const expected: {out}",
        );
        // The converted array is sized by that const and filled by a
        // const-eval while-loop copying every public account-contract column.
        assert!(
            out.contains(
                "[::hopper::hopper_schema::AccountEntry;__HOPPER_IX_initialize_ACCOUNTS_LEN]"
            ),
            "array length must route through the LEN const: {out}",
        );
        assert!(
            out.contains("::hopper::hopper_schema::AccountEntry::PROVIDED"),
            "fill seed must be the PROVIDED constructor: {out}",
        );
        for column in [
            "name:__src[__i].name",
            "writable:__src[__i].writable",
            "signer:__src[__i].signer",
            "layout_ref:__src[__i].layout_ref",
            "seeds:__src[__i].seeds",
        ] {
            assert!(
                out.contains(column),
                "conversion loop must carry `{column}`: {out}",
            );
        }
        assert!(
            out.contains("while__i<__src.len()"),
            "conversion must be a const-eval copy loop: {out}",
        );
    }

    #[test]
    fn instruction_rows_wire_spec_consts_and_never_fabricate() {
        let out = two_handler_program();
        for wired in [
            "receipt_expected:false",
            "strict_writes:Deposit::STRICT_WRITES",
            "write_ranges:Deposit::WRITE_RANGES",
            "mutation_complete:Deposit::MUTATION_COMPLETE",
            "lamport_accounts:Deposit::LAMPORT_ACCOUNTS",
            "cu_estimate:0",
            "capabilities:&[]",
            "policy_pack:\"\"",
        ] {
            assert!(
                out.contains(wired),
                "instruction row must wire `{wired}`: {out}",
            );
        }
    }

    /// `receipt_expected` is the HANDLER's `#[receipt]` opt-in, the
    /// context-level `RECEIPT_EXPECTED` const (true for any context
    /// with a mutable account) must NOT back the column, or every
    /// mutating instruction would falsely claim a receipt.
    #[test]
    fn handler_receipt_modifier_publishes_receipt_expected_true() {
        let out = expand_spaceless(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    #[receipt]
                    fn settle(ctx: Ctx<Settle>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("name:\"settle\",tag:0u8"),
            "settle row expected: {out}",
        );
        assert!(
            out.contains("receipt_expected:true"),
            "#[receipt] handlers must publish receipt_expected = true: {out}",
        );
        assert!(
            !out.contains("RECEIPT_EXPECTED"),
            "the context-level capability const must not back the column: {out}",
        );
    }

    #[test]
    fn typed_args_publish_real_names_types_and_decoder_metadata() {
        let out = expand_spaceless(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn swap(
                        ctx: Ctx<Swap>,
                        amount: u64,
                        memo: [u8; 12],
                        blob: &[u8],
                    ) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains(
                "::hopper::hopper_schema::ArgDescriptor{\
                 name:\"amount\",canonical_type:\"u64\",size:{\
                 letsize=<u64as::hopper::__macro_support::DecodeInstructionArg>::WIRE_SIZE;"
            ),
            "u64 arg must use its decoder's wire size: {out}",
        );
        assert!(
            out.contains(
                "name:\"memo\",canonical_type:\"[u8;12]\",\
                 size:{letsize=<[u8;12]as::hopper::__macro_support::DecodeInstructionArg>::WIRE_SIZE;"
            ),
            "byte-array arg must use its decoder's wire size: {out}",
        );
        for ty in ["u64", "[u8;12]"] {
            assert!(
                out.contains(&format!(
                    "encoding:<{ty}as::hopper::__macro_support::DecodeInstructionArg>::ENCODING"
                )),
                "argument encoding must come from the same decoder as its size: {out}",
            );
        }
        assert!(
            out.contains("assert!(size<=u16::MAXasusize,"),
            "manifest sizes must reject overflow before narrowing: {out}",
        );
        // Variable-length args are UNKNOWN: size 0, never fabricated.
        assert!(
            out.contains(
                "name:\"blob\",canonical_type:\"&[u8]\",size:0u16,\
                 encoding:::hopper::hopper_schema::ArgEncoding::Fixed"
            ),
            "variable-length arg must publish size 0: {out}",
        );
    }

    #[test]
    fn raw_handlers_publish_no_instruction_row() {
        let out = expand_spaceless(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn typed(ctx: Ctx<Typed>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn raw(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("name:\"typed\""),
            "typed handler row expected: {out}",
        );
        assert!(
            !out.contains("name:\"raw\""),
            "raw handlers are opaque and must publish no row: {out}",
        );
        // Exactly three consultations of the typed spec's metadata: the
        // LEN const, the copy-loop source, and the context static. The
        // raw handler contributes none.
        assert_eq!(
            out.matches("Typed::SCHEMA_METADATA").count(),
            3,
            "only the typed spec's SCHEMA_METADATA may be consulted: {out}",
        );
    }

    #[test]
    fn context_descriptors_deduplicate_shared_specs() {
        let out = expand_spaceless(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn first(ctx: Ctx<Shared>) -> ProgramResult { Ok(()) }
                    #[instruction(1)]
                    fn second(ctx: Ctx<Shared>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains(
                "pubstatic__HOPPER_CONTEXT_DESCRIPTORS:\
                 &[::hopper::hopper_schema::accounts::ContextDescriptor]=\
                 &[::hopper::hopper_schema::accounts::ContextDescriptor{\
                 instructions:&[\"first\",\"second\"],..Shared::SCHEMA_METADATA}];"
            ),
            "shared spec must appear exactly once in the context static, naming both handlers: {out}",
        );
    }

    #[test]
    fn multi_byte_discriminator_publishes_byte_zero_as_tag() {
        let out = expand_spaceless(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(discriminator = [0x1a, 0xf4])]
                    fn ported(ctx: Ctx<Ported>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains("name:\"ported\",tag:26u8"),
            "multi-byte disc must publish byte 0 (0x1a = 26) as tag: {out}",
        );
    }

    #[test]
    fn raw_only_program_still_exports_empty_statics() {
        let out = expand_spaceless(
            quote!(entrypoint = false),
            quote! {
                mod vault {
                    #[instruction(0)]
                    fn only(ctx: &mut Context<'_>) -> ProgramResult { Ok(()) }
                }
            },
        );
        assert!(
            out.contains(
                "pubstatic__HOPPER_INSTRUCTION_DESCRIPTORS:\
                 &[::hopper::hopper_schema::InstructionDescriptor]=&[];"
            ),
            "raw-only programs export an empty instruction table: {out}",
        );
        assert!(
            out.contains(
                "pubstatic__HOPPER_CONTEXT_DESCRIPTORS:\
                 &[::hopper::hopper_schema::accounts::ContextDescriptor]=&[];"
            ),
            "raw-only programs export an empty context table: {out}",
        );
    }

    #[test]
    fn arg_wire_size_table_is_honest() {
        // Fixed-size entries.
        for (ty, size) in [
            (quote!(u8), 1u16),
            (quote!(bool), 1),
            (quote!(WireBool), 1),
            (quote!(i16), 2),
            (quote!(u32), 4),
            (quote!(WireI32), 4),
            (quote!(u64), 8),
            (quote!(WireU64), 8),
            (quote!(u128), 16),
            (quote!(Address), 32),
            (quote!(Pubkey), 32),
            (quote!(hopper::prelude::Address), 32),
            (quote!(TypedAddress<Authority>), 32),
            (quote!([u8; 32]), 32),
            (quote!(&[u8; 12]), 12),
            (quote!([u16; 4]), 8),
        ] {
            let parsed: Type = syn::parse2(ty.clone()).unwrap();
            assert_eq!(
                arg_wire_size(&parsed),
                size,
                "wire size for `{ty}` must be {size}",
            );
        }
        // Unknown / variable-length entries stay 0, never fabricated.
        for ty in [
            quote!(&[u8]),
            quote!(BoundedString<16>),
            quote!(BoundedVec<u16, 4>),
            quote!(MyCustomArgs),
            quote!([u8; LEN]),
        ] {
            let parsed: Type = syn::parse2(ty.clone()).unwrap();
            assert_eq!(arg_wire_size(&parsed), 0, "`{ty}` must publish size 0");
        }
    }
}
