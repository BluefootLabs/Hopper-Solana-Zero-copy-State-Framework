//! `#[hopper_state]`. contract-aware zero-copy layout codegen.
//!
//! The canonical proc-macro path must participate in the same runtime,
//! schema, and receipt pipeline as hand-written Hopper layouts. This macro
//! therefore emits more than a `SegmentMap`: it generates field metadata,
//! layout fingerprints, typed load helpers, and schema export hooks.

use proc_macro2::TokenStream;
use quote::{format_ident, quote, ToTokens};
use sha2::{Digest, Sha256};
use syn::{
    parse::Parser, parse2, Attribute, Field, Fields, ItemStruct, LitInt, LitStr, Result, Type,
    TypePath,
};

#[derive(Clone)]
struct StateOptions {
    disc: Option<u8>,
    version: u8,
    /// Target schema epoch (`LayoutContract::SCHEMA_EPOCH`), the version
    /// the in-place epoch-migration chain heals accounts up to. Defaults
    /// to 1 (`DEFAULT_SCHEMA_EPOCH`); set it when the layout declares
    /// `LayoutMigration` edges (`#[hopper::migrate]` +
    /// `layout_migrations!`) so `#[account(epoch_migrate)]` has a target.
    schema_epoch: u32,
    /// Hybrid serialization (hybrid serialization). When set, the
    /// layout emits tail-access helpers that read/write a
    /// length-prefixed dynamic payload at offset
    /// `HEADER_LEN + BODY_SIZE`.
    dynamic_tail: Option<syn::Type>,
    /// Canonical compact-tail schema descriptor. `dynamic_account` supplies
    /// this automatically; hand-written `dynamic_tail = T` layouts at least
    /// fingerprint the tail type token.
    dynamic_tail_schema: Option<String>,
    /// Raw final-tail layouts still carry the Hopper u32 tail prefix, but the
    /// final field consumes the remaining payload bytes without its own
    /// field-level prefix and therefore cannot be represented as `TailCodec`.
    raw_tail: bool,
    /// Tier-1 compact layout: store the account as `[disc:u8][body]` with
    /// no 16-byte universal header. Emits a [`CompactLayout`] impl and the
    /// compact load helpers instead of the headered `LayoutContract` path.
    compact: bool,
    /// Compact layouts only: opt into a program-managed dynamic tail
    /// (`[disc][fixed_head][tail]`) with no length prefix, typically overlaid
    /// with a zero-copy collection (TailVec/TailRing/TailSlab) via the
    /// `CompactTail` helpers. Emits a [`CompactDynamicLayout`] impl (relaxed
    /// length validation) instead of [`CompactLayout`].
    dynamic: bool,
    /// Emit native getters and setters (`fn total(&self) -> u64`,
    /// `fn set_total(&mut self, u64)`) for the wire scalar fields. Opt-in
    /// because the methods take the fields' names.
    accessors: bool,
}

impl Default for StateOptions {
    fn default() -> Self {
        Self {
            disc: None,
            version: 1,
            schema_epoch: 1,
            dynamic_tail: None,
            dynamic_tail_schema: None,
            raw_tail: false,
            compact: false,
            dynamic: false,
            accessors: false,
        }
    }
}

/// Per-field metadata extracted from Hopper-specific attributes.
///
/// These attributes (`#[role = "..."]` and `#[invariant = "..."]`) are
/// consumed by `#[hopper::state]` itself. they are stripped from the
/// re-emitted struct so the compiler never sees them. This is how the
/// layout ties individual fields to schema intents and to the named
/// invariants declared on an associated `#[hopper::error_code]` enum.
///
/// ## Design notes
///
/// Hopper gives authored layouts a way to say "this field is a balance" or
/// "this field is guarded by
/// `balance_nonzero`" at declaration time. information that then
/// flows directly into the manifest, the receipt narrative, and the
/// Codama/Python client generators.
#[derive(Default, Clone)]
struct FieldMeta {
    /// Semantic role string (e.g. `"balance"`, `"authority"`). Empty
    /// string means no role was declared. the field falls back to
    /// `FieldIntent::Custom`.
    role: String,
    /// Invariant name this field is guarded by (e.g. `"balance_nonzero"`).
    /// Empty when the field has no declared invariant.
    invariant: String,
    /// `#[bump]`: this u8 field holds the stored PDA bump the program
    /// stored at init. Drives the `CANONICAL_BUMP_ABS_OFFSET` const that
    /// `#[account(seeds = [...], bump = stored)]` verifies against.
    bump: bool,
    /// `#[check(rule)]` / `#[check(rule, error = E)]`: value rules on
    /// this field, in declaration order.
    checks: Vec<FieldCheck>,
}

pub fn expand(attr: TokenStream, item: TokenStream) -> Result<TokenStream> {
    let options = parse_state_options(attr)?;
    if options.raw_tail && options.dynamic_tail.is_some() {
        return Err(syn::Error::new(
            proc_macro2::Span::call_site(),
            "raw_tail = true cannot be combined with dynamic_tail = T",
        ));
    }
    if options.dynamic && (options.dynamic_tail.is_some() || options.raw_tail) {
        return Err(syn::Error::new(
            proc_macro2::Span::call_site(),
            "`dynamic` (program-managed tail) cannot be combined with `dynamic_tail = T` or `raw_tail = true`: choose one tail discipline",
        ));
    }
    if options.dynamic && !options.compact {
        return Err(syn::Error::new(
            proc_macro2::Span::call_site(),
            "`dynamic` is a compact-only option; use `compact, dynamic` (or a headered `dynamic_tail = T` / `raw_tail`)",
        ));
    }
    if options.compact {
        // Compact layouts may now carry a dynamic tail: `[disc:u8][fixed_head]
        // [tail]`. With a tail the type implements `CompactDynamicLayout`
        // (relaxed length validation); without one it stays a fixed-size
        // `CompactLayout`. The `raw_tail` + `dynamic_tail` mutual-exclusion is
        // already enforced above and applies here too.
        return expand_compact(options, item);
    }
    let dynamic_tail = options.dynamic_tail.clone();
    let mut input: ItemStruct = parse2(item)?;
    let name = input.ident.clone();
    let vis = input.vis.clone();

    if !has_repr_c(&input.attrs) {
        return Err(syn::Error::new_spanned(
            &input,
            "hopper_state requires #[repr(C)] so segment offsets and typed loads stay stable",
        ));
    }

    // State overlays are plain wire values. The authored struct must be
    // `Clone + Copy` so the generated Pod impls satisfy Hopper's canonical
    // Pod contract. Do not inject derives here: rustc may apply an outer
    // `#[derive(Clone, Copy)]` separately from this attribute macro, and
    // emitting a second derive produces duplicate trait impls. Instead, keep
    // the user's derives intact and emit an explicit proof below so missing
    // derives fail at the layout declaration site.

    // Verify we have named fields before we start mutating. We can't
    // iterate `&input.fields` here because we'll need `&mut` access
    // below to strip the hopper-internal attributes from the struct
    // we re-emit. Do a bare shape-check first; actual iteration
    // happens against `input.fields` directly.
    if !matches!(input.fields, Fields::Named(_)) {
        return Err(syn::Error::new_spanned(
            &input,
            "hopper_state requires a struct with named fields",
        ));
    }

    let mut segment_entries = Vec::new();
    let mut module_items = Vec::new();
    let mut inherent_items = Vec::new();
    let mut field_name_literals = Vec::new();
    let mut field_type_literals = Vec::new();
    let mut field_types = Vec::new();
    let mut value_checks = Vec::new();
    let mut field_intent_tokens: Vec<TokenStream> = Vec::new();
    let mut field_role_literals: Vec<LitStr> = Vec::new();
    let mut field_invariant_literals: Vec<LitStr> = Vec::new();
    let mut running_offset = quote! { 0u32 };
    // Offset tokens of the single `#[bump]`-marked field, when present.
    let mut canonical_bump_offset: Option<TokenStream> = None;

    let struct_name_upper = to_screaming_snake(&name.to_string());

    // First pass: extract hopper-internal attributes from each field
    // and strip them from the re-emitted struct. The consumed attrs
    // (`#[role = "..."]`, `#[invariant = "..."]`) are bare identifiers
    // without a `::` path prefix, so leaving them in place would cause
    // rustc to reject the re-emitted struct with "unknown attribute".
    let field_metas: Vec<FieldMeta> = match &mut input.fields {
        Fields::Named(named) => {
            let mut out = Vec::with_capacity(named.named.len());
            for field in named.named.iter_mut() {
                let meta = parse_field_meta(field)?;
                strip_hopper_field_attrs(field);
                out.push(meta);
            }
            out
        }
        _ => unreachable!("checked above"),
    };

    // Borrow the (now-cleaned) named fields for the main codegen walk.
    let fields = match &input.fields {
        Fields::Named(f) => &f.named,
        _ => unreachable!("checked above"),
    };

    for (field, meta) in fields.iter().zip(field_metas.iter()) {
        let field_name = field.ident.as_ref().unwrap();
        let field_name_str = field_name.to_string();
        let field_ty = &field.ty;
        let field_name_upper = to_screaming_snake(&field_name_str);
        let current_offset = running_offset.clone();

        if meta.bump {
            // Soundness gates for `bump = stored`: exactly one marked
            // field, and it must be a literal `u8` (the bump wire type).
            if canonical_bump_offset.is_some() {
                return Err(syn::Error::new(
                    field_name.span(),
                    "#[bump] may be marked on at most one field per state struct",
                ));
            }
            let is_u8 = matches!(
                field_ty,
                Type::Path(TypePath { qself: None, path }) if path.is_ident("u8")
            );
            if !is_u8 {
                return Err(syn::Error::new(
                    field_name.span(),
                    "#[bump] must mark a `u8` field (the canonical PDA bump byte)",
                ));
            }
            canonical_bump_offset = Some(current_offset.clone());
        }

        field_name_literals.push(syn::LitStr::new(&field_name_str, field_name.span()));
        field_type_literals.push(syn::LitStr::new(
            &field_ty.to_token_stream().to_string().replace(' ', ""),
            field_name.span(),
        ));
        field_types.push(field_ty.clone());
        value_checks.push(quote! { ::hopper::__runtime::Pod::validate_value(&self.#field_name)?; });
        field_intent_tokens.push(role_to_intent_tokens(&meta.role, field_name.span())?);
        field_role_literals.push(LitStr::new(&meta.role, field_name.span()));
        field_invariant_literals.push(LitStr::new(&meta.invariant, field_name.span()));

        segment_entries.push(quote! {
            ::hopper::hopper_core::segment_map::StaticSegment::new(
                #field_name_str,
                #current_offset,
                core::mem::size_of::<#field_ty>() as u32,
            )
        });

        let const_name = format_ident!("{}_{}_OFFSET", struct_name_upper, field_name_upper);
        let const_abs_name = format_ident!("{}_{}_ABS_OFFSET", struct_name_upper, field_name_upper);
        let const_size_name = format_ident!("{}_{}_SIZE", struct_name_upper, field_name_upper);
        let const_type_name = format_ident!("{}_{}_TYPE", struct_name_upper, field_name_upper);
        let assoc_offset_name = format_ident!("{}_OFFSET", field_name_upper);
        let assoc_abs_offset_name = format_ident!("{}_ABS_OFFSET", field_name_upper);
        let assoc_size_name = format_ident!("{}_SIZE", field_name_upper);

        // Body-relative offset + account-absolute offset for each field.
        //
        // `*_OFFSET` is the field's offset within the layout body (0-indexed
        // from the start of the layout's `#[repr(C)]` struct). That's the
        // value `ctx.segment_mut::<T>(..)` historically expected with the
        // 16-byte header pre-added.
        //
        // `*_ABS_OFFSET` folds in `HEADER_LEN` so the caller can pass it
        // directly to any segment accessor that expects a buffer-absolute
        // offset. avoiding `HEADER_LEN + Vault::AUTHORITY_OFFSET`
        // boilerplate at every call site.
        module_items.push(quote! {
            #vis const #const_name: u32 = #current_offset;
            #vis const #const_abs_name: u32 =
                ::hopper::hopper_core::account::HEADER_LEN as u32 + #current_offset;
            #vis const #const_size_name: u32 = core::mem::size_of::<#field_ty>() as u32;
            #vis type #const_type_name = #field_ty;
        });

        inherent_items.push(quote! {
            #vis const #assoc_offset_name: u32 = #current_offset;
            #vis const #assoc_abs_offset_name: u32 =
                ::hopper::hopper_core::account::HEADER_LEN as u32 + #current_offset;
            #vis const #assoc_size_name: u32 = core::mem::size_of::<#field_ty>() as u32;
        });

        // Array-column geometry used by parametric exact-cell write policies.
        // These consts are emitted only for real arrays, so applying
        // `cells(selector; field)` to a scalar fails with a clear missing-const
        // type error instead of silently inventing a stride.
        if let Type::Array(array) = field_ty {
            let element_ty = &array.elem;
            let element_count = &array.len;
            let const_element_size_name =
                format_ident!("{}_{}_ELEMENT_SIZE", struct_name_upper, field_name_upper);
            let const_element_count_name =
                format_ident!("{}_{}_ELEMENT_COUNT", struct_name_upper, field_name_upper);
            let assoc_element_size_name = format_ident!("{}_ELEMENT_SIZE", field_name_upper);
            let assoc_element_count_name = format_ident!("{}_ELEMENT_COUNT", field_name_upper);
            module_items.push(quote! {
                #vis const #const_element_size_name: u32 =
                    core::mem::size_of::<#element_ty>() as u32;
                #vis const #const_element_count_name: u32 = (#element_count) as u32;
            });
            inherent_items.push(quote! {
                #vis const #assoc_element_size_name: u32 =
                    core::mem::size_of::<#element_ty>() as u32;
                #vis const #assoc_element_count_name: u32 = (#element_count) as u32;
            });
        }

        running_offset = quote! {
            #current_offset + core::mem::size_of::<#field_ty>() as u32
        };
    }

    {
        let (inherent, module) = field_rule_items(
            &name,
            &vis,
            fields,
            &field_metas,
            options.accessors,
            RuleLoad::Headered,
        )?;
        inherent_items.push(inherent);
        module_items.push(module);
    }

    // `#[bump]` marker: emit the account-absolute offset of the canonical
    // bump byte so `#[account(seeds = [...], bump = stored)]` can verify
    // the PDA with one sha256 hash. Absent marker means
    // absent const, so `bump = stored` on an unmarked type is a clean
    // missing-associated-item compile error.
    if let Some(bump_offset) = &canonical_bump_offset {
        inherent_items.push(quote! {
            /// Account-absolute byte offset of the `#[bump]`-marked field:
            /// the stored PDA bump. `#[derive(Accounts)]`'s `init` writes
            /// the canonical bump it signed the creation with here;
            /// `bump = stored` then verifies the PDA with one hash. A byte
            /// written by anything else is not proven canonical.
            #vis const CANONICAL_BUMP_ABS_OFFSET: u32 =
                ::hopper::hopper_core::account::HEADER_LEN as u32 + #bump_offset;
        });
        module_items.push(quote! {
            impl ::hopper::__runtime::layout::StoredBump for #name {
                const BUMP_ABS_OFFSET: usize = Self::CANONICAL_BUMP_ABS_OFFSET as usize;
            }
        });
    }

    let body_size = running_offset.clone();
    let version = options.version;
    let schema_epoch = options.schema_epoch;
    let dynamic_tail_fingerprint = options
        .dynamic_tail_schema
        .as_deref()
        .map(str::to_owned)
        .or_else(|| {
            dynamic_tail
                .as_ref()
                .map(|ty| format!("type:{}", ty.to_token_stream().to_string().replace(' ', "")))
        });
    let layout_id = layout_id_bytes(&name, version, fields, dynamic_tail_fingerprint.as_deref());
    // Default discriminator: first byte of the layout_id fingerprint.
    // If that byte is zero (1-in-256 chance given SHA-256 uniformity)
    // we fall through to the first non-zero byte so the compile-time
    // "disc != 0" fence never fires spuriously. The user never needs
    // to set `disc = ...` explicitly unless they want a specific wire
    // value.
    let disc = options.disc.unwrap_or_else(|| {
        for byte in layout_id.iter() {
            if *byte != 0 {
                return *byte;
            }
        }
        // All-zero SHA-256 first 8 bytes is astronomically improbable;
        // if we ever hit it the 1-byte fallback is still non-zero.
        1u8
    });
    let layout_id_tokens = byte_array_literal(&layout_id);
    let field_count = field_name_literals.len();

    // A headered layout with a variable tail flips the descriptor's
    // dynamic-tail flag; the `min_size` stays the fixed prefix length.
    let dynamic_tail_descriptor = if options.dynamic_tail.is_some() || options.raw_tail {
        quote! { .with_dynamic_tail() }
    } else {
        quote! {}
    };

    // Unique per-layout static that pins LAYOUT_ID bytes into
    // `.rodata`. `hopper verify` searches the compiled binary for
    // this exact 8-byte sequence to prove manifest/binary agreement.
    let layout_id_hex = layout_id
        .iter()
        .map(|byte| format!("{:02X}", byte))
        .collect::<String>();
    let layout_id_anchor_ident = format_ident!(
        "__HOPPER_LAYOUT_ID_ANCHOR_{}_{}",
        struct_name_upper,
        layout_id_hex
    );

    // ── Hybrid serialization: hybrid-serialization tail helpers ──────────────────
    //
    // When the user writes `#[hopper::state(dynamic_tail = MyTail)]`,
    // emit `tail_len`, `tail_read`, `tail_write`, and a
    // `TAIL_PREFIX_OFFSET` constant on the layout's inherent impl.
    // The offset points to the `u32 LE` length prefix that precedes
    // the dynamic payload. exactly the position defined in
    // `crates/hopper-runtime/src/tail.rs`.
    //
    // Layouts without `dynamic_tail` emit an empty token stream and
    // pay zero cost: the fast path stays strictly zero-copy.
    let dynamic_tail_methods = if let Some(tail_ty) = &dynamic_tail {
        quote! {
            /// This layout opts in to the Hopper hybrid-serialization
            /// tail (hybrid serialization). Fixed body remains zero-copy;
            /// tail access is explicit via the `tail_*` helpers below.
            pub const HAS_DYNAMIC_TAIL: bool = true;

            /// Byte offset of the tail's `u32 LE` length prefix. The
            /// payload starts at `TAIL_PREFIX_OFFSET + 4`. Layouts
            /// without a dynamic tail do not emit this constant.
            pub const TAIL_PREFIX_OFFSET: usize = Self::LEN;

            /// Read the tail's length prefix.
            #[inline]
            pub fn tail_len(data: &[u8]) -> ::core::result::Result<
                u32,
                ::hopper::__runtime::ProgramError,
            > {
                ::hopper::__runtime::read_tail_len(data, Self::TAIL_PREFIX_OFFSET)
            }

            /// Decode and return the dynamic tail as `#tail_ty`.
            ///
            /// The full encoded length (from the u32 prefix) must be
            /// consumed exactly by `#tail_ty::decode`. trailing bytes
            /// indicate a malformed encoding and are rejected.
            #[inline]
            pub fn tail_read(data: &[u8]) -> ::core::result::Result<
                #tail_ty,
                ::hopper::__runtime::ProgramError,
            > {
                ::hopper::__runtime::read_tail::<#tail_ty>(data, Self::TAIL_PREFIX_OFFSET)
            }

            /// Encode `tail` in place and update the u32 length prefix.
            /// Returns the number of bytes written (excluding the prefix).
            /// Caller is responsible for ensuring the account has enough
            /// room (call `resize` first when growing).
            #[inline]
            pub fn tail_write(
                data: &mut [u8],
                tail: &#tail_ty,
            ) -> ::core::result::Result<
                usize,
                ::hopper::__runtime::ProgramError,
            > {
                ::hopper::__runtime::write_tail::<#tail_ty>(
                    data,
                    Self::TAIL_PREFIX_OFFSET,
                    tail,
                )
            }
        }
    } else if options.raw_tail {
        quote! {
            /// This layout opts in to a Hopper raw final tail. Fixed body
            /// remains zero-copy; the final dynamic field consumes the
            /// remaining tail payload bytes without a field-level prefix.
            pub const HAS_DYNAMIC_TAIL: bool = true;
            pub const HAS_RAW_DYNAMIC_TAIL: bool = true;

            /// Byte offset of the tail's `u32 LE` length prefix. The payload
            /// starts at `TAIL_PREFIX_OFFSET + 4`.
            pub const TAIL_PREFIX_OFFSET: usize = Self::LEN;

            /// Read the tail's length prefix.
            #[inline]
            pub fn tail_len(data: &[u8]) -> ::core::result::Result<
                u32,
                ::hopper::__runtime::ProgramError,
            > {
                ::hopper::__runtime::read_tail_len(data, Self::TAIL_PREFIX_OFFSET)
            }

            /// Borrow the full dynamic-tail payload, excluding the u32 prefix.
            #[inline]
            pub fn tail_payload<'a>(data: &'a [u8]) -> ::core::result::Result<
                &'a [u8],
                ::hopper::__runtime::ProgramError,
            > {
                ::hopper::__runtime::tail_payload(data, Self::TAIL_PREFIX_OFFSET)
            }
        }
    } else {
        quote! {
            /// This layout has no dynamic tail. The constant is emitted
            /// unconditionally so callers can branch on it at compile time.
            pub const HAS_DYNAMIC_TAIL: bool = false;
        }
    };

    let state_param_inits = fields
        .iter()
        .map(state_field_param_init)
        .collect::<Result<Vec<_>>>()?;
    let constructor_params: Vec<TokenStream> = state_param_inits
        .iter()
        .map(|item| item.0.clone())
        .collect();
    let constructor_inits: Vec<TokenStream> = state_param_inits
        .iter()
        .map(|item| item.1.clone())
        .collect();
    let set_inner_assigns: Vec<TokenStream> = state_param_inits
        .iter()
        .map(|item| item.2.clone())
        .collect();
    let constructor_method = if options.dynamic_tail_schema.is_none() {
        quote! {
            // One parameter per field mirrors the user's struct; arity follows
            // their schema, not an API design choice.
            #[allow(clippy::too_many_arguments)]
            #[inline(always)]
            #vis const fn new(#(#constructor_params),*) -> Self {
                Self {
                    #(#constructor_inits),*
                }
            }
        }
    } else {
        TokenStream::new()
    };

    let set_inner_method = quote! {
        // One parameter per field mirrors the user's struct; arity follows
        // their schema, not an API design choice.
        #[allow(clippy::too_many_arguments)]
        #[inline(always)]
        #vis fn set_inner(
            &mut self,
            #(#constructor_params),*
        ) -> ::core::result::Result<(), ::hopper::__runtime::ProgramError> {
            #(#set_inner_assigns)*
            Ok(())
        }
    };

    let (named_fields, named_methods) = named_field_model(&input, fields)?;

    let expanded = quote! {
        #input

        #named_fields

        // ── Compile-time safety fence ──────────────────────────────────
        // Alignment, padding, discriminator, and size checks all fire at
        // type-check time, so malformed layouts never reach link time.
        const _: () = {
            assert!(
                core::mem::align_of::<#name>() == 1,
                "hopper_state layouts must use alignment-1 field types such as WireU64 or TypedAddress",
            );
            assert!(
                core::mem::size_of::<#name>() == ((#body_size) as usize),
                "hopper_state layouts must be #[repr(C)] with no implicit padding",
            );
            assert!(
                core::mem::size_of::<#name>() > 0,
                "hopper_state layouts must have at least one field; zero-sized overlays project to dangling pointers",
            );
            assert!(
                #disc != 0,
                "hopper_state discriminator must be non-zero: a zero discriminator cannot be distinguished from an uninitialized account",
            );
        };

        #(#module_items)*

        impl #name {
            #constructor_method
            #set_inner_method
            #named_methods

            #(#inherent_items)*

            pub const BODY_SIZE: usize = core::mem::size_of::<Self>();
            pub const LEN: usize = ::hopper::hopper_core::account::HEADER_LEN + Self::BODY_SIZE;
            pub const DISC: u8 = #disc;
            pub const VERSION: u8 = #version;
            pub const LAYOUT_ID: [u8; 8] = #layout_id_tokens;

            /// Bytes to allocate for a fresh account of this layout.
            ///
            /// Equal to [`Self::LEN`] (header + body) and spelled
            /// `INIT_SPACE` so Anchor-style `#[account(init, space = T::INIT_SPACE)]`
            /// ports over unchanged. Zero-copy layouts are always
            /// fixed-size, so this is a const the compiler can fold
            /// into the System Program allocate CPI at the call site.
            pub const INIT_SPACE: usize = Self::LEN;

            #[inline(always)]
            pub fn write_init_header(
                data: &mut [u8],
            ) -> ::core::result::Result<(), ::hopper::__runtime::ProgramError> {
                ::hopper::hopper_core::account::write_header(
                    data,
                    Self::DISC,
                    Self::VERSION,
                    &Self::LAYOUT_ID,
                )
            }

            #[inline(always)]
            pub fn overlay(
                data: &[u8],
            ) -> ::core::result::Result<&Self, ::hopper::__runtime::ProgramError> {
                ::hopper::hopper_core::account::pod_from_bytes::<Self>(data)
            }

            #[inline(always)]
            pub fn overlay_mut(
                data: &mut [u8],
            ) -> ::core::result::Result<&mut Self, ::hopper::__runtime::ProgramError> {
                ::hopper::hopper_core::account::pod_from_bytes_mut::<Self>(data)
            }

            #[inline(always)]
            pub fn load<'a>(
                account: &'a ::hopper::prelude::AccountView<'a>,
                program_id: &::hopper::prelude::Address,
            ) -> ::core::result::Result<
                ::hopper::__runtime::Ref<'a, Self>,
                ::hopper::__runtime::ProgramError,
            > {
                account.check_owned_by(program_id)?;
                account.load::<Self>()
            }

            #[inline(always)]
            pub fn load_mut<'a>(
                account: &'a ::hopper::prelude::AccountView<'a>,
                program_id: &::hopper::prelude::Address,
            ) -> ::core::result::Result<
                ::hopper::__runtime::RefMut<'a, Self>,
                ::hopper::__runtime::ProgramError,
            > {
                account.check_owned_by(program_id)?.check_writable()?;
                account.load_mut::<Self>()
            }

            #[inline(always)]
            #[deprecated(since = "0.2.0", note = "renamed to load_cross_program()")]
            pub fn load_foreign<'a>(
                account: &'a ::hopper::prelude::AccountView<'a>,
                expected_owner: &::hopper::prelude::Address,
            ) -> ::core::result::Result<
                ::hopper::__runtime::Ref<'a, Self>,
                ::hopper::__runtime::ProgramError,
            > {
                Self::load_cross_program(account, expected_owner)
            }

            #[inline(always)]
            pub fn load_cross_program<'a>(
                account: &'a ::hopper::prelude::AccountView<'a>,
                expected_owner: &::hopper::prelude::Address,
            ) -> ::core::result::Result<
                ::hopper::__runtime::Ref<'a, Self>,
                ::hopper::__runtime::ProgramError,
            > {
                account.check_owned_by(expected_owner)?;
                account.load::<Self>()
            }

            #dynamic_tail_methods

            /// Compile-time layout manifest for this account type.
            ///
            /// One `const` carries the full schema row, name, disc,
            /// version, 8-byte layout fingerprint, total size (header +
            /// body), and a per-field descriptor table with the REAL
            /// authored types and header-relative offsets the macro
            /// already computes. Field intents come from the declared
            /// `#[role = "..."]` attributes (`Custom` when undeclared,
            /// nothing is guessed). `hopper::program_manifest!` lists
            /// layouts as `MyLayout::LAYOUT_MANIFEST`, and
            /// `SchemaExport::layout_manifest()` returns this same
            /// const, so the published schema cannot drift from the
            /// compiled layout.
            pub const LAYOUT_MANIFEST: ::hopper::hopper_schema::LayoutManifest = {
                const FIELD_COUNT: usize = #field_count;
                const NAMES: [&str; FIELD_COUNT] = [#(#field_name_literals),*];
                const TYPES: [&str; FIELD_COUNT] = [#(#field_type_literals),*];
                const SIZES: [u16; FIELD_COUNT] = [#(core::mem::size_of::<#field_types>() as u16),*];
                // Per-field declared intents, parsed from `#[role = "..."]`
                // field attributes at proc-macro expansion time. Fields
                // without a role attribute default to `Custom`. their
                // position in this table still keeps the slice
                // `FIELD_COUNT`-sized so downstream code never needs a
                // branch on presence.
                const INTENTS: [::hopper::hopper_schema::FieldIntent; FIELD_COUNT] = [
                    #(#field_intent_tokens),*
                ];
                const FIELDS: [::hopper::hopper_schema::FieldDescriptor; FIELD_COUNT] = {
                    let mut result = [::hopper::hopper_schema::FieldDescriptor {
                        name: "",
                        canonical_type: "",
                        size: 0,
                        offset: 0,
                        intent: ::hopper::hopper_schema::FieldIntent::Custom,
                    }; FIELD_COUNT];
                    let mut offset = ::hopper::hopper_core::account::HEADER_LEN as u16;
                    let mut index = 0;
                    while index < FIELD_COUNT {
                        result[index] = ::hopper::hopper_schema::FieldDescriptor {
                            name: NAMES[index],
                            canonical_type: TYPES[index],
                            size: SIZES[index],
                            offset,
                            intent: INTENTS[index],
                        };
                        offset += SIZES[index];
                        index += 1;
                    }
                    result
                };

                ::hopper::hopper_schema::LayoutManifest {
                    name: stringify!(#name),
                    version: #name::VERSION,
                    disc: #name::DISC,
                    layout_id: #name::LAYOUT_ID,
                    total_size: #name::LEN,
                    has_dynamic_tail: #name::HAS_DYNAMIC_TAIL,
                    field_count: FIELD_COUNT,
                    fields: &FIELDS,
                }
            };

            // ── Field-level metadata registries ──────────────────────────
            //
            // These two tables are the structural twin of the `CODE_TABLE`
            // / `INVARIANT_TABLE` pair produced by `#[hopper::error_code]`.
            // Together they let off-chain tooling (SDK narrator, Codama
            // client generator, IDL exporter) answer three questions at
            // declaration time, without ever running the program:
            //
            //   1. "What does field `X` mean?". `FIELD_ROLES`
            //   2. "Which invariant guards field `X`?". `FIELD_INVARIANTS`
            //   3. "Which FieldIntent enum value does the runtime use?". //      the manifest's FieldDescriptor.intent column.
            //
            // The *same source declaration* flows into the manifest,
            // the Python client, the receipt narrative, and any future
            // lint pass that wants to say "this field was declared as a
            // balance but a non-financial invariant is guarding it."

            /// Declared semantic role per field, in struct declaration
            /// order. Empty string means no `#[role = "..."]` was given
            /// and the field falls back to `FieldIntent::Custom`.
            pub const FIELD_ROLES: &'static [(&'static str, &'static str)] = &[
                #( (#field_name_literals, #field_role_literals) ),*
            ];

            /// Declared invariant name per field, in struct declaration
            /// order. Empty string means no `#[invariant = "..."]` was
            /// given. Pair this with
            /// `<ErrorEnum>::INVARIANT_TABLE` to resolve the invariant
            /// name back to the error variant it raises. completing
            /// the field → invariant → error → receipt chain.
            pub const FIELD_INVARIANTS: &'static [(&'static str, &'static str)] = &[
                #( (#field_name_literals, #field_invariant_literals) ),*
            ];
        }

        // `#[hopper::state]` emits Pod impls, and Hopper's canonical Pod
        // contract is `Copy + Sized`. Keep the visible Rust spelling
        // conventional (`#[derive(Clone, Copy)]`) instead of silently
        // injecting a derive from inside the attribute macro; this avoids
        // duplicate trait impls when users follow the README pattern.
        #[doc(hidden)]
        const _: () = {
            struct __StateCopyProof<T: ::core::clone::Clone + ::core::marker::Copy>(
                ::core::marker::PhantomData<T>,
            );
            const _: __StateCopyProof<#name> =
                __StateCopyProof(::core::marker::PhantomData);
        };

        // Hopper field-level Pod proof. Each field type is forced through
        // this bound;
        // a `bool`, `char`, reference, or non-`Pod` nested
        // struct fails the trait bound *on the field*, not at some
        // distant `segment_ref::<T>()` call site.
        #[doc(hidden)]
        const _: () = {
            struct __FieldPodProof<
                T: ::hopper::__runtime::Pod,
            >(::core::marker::PhantomData<T>);
            #(
                #[allow(dead_code)]
                const _: __FieldPodProof<#field_types> =
                    __FieldPodProof(::core::marker::PhantomData);
            )*
        };

        // SAFETY: the struct is `#[repr(C)]` (checked at expansion), every
        // field is proven `Pod` by the assertions emitted above, and the
        // size assertion rules out padding. All-zero bytes and every
        // other bit pattern are therefore valid, at alignment 1, with no
        // pointer inside. The seal below repeats that contract.
        unsafe impl ::hopper::__runtime::Zeroable for #name {}
        // SAFETY: each field is Pod and the layout assertions establish
        // alignment 1 and no padding. Value validation adds no Rust validity
        // restriction: all byte patterns remain safe to overlay.
        unsafe impl ::hopper::hopper_core::account::Pod for #name {
            #[inline]
            fn validate_value(&self) -> ::hopper::__runtime::__hopper_native::ProgramResult {
                #(#value_checks)*
                ::core::result::Result::Ok(())
            }
        }
        // SAFETY: the field-level Pod proofs and layout assertions above
        // establish the seal's fixed-size, alignment-1, no-padding,
        // no-pointer, all-bits-valid contract.
        unsafe impl ::hopper::__runtime::__sealed::HopperZeroCopySealed for #name {}

        // Anchor the layout fingerprint in `.rodata` so `hopper verify`
        // can scan for the exact manifest bytes. On the Solana target,
        // export the anchor without `#[used]`: the retain flag flips the
        // artifact OSABI to GNU and `solana program deploy` rejects it.
        #[allow(unexpected_cfgs)]
        #[cfg_attr(not(target_os = "solana"), used)]
        #[doc(hidden)]
        #[no_mangle]
        pub static #layout_id_anchor_ident: [u8; 8] = #name::LAYOUT_ID;

        impl ::hopper::hopper_core::account::FixedLayout for #name {
            const SIZE: usize = core::mem::size_of::<Self>();
        }

        impl ::hopper::hopper_core::segment_map::SegmentMap for #name {
            const SEGMENTS: &'static [::hopper::hopper_core::segment_map::StaticSegment] = &[
                #(#segment_entries),*
            ];
        }

        impl ::hopper::hopper_core::field_map::FieldMap for #name {
            const FIELDS: &'static [::hopper::hopper_core::field_map::FieldInfo] = {
                const FIELD_COUNT: usize = #field_count;
                const NAMES: [&str; FIELD_COUNT] = [#(#field_name_literals),*];
                const SIZES: [usize; FIELD_COUNT] = [#(core::mem::size_of::<#field_types>()),*];
                const FIELDS: [::hopper::hopper_core::field_map::FieldInfo; FIELD_COUNT] = {
                    let mut result = [::hopper::hopper_core::field_map::FieldInfo::new("", 0, 0); FIELD_COUNT];
                    let mut offset = ::hopper::hopper_core::account::HEADER_LEN;
                    let mut index = 0;
                    while index < FIELD_COUNT {
                        result[index] = ::hopper::hopper_core::field_map::FieldInfo::new(
                            NAMES[index],
                            offset,
                            SIZES[index],
                        );
                        offset += SIZES[index];
                        index += 1;
                    }
                    result
                };
                &FIELDS
            };
        }

        impl ::hopper::hopper_runtime::LayoutContract for #name {
            const DISC: u8 = #name::DISC;
            const VERSION: u8 = #name::VERSION;
            const LAYOUT_ID: [u8; 8] = #name::LAYOUT_ID;
            const SIZE: usize = #name::LEN;
            const SCHEMA_EPOCH: u32 = #schema_epoch;
        }

        impl ::hopper::hopper_core::check::modifier::HopperLayout for #name {
            const DISC: u8 = #name::DISC;
            const VERSION: u8 = #name::VERSION;
            const LAYOUT_ID: [u8; 8] = #name::LAYOUT_ID;
            const LEN_WITH_HEADER: usize = #name::LEN;
            const OVERLAY_OFFSET: usize = ::hopper::hopper_core::account::HEADER_LEN;
        }

        impl ::hopper::hopper_schema::SchemaExport for #name {
            fn layout_manifest() -> ::hopper::hopper_schema::LayoutManifest {
                // One source of truth: the inherent `LAYOUT_MANIFEST`
                // const above carries the identical field table, so the
                // trait surface and the manifest-glue surface can never
                // disagree.
                #name::LAYOUT_MANIFEST
            }
        }

        // The unified one-source-of-truth descriptor. A headered layout
        // produces the same `AccountDescriptor` shape a compact one does,
        // so a program registers, diffs, and validates every account type
        // through a single model regardless of wire shape. The descriptor
        // is `const` and folds in the 16-byte header.
        impl ::hopper::manifest::LayoutDescriptor for #name {
            const DESCRIPTOR: ::hopper::manifest::AccountDescriptor =
                ::hopper::manifest::AccountDescriptor::headered(
                    stringify!(#name),
                    #name::DISC,
                    #name::VERSION as u16,
                    #name::BODY_SIZE as u32,
                    #name::LAYOUT_ID,
                )#dynamic_tail_descriptor;
        }
    };

    Ok(expanded)
}

/// Tier-1 compact-layout codegen for `#[hopper::state(compact, ...)]`.
///
/// A compact account is stored as `[disc:u8][zero-copy body]` with **no**
/// 16-byte universal header. This path therefore emits a deliberately
/// smaller surface than the headered [`expand`] path:
///
/// - a [`CompactLayout`](::hopper::account::CompactLayout) impl (the
///   hot-path loader contract) instead of `LayoutContract` / `HopperLayout`,
/// - body-relative and account-absolute field offsets (the absolute
///   offsets fold in the single discriminator byte, not `HEADER_LEN`),
/// - a `registry_entry()` helper plus role/invariant metadata so the layout
///   can flow into Tier-2/Tier-3 tooling without hand-writing the
///   `AccountLayoutEntry`.
///
/// The headered path is untouched: a type is compact iff it asked for it.
fn expand_compact(options: StateOptions, item: TokenStream) -> Result<TokenStream> {
    let mut input: ItemStruct = parse2(item)?;
    let name = input.ident.clone();
    let vis = input.vis.clone();

    if !has_repr_c(&input.attrs) {
        return Err(syn::Error::new_spanned(
            &input,
            "hopper_state(compact) requires #[repr(C)] so the compact body offset stays stable",
        ));
    }
    if !matches!(input.fields, Fields::Named(_)) {
        return Err(syn::Error::new_spanned(
            &input,
            "hopper_state(compact) requires a struct with named fields",
        ));
    }

    // Strip hopper-internal field attrs from the re-emitted struct, same as
    // the headered path. Compact layouts still support `#[role]`/`#[invariant]`
    // so they participate in schema export.
    let field_metas: Vec<FieldMeta> = match &mut input.fields {
        Fields::Named(named) => {
            let mut out = Vec::with_capacity(named.named.len());
            for field in named.named.iter_mut() {
                let meta = parse_field_meta(field)?;
                strip_hopper_field_attrs(field);
                out.push(meta);
            }
            out
        }
        _ => unreachable!("checked above"),
    };

    let fields = match &input.fields {
        Fields::Named(f) => &f.named,
        _ => unreachable!("checked above"),
    };

    let struct_name_upper = to_screaming_snake(&name.to_string());

    let mut module_items = Vec::new();
    let mut inherent_items = Vec::new();
    let mut segment_entries = Vec::new();
    let mut field_name_literals = Vec::new();
    let mut field_type_literals = Vec::new();
    let mut field_types = Vec::new();
    let mut value_checks = Vec::new();
    let mut field_intent_tokens: Vec<TokenStream> = Vec::new();
    let mut field_role_literals: Vec<LitStr> = Vec::new();
    let mut field_invariant_literals: Vec<LitStr> = Vec::new();
    let mut running_offset = quote! { 0u32 };
    // Offset tokens of the single `#[bump]`-marked field, when present,
    // same contract as the headered walk: at most one marker, `u8` only.
    let mut canonical_bump_offset: Option<TokenStream> = None;

    for (field, meta) in fields.iter().zip(field_metas.iter()) {
        let field_name = field.ident.as_ref().unwrap();
        let field_name_str = field_name.to_string();
        let field_ty = &field.ty;
        let field_name_upper = to_screaming_snake(&field_name_str);
        let current_offset = running_offset.clone();

        if meta.bump {
            // Soundness gates for `bump = stored`, mirrored from the
            // headered walk so the marker's documented contract (exactly
            // one marked field, literal `u8`) holds on EVERY layout tier,
            // a silently-swallowed marker here previously compiled to
            // nothing and surfaced later as a confusing missing-const
            // error at the `bump = stored` use site.
            if canonical_bump_offset.is_some() {
                return Err(syn::Error::new(
                    field_name.span(),
                    "#[bump] may be marked on at most one field per state struct",
                ));
            }
            let is_u8 = matches!(
                field_ty,
                Type::Path(TypePath { qself: None, path }) if path.is_ident("u8")
            );
            if !is_u8 {
                return Err(syn::Error::new(
                    field_name.span(),
                    "#[bump] must mark a `u8` field (the canonical PDA bump byte)",
                ));
            }
            canonical_bump_offset = Some(current_offset.clone());
        }

        field_name_literals.push(LitStr::new(&field_name_str, field_name.span()));
        field_type_literals.push(LitStr::new(
            &field_ty.to_token_stream().to_string().replace(' ', ""),
            field_name.span(),
        ));
        field_types.push(field_ty.clone());
        value_checks.push(quote! { ::hopper::__runtime::Pod::validate_value(&self.#field_name)?; });
        field_intent_tokens.push(role_to_intent_tokens(&meta.role, field_name.span())?);
        field_role_literals.push(LitStr::new(&meta.role, field_name.span()));
        field_invariant_literals.push(LitStr::new(&meta.invariant, field_name.span()));

        segment_entries.push(quote! {
            ::hopper::hopper_core::segment_map::StaticSegment::new(
                #field_name_str,
                #current_offset,
                core::mem::size_of::<#field_ty>() as u32,
            )
        });

        let const_name = format_ident!("{}_{}_OFFSET", struct_name_upper, field_name_upper);
        let const_abs_name = format_ident!("{}_{}_ABS_OFFSET", struct_name_upper, field_name_upper);
        let const_size_name = format_ident!("{}_{}_SIZE", struct_name_upper, field_name_upper);
        let const_type_name = format_ident!("{}_{}_TYPE", struct_name_upper, field_name_upper);
        let assoc_offset_name = format_ident!("{}_OFFSET", field_name_upper);
        let assoc_abs_offset_name = format_ident!("{}_ABS_OFFSET", field_name_upper);
        let assoc_size_name = format_ident!("{}_SIZE", field_name_upper);

        // `*_OFFSET` is body-relative (from the start of the `#[repr(C)]`
        // struct). `*_ABS_OFFSET` folds in the single compact discriminator
        // byte (`COMPACT_BODY_OFFSET`), not `HEADER_LEN`.
        module_items.push(quote! {
            #vis const #const_name: u32 = #current_offset;
            #vis const #const_abs_name: u32 =
                ::hopper::account::COMPACT_BODY_OFFSET as u32 + #current_offset;
            #vis const #const_size_name: u32 = core::mem::size_of::<#field_ty>() as u32;
            #vis type #const_type_name = #field_ty;
        });

        inherent_items.push(quote! {
            #vis const #assoc_offset_name: u32 = #current_offset;
            #vis const #assoc_abs_offset_name: u32 =
                ::hopper::account::COMPACT_BODY_OFFSET as u32 + #current_offset;
            #vis const #assoc_size_name: u32 = core::mem::size_of::<#field_ty>() as u32;
        });

        running_offset = quote! {
            #current_offset + core::mem::size_of::<#field_ty>() as u32
        };
    }

    {
        let load = if options.dynamic_tail.is_some() || options.raw_tail || options.dynamic {
            RuleLoad::CompactDynamic
        } else {
            RuleLoad::Compact
        };
        let (inherent, module) =
            field_rule_items(&name, &vis, fields, &field_metas, options.accessors, load)?;
        inherent_items.push(inherent);
        module_items.push(module);
    }

    // `#[bump]` marker on a compact layout: the account-absolute offset
    // folds in the single compact discriminator byte, not the headered
    // `HEADER_LEN`. Same absent-marker contract as the headered path: no
    // marker, no const, and `bump = stored` is a clean missing-item error.
    if let Some(bump_offset) = &canonical_bump_offset {
        inherent_items.push(quote! {
            /// Account-absolute byte offset of the `#[bump]`-marked field:
            /// the stored PDA bump. `#[derive(Accounts)]`'s `init` writes
            /// the canonical bump it signed the creation with here;
            /// `bump = stored` then verifies the PDA with one hash. A byte
            /// written by anything else is not proven canonical.
            #vis const CANONICAL_BUMP_ABS_OFFSET: u32 =
                ::hopper::account::COMPACT_BODY_OFFSET as u32 + #bump_offset;
        });
        module_items.push(quote! {
            impl ::hopper::__runtime::layout::StoredBump for #name {
                const BUMP_ABS_OFFSET: usize = Self::CANONICAL_BUMP_ABS_OFFSET as usize;
            }
        });
    }

    let body_size = running_offset.clone();
    let compact_field_count = field_name_literals.len();
    let version = options.version;
    // A compact-dynamic tail is part of the layout's identity: two layouts
    // with the same fixed head but different tail types are different wire
    // shapes, so the tail type/schema folds into the fingerprint exactly as it
    // does on the headered path.
    let dynamic_tail_fingerprint = options
        .dynamic_tail_schema
        .as_deref()
        .map(str::to_owned)
        .or_else(|| {
            options
                .dynamic_tail
                .as_ref()
                .map(|ty| format!("type:{}", ty.to_token_stream().to_string().replace(' ', "")))
        })
        .or(if options.raw_tail {
            Some("raw_tail".to_owned())
        } else if options.dynamic {
            Some("dynamic".to_owned())
        } else {
            None
        });
    let layout_id = layout_id_bytes(&name, version, fields, dynamic_tail_fingerprint.as_deref());
    let disc = options.disc.unwrap_or_else(|| {
        for byte in layout_id.iter() {
            if *byte != 0 {
                return *byte;
            }
        }
        1u8
    });
    let layout_id_tokens = byte_array_literal(&layout_id);

    let layout_id_hex = layout_id
        .iter()
        .map(|byte| format!("{:02X}", byte))
        .collect::<String>();
    let layout_id_anchor_ident = format_ident!(
        "__HOPPER_COMPACT_LAYOUT_ID_ANCHOR_{}_{}",
        struct_name_upper,
        layout_id_hex
    );

    let state_param_inits = fields
        .iter()
        .map(state_field_param_init)
        .collect::<Result<Vec<_>>>()?;
    let constructor_params: Vec<TokenStream> =
        state_param_inits.iter().map(|i| i.0.clone()).collect();
    let constructor_inits: Vec<TokenStream> =
        state_param_inits.iter().map(|i| i.1.clone()).collect();

    // ── Compact dynamic-tail wiring ────────────────────────────────────
    // A compact layout may carry a dynamic tail (`[disc][fixed_head][tail]`).
    // The tail's u32 length prefix lives at `COMPACT_LEN`, and we reuse the
    // same offset-parameterized tail runtime as the headered path, only the
    // prefix offset differs (1-byte disc vs 16-byte header).
    let has_tail = options.dynamic_tail.is_some() || options.raw_tail || options.dynamic;

    let compact_tail_methods = if let Some(tail_ty) = &options.dynamic_tail {
        quote! {
            /// This compact layout carries a Hopper dynamic tail
            /// (`[disc][fixed_head][tail]`). The fixed head stays zero-copy;
            /// tail access is explicit via the `tail_*` helpers below.
            pub const HAS_DYNAMIC_TAIL: bool = true;

            /// Byte offset of the tail's `u32 LE` length prefix, immediately
            /// after the fixed compact head. The payload starts 4 bytes later.
            pub const TAIL_PREFIX_OFFSET: usize = Self::COMPACT_LEN;

            /// Bytes to allocate for a fresh compact-dynamic account whose tail
            /// payload may grow to `tail_capacity` bytes: disc + fixed head +
            /// the 4-byte length prefix + `tail_capacity`.
            #[inline]
            pub const fn space_for_tail(tail_capacity: usize) -> usize {
                Self::COMPACT_LEN + 4 + tail_capacity
            }

            /// Read the tail's length prefix.
            #[inline]
            pub fn tail_len(data: &[u8]) -> ::core::result::Result<
                u32, ::hopper::__runtime::ProgramError,
            > {
                ::hopper::__runtime::read_tail_len(data, Self::TAIL_PREFIX_OFFSET)
            }

            /// Decode and return the dynamic tail as `#tail_ty`.
            #[inline]
            pub fn tail_read(data: &[u8]) -> ::core::result::Result<
                #tail_ty, ::hopper::__runtime::ProgramError,
            > {
                ::hopper::__runtime::read_tail::<#tail_ty>(data, Self::TAIL_PREFIX_OFFSET)
            }

            /// Encode `tail` in place and update the u32 length prefix. Returns
            /// the number of payload bytes written (excluding the prefix). The
            /// caller must ensure the account has room (call `resize` first when
            /// growing).
            #[inline]
            pub fn tail_write(
                data: &mut [u8],
                tail: &#tail_ty,
            ) -> ::core::result::Result<usize, ::hopper::__runtime::ProgramError> {
                ::hopper::__runtime::write_tail::<#tail_ty>(data, Self::TAIL_PREFIX_OFFSET, tail)
            }
        }
    } else if options.raw_tail {
        quote! {
            /// This compact layout carries a Hopper raw final tail. The fixed
            /// head stays zero-copy; the final dynamic payload consumes the
            /// remaining tail bytes without a field-level prefix.
            pub const HAS_DYNAMIC_TAIL: bool = true;
            pub const HAS_RAW_DYNAMIC_TAIL: bool = true;

            /// Byte offset of the tail's `u32 LE` length prefix, immediately
            /// after the fixed compact head. The payload starts 4 bytes later.
            pub const TAIL_PREFIX_OFFSET: usize = Self::COMPACT_LEN;

            /// Bytes to allocate for a fresh compact-dynamic account whose tail
            /// payload may grow to `tail_capacity` bytes.
            #[inline]
            pub const fn space_for_tail(tail_capacity: usize) -> usize {
                Self::COMPACT_LEN + 4 + tail_capacity
            }

            /// Read the tail's length prefix.
            #[inline]
            pub fn tail_len(data: &[u8]) -> ::core::result::Result<
                u32, ::hopper::__runtime::ProgramError,
            > {
                ::hopper::__runtime::read_tail_len(data, Self::TAIL_PREFIX_OFFSET)
            }

            /// Borrow the full dynamic-tail payload, excluding the u32 prefix.
            #[inline]
            pub fn tail_payload<'a>(data: &'a [u8]) -> ::core::result::Result<
                &'a [u8], ::hopper::__runtime::ProgramError,
            > {
                ::hopper::__runtime::tail_payload(data, Self::TAIL_PREFIX_OFFSET)
            }
        }
    } else if options.dynamic {
        quote! {
            /// This compact layout has a **program-managed** dynamic tail
            /// (`[disc][fixed_head][tail]`) with no length prefix, typically
            /// overlaid with a zero-copy collection (`TailVec` / `TailRing` /
            /// `TailSlab`) through the `CompactTail` helpers. The tail region
            /// begins at `<Self as CompactDynamicLayout>::TAIL_OFFSET`
            /// (== `COMPACT_LEN`).
            pub const HAS_DYNAMIC_TAIL: bool = true;

            /// Borrow the program-managed tail region (bytes after the fixed
            /// head). Returns an error if `data` is shorter than the fixed
            /// head, which a validated load already rules out.
            #[inline]
            pub fn tail_region(data: &[u8]) -> ::core::result::Result<
                &[u8], ::hopper::__runtime::ProgramError,
            > {
                data.get(Self::COMPACT_LEN..)
                    .ok_or(::hopper::__runtime::ProgramError::AccountDataTooSmall)
            }

            /// Mutably borrow the program-managed tail region.
            #[inline]
            pub fn tail_region_mut(data: &mut [u8]) -> ::core::result::Result<
                &mut [u8], ::hopper::__runtime::ProgramError,
            > {
                let start = Self::COMPACT_LEN;
                if data.len() < start {
                    return ::core::result::Result::Err(
                        ::hopper::__runtime::ProgramError::AccountDataTooSmall,
                    );
                }
                ::core::result::Result::Ok(&mut data[start..])
            }

            /// Bytes to allocate for a fresh compact account whose program-
            /// managed tail region needs `tail_capacity` bytes: disc + fixed
            /// head + `tail_capacity`.
            #[inline]
            pub const fn space_for_tail(tail_capacity: usize) -> usize {
                Self::COMPACT_LEN + tail_capacity
            }
        }
    } else {
        quote! {
            /// This compact layout has no dynamic tail; emitted unconditionally
            /// so callers can branch on it at compile time.
            pub const HAS_DYNAMIC_TAIL: bool = false;
        }
    };

    // Owner-checked load/init helpers. With a tail they route through the
    // relaxed `*_compact_dynamic` runtime (length `>=` the fixed head); without
    // one they use the exact-length `*_compact` runtime. Method names are
    // identical so user code is uniform across fixed and dynamic compact types.
    let compact_load_helpers = if has_tail {
        quote! {
            /// Load the fixed head of this compact-dynamic account, owned by
            /// `program_id`. The tail is accessed via the `tail_*` helpers.
            #[inline(always)]
            pub fn load_compact<'a>(
                account: &'a ::hopper::prelude::AccountView<'a>,
                program_id: &::hopper::prelude::Address,
            ) -> ::core::result::Result<
                ::hopper::__runtime::Ref<'a, Self>,
                ::hopper::__runtime::ProgramError,
            > {
                account.check_owned_by(program_id)?;
                account.load_compact_dynamic::<Self>()
            }

            /// Mutably load the fixed head, owned and writable by `program_id`.
            #[inline(always)]
            pub fn load_compact_mut<'a>(
                account: &'a ::hopper::prelude::AccountView<'a>,
                program_id: &::hopper::prelude::Address,
            ) -> ::core::result::Result<
                ::hopper::__runtime::RefMut<'a, Self>,
                ::hopper::__runtime::ProgramError,
            > {
                account.check_owned_by(program_id)?.check_writable()?;
                account.load_compact_dynamic_mut::<Self>()
            }

            /// Initialise a fresh compact-dynamic account: stamp the disc and
            /// zero the tail length prefix (empty tail, fail-closed).
            #[inline(always)]
            pub fn init_compact(
                account: &::hopper::prelude::AccountView<'_>,
            ) -> ::core::result::Result<(), ::hopper::__runtime::ProgramError> {
                account.init_compact_dynamic::<Self>()
            }
        }
    } else {
        quote! {
            /// Load a compact account owned by `program_id`.
            #[inline(always)]
            pub fn load_compact<'a>(
                account: &'a ::hopper::prelude::AccountView<'a>,
                program_id: &::hopper::prelude::Address,
            ) -> ::core::result::Result<
                ::hopper::__runtime::Ref<'a, Self>,
                ::hopper::__runtime::ProgramError,
            > {
                account.check_owned_by(program_id)?;
                account.load_compact::<Self>()
            }

            /// Mutably load a compact account owned and writable by `program_id`.
            #[inline(always)]
            pub fn load_compact_mut<'a>(
                account: &'a ::hopper::prelude::AccountView<'a>,
                program_id: &::hopper::prelude::Address,
            ) -> ::core::result::Result<
                ::hopper::__runtime::RefMut<'a, Self>,
                ::hopper::__runtime::ProgramError,
            > {
                account.check_owned_by(program_id)?.check_writable()?;
                account.load_compact_mut::<Self>()
            }

            /// Stamp the discriminator on a fresh account (offset 0).
            #[inline(always)]
            pub fn init_compact(
                account: &::hopper::prelude::AccountView<'_>,
            ) -> ::core::result::Result<(), ::hopper::__runtime::ProgramError> {
                account.init_compact::<Self>()
            }

            /// Stamp the discriminator, zero the body, and return it to fill
            /// in, in one borrow.
            #[inline(always)]
            pub fn init_compact_mut<'a>(
                account: &'a ::hopper::prelude::AccountView<'a>,
            ) -> ::core::result::Result<
                ::hopper::__runtime::RefMut<'a, Self>,
                ::hopper::__runtime::ProgramError,
            > {
                account.init_compact_mut::<Self>()
            }
        }
    };

    // A compact-dynamic layout implements `CompactDynamicLayout` (relaxed
    // length validation); a fixed compact layout implements `CompactLayout`.
    let compact_trait_impl = if has_tail {
        quote! {
            impl ::hopper::account::CompactDynamicLayout for #name {
                const DISC: u8 = #name::DISC;
            }
        }
    } else {
        quote! {
            impl ::hopper::account::CompactLayout for #name {
                const DISC: u8 = #name::DISC;
            }
        }
    };

    let descriptor_tail = if has_tail {
        quote! { .with_dynamic_tail() }
    } else {
        quote! {}
    };

    let (named_fields, named_methods) = named_field_model(&input, fields)?;
    let expanded = quote! {
        #input

        #named_fields

        // ── Compile-time safety fence (compact) ────────────────────────
        const _: () = {
            assert!(
                core::mem::align_of::<#name>() == 1,
                "hopper_state(compact) layouts must use alignment-1 field types such as WireU64 or TypedAddress",
            );
            assert!(
                core::mem::size_of::<#name>() == ((#body_size) as usize),
                "hopper_state(compact) layouts must be #[repr(C)] with no implicit padding",
            );
            assert!(
                core::mem::size_of::<#name>() > 0,
                "hopper_state(compact) layouts must have at least one field; zero-sized overlays project to dangling pointers",
            );
            assert!(
                #disc != 0,
                "hopper_state(compact) discriminator must be non-zero: a zero discriminator cannot be distinguished from an uninitialized account",
            );
        };

        #(#module_items)*

        impl #name {
            #named_methods
            // One parameter per field mirrors the user's struct.
            #[allow(clippy::too_many_arguments)]
            #[inline(always)]
            #vis const fn new(#(#constructor_params),*) -> Self {
                Self {
                    #(#constructor_inits),*
                }
            }

            #(#inherent_items)*

            /// Zero-copy body size in bytes (no discriminator).
            pub const BODY_SIZE: usize = core::mem::size_of::<Self>();
            /// Total compact wire length: 1 discriminator byte + body.
            pub const COMPACT_LEN: usize =
                ::hopper::account::COMPACT_BODY_OFFSET + Self::BODY_SIZE;
            /// Minimum account data length to load this layout. Equal to
            /// [`Self::COMPACT_LEN`]; compact layouts are fixed-size.
            pub const MIN_SIZE: usize = Self::COMPACT_LEN;
            /// Bytes to allocate for a fresh compact account. Spelled
            /// `INIT_SPACE` for Anchor-style `space = T::INIT_SPACE` parity.
            pub const INIT_SPACE: usize = Self::COMPACT_LEN;
            /// Discriminator byte stored at offset 0.
            pub const DISC: u8 = #disc;
            /// Layout version.
            pub const VERSION: u8 = #version;
            /// 8-byte wire fingerprint (same algorithm as headered layouts).
            pub const LAYOUT_ID: [u8; 8] = #layout_id_tokens;
            /// Deterministic 8-byte hash of the type name, for registry rows.
            pub const NAME_HASH: [u8; 8] =
                ::hopper::manifest::name_hash(stringify!(#name));

            /// Build the Tier-2 registry row describing this compact layout.
            ///
            /// Delegates to the single [`LayoutDescriptor::DESCRIPTOR`] so
            /// the loader, the registry row, and the off-chain metadata can
            /// never drift. Lets a program list its compact accounts in an
            /// on-chain registry (or off-chain manifest) without
            /// hand-writing the `AccountLayoutEntry`.
            #[inline]
            #vis fn registry_entry() -> ::hopper::manifest::AccountLayoutEntry {
                <Self as ::hopper::manifest::LayoutDescriptor>::DESCRIPTOR.registry_entry()
            }

            /// Overlay the body on `body_bytes` (the bytes *after* the
            /// discriminator). Use [`Self::load_compact`] for whole accounts.
            #[inline(always)]
            pub fn overlay_body(
                body_bytes: &[u8],
            ) -> ::core::result::Result<&Self, ::hopper::__runtime::ProgramError> {
                ::hopper::hopper_core::account::pod_from_bytes::<Self>(body_bytes)
            }

            #compact_load_helpers

            #compact_tail_methods

            /// Declared semantic role per field, in declaration order.
            pub const FIELD_ROLES: &'static [(&'static str, &'static str)] = &[
                #( (#field_name_literals, #field_role_literals) ),*
            ];

            /// Declared invariant name per field, in declaration order.
            pub const FIELD_INVARIANTS: &'static [(&'static str, &'static str)] = &[
                #( (#field_name_literals, #field_invariant_literals) ),*
            ];

            /// Compile-time layout manifest for this compact account type.
            ///
            /// Same shape as the headered emission, honest to the compact
            /// wire format: `total_size` is [`Self::COMPACT_LEN`]
            /// (`[disc:u8][body]`, no 16-byte header) and field offsets
            /// fold in the single discriminator byte. Field intents come
            /// from declared `#[role = "..."]` attributes (`Custom` when
            /// undeclared; nothing is guessed).
            pub const LAYOUT_MANIFEST: ::hopper::hopper_schema::LayoutManifest = {
                const FIELD_COUNT: usize = #compact_field_count;
                const NAMES: [&str; FIELD_COUNT] = [#(#field_name_literals),*];
                const TYPES: [&str; FIELD_COUNT] = [#(#field_type_literals),*];
                const SIZES: [u16; FIELD_COUNT] = [#(core::mem::size_of::<#field_types>() as u16),*];
                const INTENTS: [::hopper::hopper_schema::FieldIntent; FIELD_COUNT] = [
                    #(#field_intent_tokens),*
                ];
                const FIELDS: [::hopper::hopper_schema::FieldDescriptor; FIELD_COUNT] = {
                    let mut result = [::hopper::hopper_schema::FieldDescriptor {
                        name: "",
                        canonical_type: "",
                        size: 0,
                        offset: 0,
                        intent: ::hopper::hopper_schema::FieldIntent::Custom,
                    }; FIELD_COUNT];
                    let mut offset = ::hopper::account::COMPACT_BODY_OFFSET as u16;
                    let mut index = 0;
                    while index < FIELD_COUNT {
                        result[index] = ::hopper::hopper_schema::FieldDescriptor {
                            name: NAMES[index],
                            canonical_type: TYPES[index],
                            size: SIZES[index],
                            offset,
                            intent: INTENTS[index],
                        };
                        offset += SIZES[index];
                        index += 1;
                    }
                    result
                };

                ::hopper::hopper_schema::LayoutManifest {
                    name: stringify!(#name),
                    version: #name::VERSION,
                    disc: #name::DISC,
                    layout_id: #name::LAYOUT_ID,
                    total_size: #name::COMPACT_LEN,
                    has_dynamic_tail: #name::HAS_DYNAMIC_TAIL,
                    field_count: FIELD_COUNT,
                    fields: &FIELDS,
                }
            };
        }

        // Copy proof: the canonical Pod contract is `Copy + Sized`.
        #[doc(hidden)]
        const _: () = {
            struct __CompactCopyProof<T: ::core::clone::Clone + ::core::marker::Copy>(
                ::core::marker::PhantomData<T>,
            );
            const _: __CompactCopyProof<#name> =
                __CompactCopyProof(::core::marker::PhantomData);
        };

        // Field-level Pod proof: each field type is forced through the
        // Pod bound so a non-Pod field fails at the field, not at a load.
        #[doc(hidden)]
        const _: () = {
            struct __CompactFieldPodProof<T: ::hopper::__runtime::Pod>(
                ::core::marker::PhantomData<T>,
            );
            #(
                #[allow(dead_code)]
                const _: __CompactFieldPodProof<#field_types> =
                    __CompactFieldPodProof(::core::marker::PhantomData);
            )*
        };

        // SAFETY: as on the headered path. The struct is `#[repr(C)]`,
        // every field is proven `Pod`, and the size assertion rules out
        // padding, so every bit pattern is valid at alignment 1 with no
        // pointer inside. The seal below repeats that contract.
        unsafe impl ::hopper::__runtime::Zeroable for #name {}
        // SAFETY: each compact field is Pod and the layout assertions
        // establish alignment 1 and no padding. Every byte pattern remains
        // a valid Rust value independently of representation validation.
        unsafe impl ::hopper::hopper_core::account::Pod for #name {
            #[inline]
            fn validate_value(&self) -> ::hopper::__runtime::__hopper_native::ProgramResult {
                #(#value_checks)*
                ::core::result::Result::Ok(())
            }
        }
        // SAFETY: the compact layout's Pod field proofs and size/alignment
        // assertions establish the seal's no-padding, no-pointer,
        // fixed-size, all-bits-valid contract.
        unsafe impl ::hopper::__runtime::__sealed::HopperZeroCopySealed for #name {}

        // Anchor the layout fingerprint in `.rodata` for `hopper verify`.
        #[allow(unexpected_cfgs)]
        #[cfg_attr(not(target_os = "solana"), used)]
        #[doc(hidden)]
        #[no_mangle]
        pub static #layout_id_anchor_ident: [u8; 8] = #name::LAYOUT_ID;

        impl ::hopper::hopper_core::account::FixedLayout for #name {
            const SIZE: usize = core::mem::size_of::<Self>();
        }

        impl ::hopper::hopper_core::segment_map::SegmentMap for #name {
            const SEGMENTS: &'static [::hopper::hopper_core::segment_map::StaticSegment] = &[
                #(#segment_entries),*
            ];
        }

        // The compact hot-path loader contract. This is what distinguishes
        // a compact layout from a headered one at the type level. A fixed
        // compact layout implements `CompactLayout` (exact-length validation);
        // a compact layout with a dynamic tail implements `CompactDynamicLayout`
        // (length `>=` the fixed head). The headered `LayoutContract` /
        // `SchemaExport` (which assumes a 16-byte header) is deliberately NOT
        // implemented: Tier-2/3 metadata flows through `registry_entry()`.
        #compact_trait_impl

        // The unified one-source-of-truth descriptor. Both compact and
        // headered layouts implement `LayoutDescriptor`, so a program has a
        // single registry/identity model regardless of wire shape. The
        // descriptor is `const`, so the hot path pays nothing for it. A
        // dynamic tail flips the descriptor's tail flag; `min_size` stays the
        // fixed compact prefix length.
        impl ::hopper::manifest::LayoutDescriptor for #name {
            const DESCRIPTOR: ::hopper::manifest::AccountDescriptor =
                ::hopper::manifest::AccountDescriptor::compact(
                    stringify!(#name),
                    #name::DISC,
                    #name::VERSION as u16,
                    #name::BODY_SIZE as u32,
                    #name::LAYOUT_ID,
                )#descriptor_tail;
        }
    };

    Ok(expanded)
}

/// Consume hopper-internal attributes (`#[role = "..."]`,
/// `#[invariant = "..."]`) from a single field and return the
/// extracted metadata. Attributes that fail to parse raise a
/// compile error pointing at the offending span.
///
/// Accepted forms:
///
/// ```ignore
/// #[role = "balance"]
/// #[role(balance)]          // path form, also accepted
/// #[invariant = "balance_nonzero"]
/// ```
fn parse_field_meta(field: &Field) -> Result<FieldMeta> {
    let mut meta = FieldMeta::default();
    for attr in &field.attrs {
        if attr.path().is_ident("role") {
            // Accept either `#[role = "balance"]` or `#[role(balance)]`.
            // The former uses `NameValue` meta; the latter uses `List`.
            // Both are equivalent at the attribute level. we just want
            // the string value.
            if let Ok(nv) = attr.meta.require_name_value() {
                if let syn::Expr::Lit(syn::ExprLit {
                    lit: syn::Lit::Str(s),
                    ..
                }) = &nv.value
                {
                    meta.role = s.value();
                    continue;
                }
                return Err(syn::Error::new_spanned(
                    &nv.value,
                    "#[role = \"...\"] expects a string literal (e.g. \"balance\", \"authority\")",
                ));
            }
            if let Ok(list) = attr.meta.require_list() {
                // Parse `#[role(balance)]` by pulling the single path ident.
                let tokens: TokenStream = list.tokens.clone();
                let parsed: syn::Ident = parse2(tokens).map_err(|_| {
                    syn::Error::new_spanned(
                        &list.tokens,
                        "#[role(...)] expects a single identifier (e.g. balance, authority)",
                    )
                })?;
                meta.role = parsed.to_string();
                continue;
            }
            return Err(syn::Error::new_spanned(
                attr,
                "unsupported #[role] form; use #[role = \"balance\"] or #[role(balance)]",
            ));
        }
        if attr.path().is_ident("bump") {
            // `#[bump]`: mark THIS field as the stored PDA bump the
            // program stored at init. The macro emits
            // `CANONICAL_BUMP_ABS_OFFSET` (headered AND compact walks) so
            // `#[account(seeds = [...], bump = stored)]` can verify the
            // PDA with one sha256 hash instead of a
            // `find_program_address` search. Explicit by design: a field
            // merely NAMED `bump` is never auto-detected. The bare
            // identifier `stored` is reserved in `bump = ...` position;
            // an instruction ARGUMENT named `stored` must be spelled
            // `bump = (stored)` (and the context macro refuses the
            // ambiguous combination outright).
            if !matches!(attr.meta, syn::Meta::Path(_)) {
                return Err(syn::Error::new_spanned(
                    attr,
                    "#[bump] takes no arguments; mark the single u8 field holding the canonical PDA bump",
                ));
            }
            meta.bump = true;
            continue;
        }
        if attr.path().is_ident("check") {
            let check: FieldCheck = attr.parse_args().map_err(|error| {
                syn::Error::new(
                    error.span(),
                    format!(
                        "{error}. #[check(..)] takes a boolean expression over `value`, \
                         e.g. #[check(value >= 1 && value <= 10)] or \
                         #[check(value != 0, error = MyError::Zero)]"
                    ),
                )
            })?;
            meta.checks.push(check);
            continue;
        }
        if attr.path().is_ident("invariant") {
            let nv = attr.meta.require_name_value().map_err(|_| {
                syn::Error::new_spanned(
                    attr,
                    "#[invariant] on a field expects name-value form: #[invariant = \"balance_nonzero\"]",
                )
            })?;
            if let syn::Expr::Lit(syn::ExprLit {
                lit: syn::Lit::Str(s),
                ..
            }) = &nv.value
            {
                meta.invariant = s.value();
                continue;
            }
            return Err(syn::Error::new_spanned(
                &nv.value,
                "#[invariant = \"...\"] expects a string literal (the invariant name)",
            ));
        }
    }
    Ok(meta)
}

/// Remove hopper-internal attributes from a field before the struct is
/// re-emitted. Leaving bare `#[role = "..."]` / `#[invariant = "..."]`
/// in place would cause rustc to reject the struct because those
/// attribute names are not registered with the compiler.
fn strip_hopper_field_attrs(field: &mut Field) {
    field.attrs.retain(|a| {
        !a.path().is_ident("role")
            && !a.path().is_ident("invariant")
            && !a.path().is_ident("bump")
            && !a.path().is_ident("check")
    });
}

/// Map a role string to a `FieldIntent` variant path token stream.
///
/// The role string is matched case-insensitively. An empty string
/// resolves to `FieldIntent::Custom` so fields without a declared
/// role still emit a well-formed descriptor. An unknown role raises
/// a compile error listing the full accepted vocabulary. this is
/// the cheapest place to catch typos (`"authorty"`, `"ballance"`)
/// that would otherwise silently degrade to `Custom`.
fn role_to_intent_tokens(role: &str, span: proc_macro2::Span) -> Result<TokenStream> {
    let normalized = role.to_ascii_lowercase();
    let variant = match normalized.as_str() {
        "" => "Custom",
        "balance" => "Balance",
        "authority" => "Authority",
        "timestamp" => "Timestamp",
        "counter" => "Counter",
        "index" => "Index",
        "basis_points" | "basispoints" | "bps" => "BasisPoints",
        "flag" | "bool" => "Flag",
        "address" | "pubkey" => "Address",
        "hash" | "fingerprint" => "Hash",
        "pda_seed" | "pdaseed" | "seed" => "PDASeed",
        "version" => "Version",
        "bump" => "Bump",
        "nonce" => "Nonce",
        "supply" | "total_supply" => "Supply",
        "limit" | "cap" | "ceiling" => "Limit",
        "threshold" => "Threshold",
        "owner" => "Owner",
        "delegate" => "Delegate",
        "status" | "state" | "lifecycle" => "Status",
        "custom" => "Custom",
        other => {
            return Err(syn::Error::new(
                span,
                format!(
                    "unknown #[role = \"{}\"]. accepted: balance, authority, timestamp, \
                     counter, index, basis_points, flag, address, hash, pda_seed, version, \
                     bump, nonce, supply, limit, threshold, owner, delegate, status, custom",
                    other
                ),
            ));
        }
    };
    let ident = syn::Ident::new(variant, span);
    Ok(quote! { ::hopper::hopper_schema::FieldIntent::#ident })
}

/// Use the same native input types and wire conversions as positional creation.
/// The companion is an input value, never an account overlay or wire format.
fn named_field_model(
    input: &ItemStruct,
    fields: &syn::punctuated::Punctuated<Field, syn::Token![,]>,
) -> Result<(TokenStream, TokenStream)> {
    let name = &input.ident;
    let vis = &input.vis;
    let values_name = format_ident!("{}Fields", name);
    let names: Vec<_> = fields.iter().map(|f| f.ident.as_ref().unwrap()).collect();
    let params = fields
        .iter()
        .map(state_field_param_init)
        .collect::<Result<Vec<_>>>()?;
    let declarations = fields.iter().zip(&params).map(|(field, param)| {
        let field_vis = &field.vis;
        let declaration = &param.0;
        quote! { #field_vis #declaration }
    });
    let inits = params.iter().map(|param| &param.1);
    let assignments = params.iter().map(|param| &param.2);
    Ok((
        quote! {
            /// Named input values for the fixed fields of this state.
            ///
            /// Scalar wire wrappers accept native scalars, as in `new`. This is
            /// not a serialized layout. Dynamic tails must be initialized separately.
            #vis struct #values_name {
                #(#declarations),*
            }

            impl ::hopper::__runtime::AccountFields for #values_name {
                type Layout = #name;

                #[inline(always)]
                fn write(self, layout: &mut #name) -> ::hopper::__runtime::ProgramResult {
                    layout.set_fields(self)
                }
            }
        },
        quote! {
            /// Construct the fixed body from named values; does not write a header
            /// or initialize any dynamic tail.
            #[inline(always)]
            #vis const fn from_fields(values: #values_name) -> Self {
                let #values_name { #(#names),* } = values;
                Self { #(#inits),* }
            }

            /// Replace fixed fields through the caller's existing mutable borrow.
            /// Does not change the header, tail, or the borrow's write permissions.
            #[inline(always)]
            #vis fn set_fields(&mut self, values: #values_name) -> ::hopper::__runtime::ProgramResult {
                let #values_name { #(#names),* } = values;
                #(#assignments)*
                Ok(())
            }
        },
    ))
}

fn state_field_param_init(field: &Field) -> Result<(TokenStream, TokenStream, TokenStream)> {
    let field_name = field
        .ident
        .as_ref()
        .ok_or_else(|| syn::Error::new_spanned(field, "hopper_state requires named fields"))?;
    let field_ty = &field.ty;
    let (param_ty, init_expr) = if let Some(native_ty) = native_wire_param_type(field_ty) {
        (native_ty, quote! { <#field_ty>::new(#field_name) })
    } else {
        (quote! { #field_ty }, quote! { #field_name })
    };

    Ok((
        quote! { #field_name: #param_ty },
        quote! { #field_name: #init_expr },
        quote! { self.#field_name = #init_expr; },
    ))
}

fn native_wire_param_type(ty: &syn::Type) -> Option<TokenStream> {
    let syn::Type::Path(type_path) = ty else {
        return None;
    };
    let ident = type_path.path.segments.last()?.ident.to_string();
    let native = match ident.as_str() {
        "WireBool" => quote! { bool },
        "WireU16" => quote! { u16 },
        "WireU32" => quote! { u32 },
        "WireU64" => quote! { u64 },
        "WireU128" => quote! { u128 },
        "WireI16" => quote! { i16 },
        "WireI32" => quote! { i32 },
        "WireI64" => quote! { i64 },
        "WireI128" => quote! { i128 },
        _ => return None,
    };
    Some(native)
}

/// One `#[check(..)]` rule on a field.
#[derive(Clone)]
struct FieldCheck {
    /// The boolean expression; `value` names the field's native value.
    rule: syn::Expr,
    /// `error = <expr>`: the error a failed rule returns.
    error: Option<syn::Expr>,
}

impl syn::parse::Parse for FieldCheck {
    fn parse(input: syn::parse::ParseStream<'_>) -> Result<Self> {
        let rule: syn::Expr = input.parse()?;
        let mut error = None;
        if input.peek(syn::Token![,]) {
            input.parse::<syn::Token![,]>()?;
            if !input.is_empty() {
                let key: syn::Ident = input.parse()?;
                if key != "error" {
                    return Err(syn::Error::new(
                        key.span(),
                        "expected `error = <expr>` after the rule",
                    ));
                }
                input.parse::<syn::Token![=]>()?;
                error = Some(input.parse()?);
                if input.peek(syn::Token![,]) {
                    input.parse::<syn::Token![,]>()?;
                }
            }
        }
        if !input.is_empty() {
            return Err(input.error(
                "one rule per #[check(..)]: join conditions with `&&`, or add another #[check(..)]",
            ));
        }
        Ok(Self { rule, error })
    }
}

/// An integer literal, negated or not, as `i128`.
fn int_literal(expr: &syn::Expr) -> Option<i128> {
    match expr {
        syn::Expr::Lit(lit) => match &lit.lit {
            syn::Lit::Int(value) => value.base10_parse::<i128>().ok(),
            _ => None,
        },
        syn::Expr::Unary(unary) if matches!(unary.op, syn::UnOp::Neg(_)) => {
            int_literal(&unary.expr)?.checked_neg()
        }
        syn::Expr::Paren(paren) => int_literal(&paren.expr),
        syn::Expr::Group(group) => int_literal(&group.expr),
        _ => None,
    }
}

fn is_value_path(expr: &syn::Expr) -> bool {
    match expr {
        syn::Expr::Path(path) => path.qself.is_none() && path.path.is_ident("value"),
        syn::Expr::Paren(paren) => is_value_path(&paren.expr),
        syn::Expr::Group(group) => is_value_path(&group.expr),
        _ => false,
    }
}

/// The inclusive bounds a rule places on `value`, read from the
/// comparisons with integer literals that the rule joins with `&&`. Every
/// such comparison must hold for the rule to hold, so each is a bound on
/// its own; anything else in the conjunction (a call, another field) can
/// only narrow further and is left out. A rule with `||` at the top
/// decides no bound.
#[cfg(test)]
fn rule_bounds(expr: &syn::Expr, min: &mut Option<i128>, max: &mut Option<i128>) {
    let mut exact = true;
    rule_bounds_exact(expr, min, max, &mut exact);
}

/// [`rule_bounds`], also reporting whether the bounds are the whole rule:
/// `exact` is cleared by any condition that is not a comparison of `value`
/// with an integer literal that a bound expresses.
fn rule_bounds_exact(
    expr: &syn::Expr,
    min: &mut Option<i128>,
    max: &mut Option<i128>,
    exact: &mut bool,
) {
    match expr {
        syn::Expr::Paren(paren) => rule_bounds_exact(&paren.expr, min, max, exact),
        syn::Expr::Group(group) => rule_bounds_exact(&group.expr, min, max, exact),
        syn::Expr::Binary(binary) => {
            if matches!(binary.op, syn::BinOp::And(_)) {
                rule_bounds_exact(&binary.left, min, max, exact);
                rule_bounds_exact(&binary.right, min, max, exact);
                return;
            }
            // Normalize to `value <op> literal`.
            #[derive(Clone, Copy)]
            enum Op {
                Ge,
                Gt,
                Le,
                Lt,
                Eq,
            }
            let op = match binary.op {
                syn::BinOp::Ge(_) => Op::Ge,
                syn::BinOp::Gt(_) => Op::Gt,
                syn::BinOp::Le(_) => Op::Le,
                syn::BinOp::Lt(_) => Op::Lt,
                syn::BinOp::Eq(_) => Op::Eq,
                _ => {
                    *exact = false;
                    return;
                }
            };
            let (op, literal) = if is_value_path(&binary.left) {
                match int_literal(&binary.right) {
                    Some(literal) => (op, literal),
                    None => {
                        *exact = false;
                        return;
                    }
                }
            } else if is_value_path(&binary.right) {
                let flipped = match op {
                    Op::Ge => Op::Le,
                    Op::Gt => Op::Lt,
                    Op::Le => Op::Ge,
                    Op::Lt => Op::Gt,
                    Op::Eq => Op::Eq,
                };
                match int_literal(&binary.left) {
                    Some(literal) => (flipped, literal),
                    None => {
                        *exact = false;
                        return;
                    }
                }
            } else {
                *exact = false;
                return;
            };
            let mut raise = |bound: Option<i128>| {
                if let Some(bound) = bound {
                    *min = Some(min.map_or(bound, |current| current.max(bound)));
                }
            };
            match op {
                Op::Ge => raise(Some(literal)),
                Op::Gt => raise(literal.checked_add(1)),
                Op::Eq => raise(Some(literal)),
                _ => {}
            }
            let mut lower = |bound: Option<i128>| {
                if let Some(bound) = bound {
                    *max = Some(max.map_or(bound, |current| current.min(bound)));
                }
            };
            match op {
                Op::Le => lower(Some(literal)),
                Op::Lt => lower(literal.checked_sub(1)),
                Op::Eq => lower(Some(literal)),
                _ => {}
            }
        }
        _ => *exact = false,
    }
}

fn option_i128_tokens(value: Option<i128>) -> TokenStream {
    match value {
        Some(value) => {
            let literal = proc_macro2::Literal::i128_suffixed(value);
            quote! { ::core::option::Option::Some(#literal) }
        }
        None => quote! { ::core::option::Option::None },
    }
}

/// How the generated `check_account` loads the layout.
#[derive(Clone, Copy)]
enum RuleLoad {
    Headered,
    Compact,
    CompactDynamic,
}

/// The value-rule and accessor surface of a layout: `FIELD_RULES`,
/// `check_rules`, a `try_set_<field>` per ruled field, the `FieldRules`
/// impl the accounts derive finds through its probe, and, with the
/// `accessors` option, native getters and setters for the wire scalars.
fn field_rule_items(
    name: &syn::Ident,
    vis: &syn::Visibility,
    fields: &syn::punctuated::Punctuated<Field, syn::Token![,]>,
    metas: &[FieldMeta],
    accessors: bool,
    load: RuleLoad,
) -> Result<(TokenStream, TokenStream)> {
    let mut descriptors = Vec::new();
    let mut checks = Vec::new();
    let mut methods = Vec::new();

    for (field, meta) in fields.iter().zip(metas) {
        let field_name = field.ident.as_ref().unwrap();
        let field_ty = &field.ty;
        let native = native_wire_param_type(field_ty);
        let read = match &native {
            Some(_) => quote! { self.#field_name.get() },
            None => quote! { self.#field_name },
        };
        let (param_ty, stored) = match &native {
            Some(native) => (native.clone(), quote! { <#field_ty>::new(value) }),
            None => (quote! { #field_ty }, quote! { value }),
        };

        let mut field_checks = Vec::new();
        for check in &meta.checks {
            let rule = &check.rule;
            let text = rule.to_token_stream().to_string();
            let (mut min, mut max, mut exact) = (None, None, true);
            rule_bounds_exact(rule, &mut min, &mut max, &mut exact);
            if let (Some(min), Some(max)) = (min, max) {
                if min > max {
                    return Err(syn::Error::new_spanned(
                        rule,
                        format!(
                            "no value satisfies this rule: it needs `value >= {min}` and \
                             `value <= {max}`"
                        ),
                    ));
                }
            }
            let field_literal = LitStr::new(&field_name.to_string(), field_name.span());
            let min = option_i128_tokens(min);
            let max = option_i128_tokens(max);
            descriptors.push(quote! {
                ::hopper::hopper_schema::FieldRule {
                    field: #field_literal,
                    rule: #text,
                    min: #min,
                    max: #max,
                    exact: #exact,
                }
            });
            let error = match &check.error {
                Some(error) => quote! { (#error).into() },
                None => quote! { ::hopper::__runtime::ProgramError::InvalidAccountData },
            };
            field_checks.push(quote! {
                if !(#rule) {
                    return ::core::result::Result::Err(#error);
                }
            });
        }

        if !field_checks.is_empty() {
            checks.push(quote! {
                {
                    let value = #read;
                    #(#field_checks)*
                }
            });
            let try_set = format_ident!("try_set_{}", field_name);
            let doc = format!(
                "Set `{field_name}` after checking its `#[check]` rules against the new value; \
                 a refused value leaves the field unchanged."
            );
            methods.push(quote! {
                #[doc = #doc]
                // The rule is the author's expression, kept as written.
                #[allow(clippy::manual_range_contains, clippy::nonminimal_bool)]
                #[inline]
                #vis fn #try_set(&mut self, value: #param_ty) -> ::hopper::__runtime::ProgramResult {
                    #(#field_checks)*
                    self.#field_name = #stored;
                    ::core::result::Result::Ok(())
                }
            });
        }

        if accessors {
            if let Some(native) = &native {
                let getter_doc = format!("`{field_name}` as its native value.");
                methods.push(quote! {
                    #[doc = #getter_doc]
                    #[inline(always)]
                    #vis const fn #field_name(&self) -> #native {
                        self.#field_name.get()
                    }
                });
                // A ruled field is written through `try_set_<field>`.
                if meta.checks.is_empty() {
                    let setter = format_ident!("set_{}", field_name);
                    let setter_doc = format!("Set `{field_name}` from its native value.");
                    methods.push(quote! {
                        #[doc = #setter_doc]
                        #[inline(always)]
                        #vis fn #setter(&mut self, value: #native) {
                            self.#field_name = <#field_ty>::new(value);
                        }
                    });
                }
            }
        }
    }

    let has_rules = !checks.is_empty();
    let check_rules = if has_rules {
        quote! {
            /// Check every `#[check]` rule of this layout, in field order,
            /// and return the first failure.
            // The rules are the author's expressions, kept as written.
            #[allow(clippy::manual_range_contains, clippy::nonminimal_bool)]
            #[inline]
            #vis fn check_rules(&self) -> ::hopper::__runtime::ProgramResult {
                #(#checks)*
                ::core::result::Result::Ok(())
            }
        }
    } else {
        TokenStream::new()
    };
    let inherent = quote! {
        /// The `#[check]` rules of this layout, in field order: the rule as
        /// written and the inclusive integer bounds it decides. Tooling
        /// compares two releases' tables to tell a tightened rule from a
        /// widened one.
        pub const FIELD_RULES: &'static [::hopper::hopper_schema::FieldRule] = &[
            #(#descriptors),*
        ];

        #check_rules

        #(#methods)*
    };

    let module = if has_rules {
        let loaded = match load {
            RuleLoad::Headered => quote! { account.load::<Self>()? },
            RuleLoad::Compact => quote! { account.load_compact::<Self>()? },
            RuleLoad::CompactDynamic => quote! { account.load_compact_dynamic::<Self>()? },
        };
        quote! {
            impl ::hopper::__runtime::layout::FieldRules for #name {
                #[inline(always)]
                fn check_rules(&self) -> ::hopper::__runtime::ProgramResult {
                    #name::check_rules(self)
                }

                #[inline]
                fn check_account(
                    account: &::hopper::prelude::AccountView<'_>,
                ) -> ::hopper::__runtime::ProgramResult {
                    let layout = #loaded;
                    #name::check_rules(&layout)
                }
            }
        }
    } else {
        TokenStream::new()
    };

    Ok((inherent, module))
}

fn parse_state_options(attr: TokenStream) -> Result<StateOptions> {
    if attr.is_empty() {
        return Ok(StateOptions::default());
    }

    let mut options = StateOptions::default();
    let parser = syn::meta::parser(|meta| {
        if meta.path.is_ident("disc") || meta.path.is_ident("discriminator") {
            let value: LitInt = meta.value()?.parse()?;
            options.disc = Some(value.base10_parse()?);
            return Ok(());
        }
        if meta.path.is_ident("version") {
            let value: LitInt = meta.value()?.parse()?;
            options.version = value.base10_parse()?;
            return Ok(());
        }
        if meta.path.is_ident("schema_epoch") {
            let value: LitInt = meta.value()?.parse()?;
            options.schema_epoch = value.base10_parse()?;
            if options.schema_epoch == 0 {
                return Err(
                    meta.error("schema_epoch starts at 1 (0 is read as the pre-epoch default)")
                );
            }
            return Ok(());
        }
        if meta.path.is_ident("dynamic_tail") {
            let ty: syn::Type = meta.value()?.parse()?;
            options.dynamic_tail = Some(ty);
            return Ok(());
        }
        if meta.path.is_ident("raw_tail") {
            let value: syn::LitBool = meta.value()?.parse()?;
            options.raw_tail = value.value;
            return Ok(());
        }
        if meta.path.is_ident("compact") {
            // Accept both the bare flag `compact` and `compact = true`.
            options.compact = match meta.value() {
                Ok(value) => value.parse::<syn::LitBool>()?.value,
                Err(_) => true,
            };
            return Ok(());
        }
        if meta.path.is_ident("dynamic") {
            // Accept both the bare flag `dynamic` and `dynamic = true`.
            options.dynamic = match meta.value() {
                Ok(value) => value.parse::<syn::LitBool>()?.value,
                Err(_) => true,
            };
            return Ok(());
        }
        if meta.path.is_ident("accessors") {
            // Accept both the bare flag `accessors` and `accessors = true`.
            options.accessors = match meta.value() {
                Ok(value) => value.parse::<syn::LitBool>()?.value,
                Err(_) => true,
            };
            return Ok(());
        }
        if meta.path.is_ident("dynamic_tail_schema") || meta.path.is_ident("tail_schema") {
            let value: LitStr = meta.value()?.parse()?;
            options.dynamic_tail_schema = Some(value.value());
            return Ok(());
        }
        Err(meta.error("unsupported hopper_state option; expected `disc = N`, `discriminator = N`, `version = N`, `schema_epoch = N`, `compact`, `dynamic`, `accessors`, `dynamic_tail = T`, `raw_tail = true`, or `dynamic_tail_schema = \"...\"`"))
    });

    parser.parse2(attr)?;
    Ok(options)
}

fn has_repr_c(attrs: &[Attribute]) -> bool {
    attrs.iter().any(|attr| {
        if !attr.path().is_ident("repr") {
            return false;
        }

        let mut has_c = false;
        let _ = attr.parse_nested_meta(|meta| {
            if meta.path.is_ident("C") {
                has_c = true;
            }
            Ok(())
        });
        has_c
    })
}

/// Build the 8-byte wire fingerprint for a layout.
///
/// The earlier algorithm hashed raw Rust token strings, which was
/// source-spelling-dependent and therefore
/// unsuitable as a long-term ABI identity primitive. A rename of
/// `foo::bar::WireU64` to `crate::WireU64`, or a swap of the generic
/// parameter on `TypedAddress<Authority>` → `TypedAddress<Token>`,
/// changed the fingerprint even though the wire layout was identical.
///
/// The audit-compliant algorithm this function implements normalizes
/// each field's type to a **canonical wire stem**:
///
/// - `Type::Path`. the last `::`-separated path segment only
///   (`foo::bar::WireU64` → `WireU64`). `TypedAddress<T>`, the one
///   framework type whose generic is phantom-only, has its parameter
///   stripped (`TypedAddress<Authority>` → `TypedAddress`) so
///   retagging an address stays ABI-invisible. Any other generic
///   argument is folded into the stem (`Pair<WireU32>` →
///   `Pair_WireU32`), because a nested generic Pod overlay's
///   parameters can shift the byte layout; losing them would let two
///   different wire shapes share a fingerprint.
/// - `Type::Array`. `arr_<elem_stem>_<len>` so `[u8; 32]` becomes
///   `arr_u8_32`. stable against spelling variants.
/// - Anything else. fall back to the normalized token string so a
///   non-path type still produces a deterministic value.
///
/// The canonical descriptor format then feeds into SHA-256:
///
/// ```text
/// hopper:wire:v2|S:<StructName>|V:<Version>|
///   f0:<field_name>:<wire_stem>|f1:...|...|tail:<schema-or-type>
/// ```
///
/// Dynamic-tail layouts include either the precise compact-tail schema supplied
/// by `#[hopper::dynamic_account]` or the explicit `dynamic_tail` type token.
/// Fixed-only layouts omit the tail component.
///
/// `hopper:wire:v2` is the fingerprint-algorithm version marker. If
/// the descriptor format itself ever changes, bump this tag and the
/// old fingerprints stay distinguishable.
fn layout_id_bytes(
    name: &syn::Ident,
    version: u8,
    fields: &syn::punctuated::Punctuated<syn::Field, syn::token::Comma>,
    dynamic_tail_fingerprint: Option<&str>,
) -> [u8; 8] {
    let mut input = format!("hopper:wire:v2|S:{}|V:{}", name, version);
    for (idx, field) in fields.iter().enumerate() {
        let field_name = field.ident.as_ref().expect("named fields only");
        let stem = canonical_wire_stem(&field.ty);
        input.push_str(&format!("|f{}:{}:{}", idx, field_name, stem));
    }
    if let Some(tail) = dynamic_tail_fingerprint {
        input.push_str("|tail:");
        input.push_str(tail);
    }

    let digest = Sha256::digest(input.as_bytes());
    let mut layout_id = [0u8; 8];
    layout_id.copy_from_slice(&digest[..8]);
    layout_id
}

/// Normalize a Rust type token to a canonical wire stem.
///
/// See [`layout_id_bytes`] for the full contract. The normalization
/// is deliberately lossy on purely-cosmetic differences (paths,
/// phantom generics) and lossless on anything that actually shifts
/// the wire shape.
fn canonical_wire_stem(ty: &syn::Type) -> String {
    match ty {
        syn::Type::Path(type_path) => {
            if let Some(last) = type_path.path.segments.last() {
                let stem = last.ident.to_string();
                // `TypedAddress<T>`'s parameter is phantom-only, the wire
                // shape is 32 bytes regardless of `T`; so it is deliberately
                // stripped: retagging an address must not shift the ABI
                // fingerprint. Every OTHER generic argument is treated as
                // potentially size-bearing (a nested Pod overlay like
                // `Pair<WireU32>` vs `Pair<WireU64>` changes the byte
                // layout), so its stem folds into the fingerprint. Being
                // over-sensitive here is the safe direction: a phantom-only
                // user generic produces a spurious fingerprint change (a
                // loud false alarm), never a silent collision between two
                // different wire shapes.
                if stem == "TypedAddress" {
                    return stem;
                }
                match &last.arguments {
                    syn::PathArguments::None => stem,
                    syn::PathArguments::AngleBracketed(args) => {
                        let mut out = stem;
                        for arg in &args.args {
                            match arg {
                                syn::GenericArgument::Type(inner) => {
                                    out.push('_');
                                    out.push_str(&canonical_wire_stem(inner));
                                }
                                syn::GenericArgument::Const(expr) => {
                                    out.push('_');
                                    out.push_str(&strip_int_literal_suffix(
                                        &expr
                                            .to_token_stream()
                                            .to_string()
                                            .replace(char::is_whitespace, ""),
                                    ));
                                }
                                // Lifetimes and associated-type bindings do
                                // not shift the wire shape.
                                _ => {}
                            }
                        }
                        out
                    }
                    // `Fn(..)`-style parenthesized arguments cannot appear
                    // on a Pod field; keep the deterministic fallback.
                    syn::PathArguments::Parenthesized(_) => ty
                        .to_token_stream()
                        .to_string()
                        .replace(char::is_whitespace, ""),
                }
            } else {
                "unknown_path".to_string()
            }
        }
        syn::Type::Array(arr) => {
            let elem = canonical_wire_stem(&arr.elem);
            // `[u8; 32]` → `arr_u8_32`. Normalize so `[u8; 32]`,
            // `[u8; 32usize]`, and `[u8 ; 32]` all hash the same:
            // strip whitespace, then strip any integer-type suffix
            // (`u8`, `u16`, …, `usize`, `i8`, …) that a literal may
            // carry. We only touch the trailing non-digit tail so an
            // expression-shaped length like `N + 1` stays intact.
            let raw = arr
                .len
                .to_token_stream()
                .to_string()
                .replace(char::is_whitespace, "");
            let canonical_len = strip_int_literal_suffix(&raw);
            format!("arr_{}_{}", elem, canonical_len)
        }
        syn::Type::Tuple(tup) if tup.elems.is_empty() => "unit".to_string(),
        // Fallback: deterministic whitespace-stripped token string.
        // Not ideal, but covers exotic types (references, slices,
        // bare function pointers) without producing a collision.
        other => other
            .to_token_stream()
            .to_string()
            .replace(char::is_whitespace, ""),
    }
}

fn byte_array_literal(bytes: &[u8; 8]) -> TokenStream {
    let items = bytes.iter();
    quote! { [#(#items),*] }
}

/// Strip a Rust integer literal's type suffix if the literal is a
/// pure digit run, e.g. `"32usize"` → `"32"`, `"255u8"` → `"255"`,
/// `"0x10u32"` → `"0x10"`. Expression-shaped strings like `"N + 1"`
/// or `"SIZE"` are returned unchanged.
fn strip_int_literal_suffix(raw: &str) -> String {
    // Only strip if the prefix is a plausible integer literal: starts
    // with a digit, and the trailing non-digit tail is one of the
    // known integer-type suffixes.
    if !raw.chars().next().is_some_and(|c| c.is_ascii_digit()) {
        return raw.to_string();
    }
    const SUFFIXES: &[&str] = &[
        "usize", "isize", "u128", "i128", "u64", "i64", "u32", "i32", "u16", "i16", "u8", "i8",
    ];
    for suffix in SUFFIXES {
        if let Some(stripped) = raw.strip_suffix(suffix) {
            // Guard: the character immediately before the suffix must
            // be a digit (or `_` which Rust allows inside literals),
            // otherwise the suffix is actually the type identifier for
            // something like `N_u32` (an identifier).
            let before_ok = stripped
                .chars()
                .last()
                .is_some_and(|c| c.is_ascii_digit() || c == '_');
            if before_ok {
                return stripped.to_string();
            }
        }
    }
    raw.to_string()
}

// ══════════════════════════════════════════════════════════════════════
//  Canonical wire fingerprint. regression tests
// ══════════════════════════════════════════════════════════════════════
//
// These tests lock in the no-source-spelling-drift invariant:
// path imports, full-qualification, and phantom-only generic parameters
// MUST produce the same wire fingerprint, because none of them change
// the byte layout of the serialized account.

#[cfg(test)]
mod fingerprint_tests {
    use super::*;
    use syn::parse_quote;

    fn fp(ty: syn::Type) -> String {
        canonical_wire_stem(&ty)
    }

    #[test]
    fn path_spelling_drift_does_not_change_stem() {
        assert_eq!(fp(parse_quote!(WireU64)), fp(parse_quote!(crate::WireU64)));
        assert_eq!(
            fp(parse_quote!(WireU64)),
            fp(parse_quote!(hopper_native::wire::WireU64)),
        );
        assert_eq!(fp(parse_quote!(WireU64)), fp(parse_quote!(self::WireU64)));
    }

    #[test]
    fn phantom_generic_parameters_are_stripped() {
        // `TypedAddress<Authority>` and `TypedAddress<Token>` have
        // identical byte layout; they must hash the same under the
        // canonical algorithm.
        assert_eq!(
            fp(parse_quote!(TypedAddress<Authority>)),
            fp(parse_quote!(TypedAddress<Token>)),
        );
        assert_eq!(
            fp(parse_quote!(TypedAddress<Authority>)),
            fp(parse_quote!(TypedAddress)),
        );
    }

    #[test]
    fn size_bearing_generic_arguments_fold_into_the_stem() {
        // A generic Pod overlay's parameters can shift the wire shape:
        // `Pair<WireU32>` and `Pair<WireU64>` are different byte
        // layouts and MUST produce different stems. (Batch 4 audit
        // finding: the pre-fix algorithm stripped ALL generic
        // arguments, so these collided, and `Pack<WireU64, WireU32>`
        // vs `Pack<WireU32, WireU64>` even collided at equal total
        // size, defeating the foreign-lens drift check entirely.)
        assert_ne!(
            fp(parse_quote!(Pair<WireU32>)),
            fp(parse_quote!(Pair<WireU64>)),
        );
        assert_ne!(
            fp(parse_quote!(Pack<WireU64, WireU32>)),
            fp(parse_quote!(Pack<WireU32, WireU64>)),
        );
        // Path spelling of the argument stays cosmetic.
        assert_eq!(
            fp(parse_quote!(Pair<WireU32>)),
            fp(parse_quote!(Pair<crate::wire::WireU32>)),
        );
        // Const generic arguments are size-bearing too.
        assert_ne!(
            fp(parse_quote!(FixedBytes<16>)),
            fp(parse_quote!(FixedBytes<32>)),
        );
        assert_eq!(
            fp(parse_quote!(FixedBytes<32>)),
            fp(parse_quote!(FixedBytes<32usize>)),
        );
    }

    #[test]
    fn arrays_normalize_whitespace_and_usize_suffix() {
        assert_eq!(fp(parse_quote!([u8; 32])), fp(parse_quote!([u8; 32])));
        assert_eq!(fp(parse_quote!([u8; 32])), fp(parse_quote!([u8; 32usize])));
    }

    #[test]
    fn different_wire_types_still_distinguishable() {
        // Two genuinely different wire types must produce different
        // stems, otherwise we've over-normalized and lost ABI safety.
        assert_ne!(fp(parse_quote!(WireU64)), fp(parse_quote!(WireU32)));
        assert_ne!(fp(parse_quote!([u8; 32])), fp(parse_quote!([u8; 64])));
        assert_ne!(fp(parse_quote!(u8)), fp(parse_quote!(u16)));
    }

    #[test]
    fn unit_and_tuple_roll_up_cleanly() {
        assert_eq!(fp(parse_quote!(())), "unit");
    }
}

// ══════════════════════════════════════════════════════════════════════
//  Field-attribute parsing. regression tests (Task 18)
// ══════════════════════════════════════════════════════════════════════
//
// These tests lock in the per-field declarative surface introduced to
// close the "Anchor has no field intent" gap. Three properties matter:
//
//   1. Both `#[role = "..."]` and `#[role(...)]` work and agree.
//   2. Role strings map to the correct `FieldIntent` variant path, and
//      unknown roles produce a readable compile error rather than
//      silently degrading to `Custom`.
//   3. Stripping the hopper-internal attrs leaves the struct re-emit
//      valid. no `#[role]` leaks through to rustc.

#[cfg(test)]
mod field_attr_tests {
    use super::*;
    use syn::parse_quote;

    fn parse_first_field(f: syn::Field) -> FieldMeta {
        parse_field_meta(&f).expect("valid field meta")
    }

    #[test]
    fn name_value_role_parses() {
        let f: syn::Field = parse_quote!(
            #[role = "balance"]
            pub amount: WireU64
        );
        let m = parse_first_field(f);
        assert_eq!(m.role, "balance");
        assert_eq!(m.invariant, "");
    }

    #[test]
    fn path_form_role_parses() {
        let f: syn::Field = parse_quote!(
            #[role(authority)]
            pub owner: TypedAddress<Authority>
        );
        let m = parse_first_field(f);
        assert_eq!(m.role, "authority");
    }

    fn bounds(rule: syn::Expr) -> (Option<i128>, Option<i128>) {
        let (mut min, mut max) = (None, None);
        rule_bounds(&rule, &mut min, &mut max);
        (min, max)
    }

    #[test]
    fn rule_bounds_come_from_the_literal_comparisons_of_a_conjunction() {
        assert_eq!(
            bounds(parse_quote!(value >= 1 && value <= 10)),
            (Some(1), Some(10))
        );
        assert_eq!(
            bounds(parse_quote!(value > 1 && value < 10)),
            (Some(2), Some(9))
        );
        assert_eq!(bounds(parse_quote!(3 <= value)), (Some(3), None));
        assert_eq!(
            bounds(parse_quote!(-7 < value && (value) <= -2)),
            (Some(-6), Some(-2))
        );
        assert_eq!(bounds(parse_quote!(value == 4)), (Some(4), Some(4)));
        // The narrowest of repeated bounds.
        assert_eq!(
            bounds(parse_quote!(
                value >= 1 && value >= 5 && value <= 9 && value <= 7
            )),
            (Some(5), Some(7))
        );
        // Other conjuncts only narrow; the literal bounds stand.
        assert_eq!(
            bounds(parse_quote!(
                value >= 1 && value <= self.cap.get() && value != 3
            )),
            (Some(1), None)
        );
        // A disjunction, a constant, another operand: no bound.
        assert_eq!(
            bounds(parse_quote!(value == 0 || value >= 10)),
            (None, None)
        );
        assert_eq!(bounds(parse_quote!(value <= MAX)), (None, None));
        assert_eq!(bounds(parse_quote!(self.other.get() <= 10)), (None, None));
        assert_eq!(bounds(parse_quote!(value + 1 <= 10)), (None, None));
    }

    #[test]
    fn check_attr_parses_the_rule_and_the_error() {
        let f: syn::Field = parse_quote!(
            #[check(value >= 1)]
            #[check(value <= 10, error = MyError::TooBig)]
            pub tier: u8
        );
        let m = parse_first_field(f);
        assert_eq!(m.checks.len(), 2);
        assert!(m.checks[0].error.is_none());
        assert!(m.checks[1].error.is_some());
    }

    #[test]
    fn a_malformed_check_names_the_accepted_forms() {
        for field in [
            parse_quote!(#[check] pub tier: u8),
            parse_quote!(#[check(value >= 1, value <= 10)] pub tier: u8),
            parse_quote!(#[check(value >= 1, err = E)] pub tier: u8),
        ] {
            let field: syn::Field = field;
            let error = parse_field_meta(&field)
                .err()
                .expect("must refuse")
                .to_string();
            assert!(
                error.contains("#[check(value >= 1 && value <= 10)]"),
                "{error}"
            );
        }
    }

    #[test]
    fn a_rule_no_value_satisfies_is_a_compile_error() {
        let error = expand(
            quote!(disc = 1),
            quote! {
                #[derive(Clone, Copy)]
                #[repr(C)]
                pub struct Broken {
                    #[check(value >= 10 && value < 10)]
                    pub tier: u8,
                }
            },
        )
        .expect_err("must refuse")
        .to_string();
        assert!(error.contains("no value satisfies"), "{error}");
    }

    #[test]
    fn invariant_attr_parses() {
        let f: syn::Field = parse_quote!(
            #[invariant = "balance_nonzero"]
            pub amount: WireU64
        );
        let m = parse_first_field(f);
        assert_eq!(m.invariant, "balance_nonzero");
        assert_eq!(m.role, "");
    }

    #[test]
    fn both_attrs_parse_together() {
        let f: syn::Field = parse_quote!(
            #[role = "balance"]
            #[invariant = "balance_nonzero"]
            pub amount: WireU64
        );
        let m = parse_first_field(f);
        assert_eq!(m.role, "balance");
        assert_eq!(m.invariant, "balance_nonzero");
    }

    #[test]
    fn unknown_role_is_rejected() {
        // Typo in role name must produce a compile error, not a silent
        // downgrade to `Custom`. That's the whole point of making this
        // a closed vocabulary instead of a free-form string.
        let span = proc_macro2::Span::call_site();
        let err = role_to_intent_tokens("authorty", span).unwrap_err();
        let msg = err.to_string();
        assert!(
            msg.contains("unknown #[role = \"authorty\"]"),
            "expected helpful error, got: {msg}",
        );
        assert!(
            msg.contains("authority"),
            "error message should suggest valid vocabulary"
        );
    }

    #[test]
    fn empty_role_maps_to_custom() {
        // Fields without `#[role = ...]` must still emit a well-formed
        // FieldIntent (Custom) rather than a compile error. The parallel
        // arrays inside `SchemaExport::layout_manifest` rely on every
        // field slot being populated.
        let span = proc_macro2::Span::call_site();
        let tokens = role_to_intent_tokens("", span).expect("empty role is valid");
        let rendered = tokens.to_string().replace(' ', "");
        assert!(
            rendered.ends_with("FieldIntent::Custom"),
            "empty role should render FieldIntent::Custom, got: {rendered}",
        );
    }

    #[test]
    fn role_mapping_covers_full_vocabulary() {
        // Every FieldIntent variant (except the `Custom` fallback) must
        // be reachable through at least one accepted role spelling.
        // If this list drifts from `FieldIntent`, the test fails loudly
        // rather than letting partial coverage rot silently.
        let expected = [
            ("balance", "Balance"),
            ("authority", "Authority"),
            ("timestamp", "Timestamp"),
            ("counter", "Counter"),
            ("index", "Index"),
            ("basis_points", "BasisPoints"),
            ("flag", "Flag"),
            ("address", "Address"),
            ("hash", "Hash"),
            ("pda_seed", "PDASeed"),
            ("version", "Version"),
            ("bump", "Bump"),
            ("nonce", "Nonce"),
            ("supply", "Supply"),
            ("limit", "Limit"),
            ("threshold", "Threshold"),
            ("owner", "Owner"),
            ("delegate", "Delegate"),
            ("status", "Status"),
        ];
        let span = proc_macro2::Span::call_site();
        for (role, variant) in expected {
            let tokens = role_to_intent_tokens(role, span).unwrap_or_else(|e| {
                panic!("role `{role}` should map to FieldIntent::{variant}: {e}")
            });
            let rendered = tokens.to_string().replace(' ', "");
            assert!(
                rendered.ends_with(&format!("FieldIntent::{variant}")),
                "role `{role}` should map to FieldIntent::{variant}, got: {rendered}",
            );
        }
    }

    #[test]
    fn case_variants_and_aliases_resolve() {
        let span = proc_macro2::Span::call_site();
        // Case insensitivity: users should not be punished for
        // `#[role = "Balance"]` vs `#[role = "balance"]`.
        let a = role_to_intent_tokens("Balance", span).unwrap().to_string();
        let b = role_to_intent_tokens("balance", span).unwrap().to_string();
        assert_eq!(a, b);
        // Aliases: `bps` ≡ `basis_points`, `seed` ≡ `pda_seed`, etc.
        let c = role_to_intent_tokens("bps", span).unwrap().to_string();
        let d = role_to_intent_tokens("basis_points", span)
            .unwrap()
            .to_string();
        assert_eq!(c, d);
        let e = role_to_intent_tokens("seed", span).unwrap().to_string();
        let f = role_to_intent_tokens("pda_seed", span).unwrap().to_string();
        assert_eq!(e, f);
    }

    #[test]
    fn strip_removes_hopper_attrs_but_preserves_others() {
        let mut f: syn::Field = parse_quote!(
            #[role = "balance"]
            #[invariant = "balance_nonzero"]
            #[serde(skip)]
            pub amount: WireU64
        );
        strip_hopper_field_attrs(&mut f);
        // `#[serde(skip)]` must survive. anything else the user
        // stacked alongside our attrs is not ours to consume.
        assert_eq!(f.attrs.len(), 1);
        assert!(f.attrs[0].path().is_ident("serde"));
    }
}

fn to_screaming_snake(s: &str) -> String {
    let mut result = String::with_capacity(s.len() + 4);
    for (i, c) in s.chars().enumerate() {
        if c.is_uppercase() && i > 0 {
            result.push('_');
        }
        result.push(c.to_ascii_uppercase());
    }
    result
}

// ─────────────────────────────────────────────────────────────────────
// Macro-expansion tests for `LAYOUT_MANIFEST` (manifest Phase B). Pins
// match the space-stripped expansion, per house style.
// ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod layout_manifest_tests {
    use super::*;
    use quote::quote;

    /// Space-stripped expansion: exact-token pins without `quote`
    /// pretty-printer spacing noise.
    fn expand_spaceless(attr: TokenStream, item: TokenStream) -> String {
        expand(attr, item)
            .expect("state expansion should succeed")
            .to_string()
            .replace(char::is_whitespace, "")
    }

    fn ledger() -> String {
        expand_spaceless(
            quote!(disc = 42, version = 1),
            quote! {
                #[repr(C)]
                pub struct Ledger {
                    pub authority: Address,
                    #[role = "balance"]
                    pub balance: WireU64,
                }
            },
        )
    }

    #[test]
    fn headered_layout_emits_the_layout_manifest_const() {
        let out = ledger();
        assert!(
            out.contains("pubconstLAYOUT_MANIFEST:::hopper::hopper_schema::LayoutManifest="),
            "LAYOUT_MANIFEST const expected: {out}",
        );
        // The literal wires the layout's own contract consts; nothing
        // is restated by hand.
        for wired in [
            "name:stringify!(Ledger)",
            "version:Ledger::VERSION",
            "disc:Ledger::DISC",
            "layout_id:Ledger::LAYOUT_ID",
            "total_size:Ledger::LEN",
            "field_count:FIELD_COUNT",
            "fields:&FIELDS",
        ] {
            assert!(
                out.contains(wired),
                "manifest literal must wire `{wired}`: {out}",
            );
        }
    }

    #[test]
    fn fields_carry_real_types_header_offsets_and_declared_intents() {
        let out = ledger();
        assert!(
            out.contains("constNAMES:[&str;FIELD_COUNT]=[\"authority\",\"balance\"];"),
            "field names table expected: {out}",
        );
        // REAL canonical types, stringified from the authored field
        // types, no lookup table, no guessing.
        assert!(
            out.contains("constTYPES:[&str;FIELD_COUNT]=[\"Address\",\"WireU64\"];"),
            "canonical type table expected: {out}",
        );
        // Intents come from declared `#[role]` attrs; undeclared fields
        // stay `Custom`.
        assert!(
            out.contains(
                "constINTENTS:[::hopper::hopper_schema::FieldIntent;FIELD_COUNT]=\
                 [::hopper::hopper_schema::FieldIntent::Custom,\
                 ::hopper::hopper_schema::FieldIntent::Balance];"
            ),
            "declared-role intent table expected: {out}",
        );
        // Offsets are header-relative: the copy loop starts at
        // HEADER_LEN, exactly like the runtime's FieldMap.
        assert!(
            out.contains("letmutoffset=::hopper::hopper_core::account::HEADER_LENasu16;"),
            "headered offsets must start at HEADER_LEN: {out}",
        );
    }

    #[test]
    fn schema_export_delegates_to_the_single_const() {
        let out = ledger();
        assert!(
            out.contains(
                "impl::hopper::hopper_schema::SchemaExportforLedger{\
                 fnlayout_manifest()->::hopper::hopper_schema::LayoutManifest{\
                 Ledger::LAYOUT_MANIFEST}}"
            ),
            "SchemaExport must return the same LAYOUT_MANIFEST const: {out}",
        );
    }

    #[test]
    fn compact_layout_manifest_is_honest_to_the_compact_wire_shape() {
        let out = expand_spaceless(
            quote!(compact, disc = 9),
            quote! {
                #[repr(C)]
                pub struct Tally {
                    pub count: WireU32,
                }
            },
        );
        assert!(
            out.contains("pubconstLAYOUT_MANIFEST:::hopper::hopper_schema::LayoutManifest="),
            "compact layouts must also publish LAYOUT_MANIFEST: {out}",
        );
        // Compact accounts are `[disc:u8][body]`: total size is
        // COMPACT_LEN and offsets fold in the single discriminator
        // byte, not the 16-byte header.
        assert!(
            out.contains("total_size:Tally::COMPACT_LEN"),
            "compact total_size must be COMPACT_LEN: {out}",
        );
        assert!(
            out.contains("letmutoffset=::hopper::account::COMPACT_BODY_OFFSETasu16;"),
            "compact offsets must start at COMPACT_BODY_OFFSET: {out}",
        );
        assert!(
            !out.contains("HEADER_LENasu16"),
            "compact manifests must not assume the 16-byte header: {out}",
        );
    }
}
