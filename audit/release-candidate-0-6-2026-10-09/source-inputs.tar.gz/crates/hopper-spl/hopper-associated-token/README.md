# hopper-associated-token

Hopper-owned Associated Token Account (ATA) builders. `Create`,
`CreateIdempotent`, `RecoverNested`, plus `ATA_PROGRAM_ID`. ATA derivation
and verification helpers (`derive_ata`, `derive_ata_2022`, `verify_ata`, and
related functions) are re-exported from `hopper-solana` on the SBF target.

[![Crates.io](https://img.shields.io/crates/v/hopper-associated-token.svg)](https://crates.io/crates/hopper-associated-token)
[![Docs.rs](https://img.shields.io/docsrs/hopper-associated-token)](https://docs.rs/crate/hopper-associated-token)

Part of the **[Hopper](https://hopperzero.dev)** framework.

```rust
use hopper::prelude::*;

hopper_associated_token::instructions::CreateIdempotent {
    payer,
    associated_account,
    wallet,
    mint,
    system_program,
    token_program,
}
.invoke()?;
```

Works against both legacy SPL Token and Token-2022 mints; pass the
`token_program` account that matches the mint.

Docs: <https://docs.rs/crate/hopper-associated-token>

Support: `solanadevdao.sol` / `F42ZovBoRJZU4av5MiESVwJWnEx8ZQVFkc1RM29zMxNT`.

License: Apache-2.0.
