//! Hopper-owned Token-2022 builder and screening surface.
//!
//! Thin first-class Hopper wrappers over the canonical runtime builders,
//! plus Token-2022 extension screening re-exports from `hopper-solana`.

#![no_std]
#![deny(unsafe_op_in_unsafe_fn)]

pub mod hook;
pub mod layout;
pub use hook::{
    extra_account_metas_pda, ExtraAccountMeta, ExtraAccountMetaList, HookAccountBuf, HookError,
    ResolvedHookAccount, EXTRA_ACCOUNT_METAS_SEED,
};
pub use hopper_runtime::token::{TokenBatch, TokenInstruction, TokenProgram, TokenSink, Trailing};
pub use hopper_runtime::token_mint::{
    InitializeMint2, MintConfig, MintExtension, MintInstructionData, MintPlan, MintProgram,
};

/// The Token-2022-only instructions: `CreateNativeMint`,
/// `InitializeNonTransferableMint`, `Reallocate`, and every extension
/// family's initializers, updates, and toggles. Each targets Token-2022
/// from `invoke()`; see [`hopper_runtime::token_2022_ix`].
pub mod extension_instructions {
    pub use hopper_runtime::token_2022_ix::*;
}

/// The token-metadata and token-group interface instructions (Token-2022
/// implements both; `invoke_on_program` reaches any other implementer).
pub mod metadata_instructions {
    pub use hopper_runtime::token_metadata_ix::*;
}

/// The confidential-transfer instructions. Ciphertexts, keys, and proofs
/// are produced off chain; the builders carry them as bytes.
pub mod confidential_instructions {
    pub use hopper_runtime::token_confidential_ix::*;
}

/// The instruction set Token-2022 shares with SPL Token, in the checked
/// forms: send any of these to Token-2022 with
/// `invoke_on(TokenProgram::Token2022, multisig_signers, signers)`, or
/// with `invoke_for_owner(..)` to whichever program owns the account.
pub mod checked {
    pub use hopper_runtime::token::{
        AmountToUiAmount, ApproveChecked, BurnChecked, CloseAccount, FreezeAccount,
        GetAccountDataSize, InitializeAccount2, InitializeAccount3, InitializeImmutableOwner,
        InitializeMint, InitializeMultisig, InitializeMultisig2, MintToChecked, Revoke,
        SetAuthority, SyncNative, ThawAccount, TokenAuthorityType, TokenBatch, TokenInstruction,
        TokenProgram, TransferChecked, UiAmountToAmount, WithdrawExcessLamports,
    };
}

use hopper_runtime::instruction::{InstructionAccount, InstructionView, Signer};
use hopper_runtime::{AccountView, ProgramResult};

pub use hopper_solana::constants::TOKEN_2022_PROGRAM_ID;
pub use hopper_solana::mint::{
    check_mint_authority, check_mint_initialized, mint_authority, mint_decimals,
    mint_freeze_authority, mint_supply, MINT_LEN,
};
pub use hopper_solana::token::{
    check_not_frozen, check_token_balance_gte, check_token_initialized, check_token_mint,
    check_token_owner, token_account_amount, token_account_mint, token_account_owner,
    token_account_state, TOKEN_ACCOUNT_LEN,
};
pub use hopper_solana::token2022_ext::{
    check_no_confidential_transfer, check_no_permanent_delegate, check_no_transfer_fee,
    check_no_transfer_hook, check_safe_token_2022_mint, check_transfer_hook_program,
    check_transferable, find_extension_data, mint_has_extension, read_transfer_fee_config,
    read_transfer_hook, token_has_extension, validate_token_2022_mint_extensions,
    TransferFeeConfig, TransferHook, ACCOUNT_TYPE_MINT, ACCOUNT_TYPE_OFFSET, ACCOUNT_TYPE_TOKEN,
    EXT_CONFIDENTIAL_MINT_BURN, EXT_CONFIDENTIAL_TRANSFER_ACCOUNT,
    EXT_CONFIDENTIAL_TRANSFER_FEE_AMOUNT, EXT_CONFIDENTIAL_TRANSFER_FEE_CONFIG,
    EXT_CONFIDENTIAL_TRANSFER_MINT, EXT_CPI_GUARD, EXT_DEFAULT_ACCOUNT_STATE,
    EXT_GROUP_MEMBER_POINTER, EXT_GROUP_POINTER, EXT_IMMUTABLE_OWNER, EXT_INTEREST_BEARING,
    EXT_MEMO_TRANSFER, EXT_METADATA_POINTER, EXT_MINT_CLOSE_AUTHORITY, EXT_NON_TRANSFERABLE,
    EXT_NON_TRANSFERABLE_ACCOUNT, EXT_PAUSABLE, EXT_PAUSABLE_ACCOUNT, EXT_PERMANENT_DELEGATE,
    EXT_PERMISSIONED_BURN, EXT_SCALED_UI_AMOUNT, EXT_TOKEN_GROUP, EXT_TOKEN_GROUP_MEMBER,
    EXT_TOKEN_METADATA, EXT_TRANSFER_FEE_AMOUNT, EXT_TRANSFER_FEE_CONFIG, EXT_TRANSFER_HOOK,
    EXT_TRANSFER_HOOK_ACCOUNT, MAX_KNOWN_EXTENSION_TYPE, MINT_BASE_SIZE, TLV_OFFSET,
    TOKEN_ACCOUNT_BASE_SIZE,
};

/// Builder for Token-2022 Transfer (instruction index 3).
pub struct Transfer<'a> {
    pub from: &'a AccountView<'a>,
    pub to: &'a AccountView<'a>,
    pub authority: &'a AccountView<'a>,
    pub amount: u64,
}

impl Transfer<'_> {
    #[inline]
    pub fn invoke(&self) -> ProgramResult {
        self.invoke_signed(&[])
    }

    #[inline]
    pub fn invoke_signed(&self, signers: &[Signer<'_, '_>]) -> ProgramResult {
        let data = layout::encode_transfer(self.amount);

        let accounts = [
            InstructionAccount::writable(self.from.address()),
            InstructionAccount::writable(self.to.address()),
            InstructionAccount::readonly_signer(self.authority.address()),
        ];
        let views = [self.from, self.to, self.authority];
        let instruction = InstructionView {
            program_id: &TOKEN_2022_PROGRAM_ID,
            data: &data,
            accounts: &accounts,
        };

        hopper_runtime::cpi::invoke_signed(&instruction, &views, signers)
    }
}

/// Builder for Token-2022 MintTo (instruction index 7).
pub struct MintTo<'a> {
    pub mint: &'a AccountView<'a>,
    pub account: &'a AccountView<'a>,
    pub mint_authority: &'a AccountView<'a>,
    pub amount: u64,
}

impl MintTo<'_> {
    #[inline]
    pub fn invoke(&self) -> ProgramResult {
        self.invoke_signed(&[])
    }

    #[inline]
    pub fn invoke_signed(&self, signers: &[Signer<'_, '_>]) -> ProgramResult {
        let data = layout::encode_mint_to(self.amount);

        let accounts = [
            InstructionAccount::writable(self.mint.address()),
            InstructionAccount::writable(self.account.address()),
            InstructionAccount::readonly_signer(self.mint_authority.address()),
        ];
        let views = [self.mint, self.account, self.mint_authority];
        let instruction = InstructionView {
            program_id: &TOKEN_2022_PROGRAM_ID,
            data: &data,
            accounts: &accounts,
        };

        hopper_runtime::cpi::invoke_signed(&instruction, &views, signers)
    }
}

/// Builder for Token-2022 Burn (instruction index 8).
pub struct Burn<'a> {
    pub account: &'a AccountView<'a>,
    pub mint: &'a AccountView<'a>,
    pub authority: &'a AccountView<'a>,
    pub amount: u64,
}

impl Burn<'_> {
    #[inline]
    pub fn invoke(&self) -> ProgramResult {
        self.invoke_signed(&[])
    }

    #[inline]
    pub fn invoke_signed(&self, signers: &[Signer<'_, '_>]) -> ProgramResult {
        let data = layout::encode_burn(self.amount);

        let accounts = [
            InstructionAccount::writable(self.account.address()),
            InstructionAccount::writable(self.mint.address()),
            InstructionAccount::readonly_signer(self.authority.address()),
        ];
        let views = [self.account, self.mint, self.authority];
        let instruction = InstructionView {
            program_id: &TOKEN_2022_PROGRAM_ID,
            data: &data,
            accounts: &accounts,
        };

        hopper_runtime::cpi::invoke_signed(&instruction, &views, signers)
    }
}

/// Builder for Token-2022 CloseAccount (instruction index 9).
pub struct CloseAccount<'a> {
    pub account: &'a AccountView<'a>,
    pub destination: &'a AccountView<'a>,
    pub authority: &'a AccountView<'a>,
}

impl CloseAccount<'_> {
    #[inline]
    pub fn invoke(&self) -> ProgramResult {
        self.invoke_signed(&[])
    }

    #[inline]
    pub fn invoke_signed(&self, signers: &[Signer<'_, '_>]) -> ProgramResult {
        let data = layout::encode_close_account();
        let accounts = [
            InstructionAccount::writable(self.account.address()),
            InstructionAccount::writable(self.destination.address()),
            InstructionAccount::readonly_signer(self.authority.address()),
        ];
        let views = [self.account, self.destination, self.authority];
        let instruction = InstructionView {
            program_id: &TOKEN_2022_PROGRAM_ID,
            data: &data,
            accounts: &accounts,
        };

        hopper_runtime::cpi::invoke_signed(&instruction, &views, signers)
    }
}

/// Builder for Token-2022 Approve (instruction index 4).
pub struct Approve<'a> {
    pub source: &'a AccountView<'a>,
    pub delegate: &'a AccountView<'a>,
    pub authority: &'a AccountView<'a>,
    pub amount: u64,
}

impl Approve<'_> {
    #[inline]
    pub fn invoke(&self) -> ProgramResult {
        self.invoke_signed(&[])
    }

    #[inline]
    pub fn invoke_signed(&self, signers: &[Signer<'_, '_>]) -> ProgramResult {
        let data = layout::encode_approve(self.amount);

        let accounts = [
            InstructionAccount::writable(self.source.address()),
            InstructionAccount::readonly(self.delegate.address()),
            InstructionAccount::readonly_signer(self.authority.address()),
        ];
        let views = [self.source, self.delegate, self.authority];
        let instruction = InstructionView {
            program_id: &TOKEN_2022_PROGRAM_ID,
            data: &data,
            accounts: &accounts,
        };

        hopper_runtime::cpi::invoke_signed(&instruction, &views, signers)
    }
}

/// Builder for Token-2022 Revoke (instruction index 5).
pub struct Revoke<'a> {
    pub source: &'a AccountView<'a>,
    pub authority: &'a AccountView<'a>,
}

impl Revoke<'_> {
    #[inline]
    pub fn invoke(&self) -> ProgramResult {
        self.invoke_signed(&[])
    }

    #[inline]
    pub fn invoke_signed(&self, signers: &[Signer<'_, '_>]) -> ProgramResult {
        let data = layout::encode_revoke();
        let accounts = [
            InstructionAccount::writable(self.source.address()),
            InstructionAccount::readonly_signer(self.authority.address()),
        ];
        let views = [self.source, self.authority];
        let instruction = InstructionView {
            program_id: &TOKEN_2022_PROGRAM_ID,
            data: &data,
            accounts: &accounts,
        };

        hopper_runtime::cpi::invoke_signed(&instruction, &views, signers)
    }
}

/// Builder for Token-2022 InitializeAccount (instruction index 1).
pub struct InitializeAccount<'a> {
    pub account: &'a AccountView<'a>,
    pub mint: &'a AccountView<'a>,
    pub owner: &'a AccountView<'a>,
    pub rent_sysvar: &'a AccountView<'a>,
}

impl InitializeAccount<'_> {
    #[inline]
    pub fn invoke(&self) -> ProgramResult {
        let data = layout::encode_initialize_account();
        let accounts = [
            InstructionAccount::writable(self.account.address()),
            InstructionAccount::readonly(self.mint.address()),
            InstructionAccount::readonly(self.owner.address()),
            InstructionAccount::readonly(self.rent_sysvar.address()),
        ];
        let views = [self.account, self.mint, self.owner, self.rent_sysvar];
        let instruction = InstructionView {
            program_id: &TOKEN_2022_PROGRAM_ID,
            data: &data,
            accounts: &accounts,
        };

        hopper_runtime::cpi::invoke(&instruction, &views)
    }
}

pub mod instructions {
    pub use super::extension_instructions::*;
    pub use super::{
        Approve, Burn, CloseAccount, InitializeAccount, InitializeMint2, MintTo, Revoke, Transfer,
    };
}
