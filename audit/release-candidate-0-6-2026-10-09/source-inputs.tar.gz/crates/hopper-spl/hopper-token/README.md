# hopper-token

Hopper-owned SPL Token builders, the whole instruction set. The default
public API is safety-first: `TransferChecked`, `MintToChecked`, `BurnChecked`,
`ApproveChecked`, plus `CloseAccount`, `Revoke`, `InitializeAccount` (and
`InitializeAccount2` / `InitializeAccount3`), `SetAuthority`, `FreezeAccount`,
`ThawAccount`, `SyncNative`, `InitializeMint`, `InitializeMultisig`,
`InitializeMultisig2`, `InitializeImmutableOwner`, `GetAccountDataSize`,
`AmountToUiAmount`, `UiAmountToAmount`, `WithdrawExcessLamports`, and
`UnwrapLamports`. Stack-allocated instruction data, no heap.

Every builder targets SPL Token from `invoke()` and Token-2022 from
`invoke_on(TokenProgram::Token2022, multisig_signers, signers)`;
`invoke_for_owner(..)` picks whichever of the two owns the builder's first
account and refuses any other owner before the CPI. `TokenBatch` collects
any number of builders and sends them as one p-token `Batch` CPI. The bytes
and account metas of every builder are checked against the canonical
`spl-token-2022-interface` constructors in the runtime's tests, and the
`hopper-token-lab` example runs each family on devnet.

[![Crates.io](https://img.shields.io/crates/v/hopper-token.svg)](https://crates.io/crates/hopper-token)
[![Docs.rs](https://img.shields.io/docsrs/hopper-token)](https://docs.rs/crate/hopper-token)

Part of the **[Hopper](https://hopperzero.dev)** framework.

```rust
use hopper::prelude::*;

hopper_token::instructions::TransferChecked {
    from,
    mint,
    to,
    authority,
    amount,
    decimals,
}
.invoke()?;
```

Deprecated plain builders (`Transfer`, `MintTo`, `Burn`, `Approve`) are hidden
unless the non-default `legacy-token-instructions` feature is enabled. Use that
feature only for migration tests against legacy SPL Token programs that cannot
use the checked instructions.

Version 0.3.1 also exports `InitializeMint2`, `MintConfig`,
`MintProgram`, and `MintPlan`. A legacy plan has no extensions, allocates exactly
82 bytes, and initializes an empty mint with the configured authorities.
Creation uses live rent and supports prefunding and PDA signer seeds. These
APIs are available from the verified 0.3.1 registry release.

For Token-2022 mints with extension awareness, see
[`hopper-token-2022`](https://crates.io/crates/hopper-token-2022).

Docs: <https://docs.rs/crate/hopper-token>

Support: `solanadevdao.sol` / `F42ZovBoRJZU4av5MiESVwJWnEx8ZQVFkc1RM29zMxNT`.

License: Apache-2.0.
