//! Alignment-1 boolean wire type.

use core::fmt;

/// Boolean wire type stored as a single byte.
///
/// `0x00` = `false`, any non-zero = `true`.
/// Normalizes to `0x01` on write.
#[derive(Clone, Copy, Default)]
#[repr(transparent)]
pub struct WireBool([u8; 1]);

// Equality compares the *boolean projection*, not raw bytes: the wire
// rule above makes 0xFF just as `true` as 0x01, so a byte-derived
// PartialEq would report `WireBool([0xFF]) != WireBool::TRUE`, byte
// equality disagreeing with the type's own semantics. (Lawful Eq: the
// projection partitions all 256 patterns into exactly two classes.)
impl PartialEq for WireBool {
    #[inline(always)]
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}
impl Eq for WireBool {}

const _: () = assert!(core::mem::size_of::<WireBool>() == 1);
const _: () = assert!(core::mem::align_of::<WireBool>() == 1);

impl WireBool {
    pub const FALSE: Self = Self([0]);
    pub const TRUE: Self = Self([1]);

    #[inline(always)]
    pub const fn new(v: bool) -> Self {
        Self([v as u8])
    }

    #[inline(always)]
    pub const fn get(self) -> bool {
        self.0[0] != 0
    }

    #[inline(always)]
    pub fn set(&mut self, v: bool) {
        self.0[0] = v as u8;
    }
}

impl From<bool> for WireBool {
    #[inline(always)]
    fn from(v: bool) -> Self {
        Self::new(v)
    }
}

impl From<WireBool> for bool {
    #[inline(always)]
    fn from(w: WireBool) -> Self {
        w.get()
    }
}

impl fmt::Debug for WireBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "WireBool({})", self.get())
    }
}

impl fmt::Display for WireBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.get())
    }
}

// SAFETY: align_of == 1, all bit patterns valid (any non-zero = true), Copy, no drop.
unsafe impl crate::abi::WireType for WireBool {
    const WIRE_SIZE: usize = 1;
    const CANONICAL_NAME: &'static str = "bool";
}

// SAFETY: #[repr(transparent)] over [u8; 1], all bit patterns valid.
unsafe impl crate::account::Zeroable for WireBool {}
unsafe impl crate::account::Pod for WireBool {}
// SAFETY: the type meets the seal's contract, as its `Pod` impl states:
// alignment 1, no padding, no pointers, every bit pattern valid.
unsafe impl ::hopper_runtime::__sealed::HopperZeroCopySealed for WireBool {}

// FixedLayout::SIZE defaults to size_of::<Self>(); the const asserts pin it to 1.
impl crate::account::FixedLayout for WireBool {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bool_roundtrip() {
        assert!(WireBool::new(true).get());
        assert!(!WireBool::new(false).get());
    }

    #[test]
    fn nonzero_is_true() {
        let w = WireBool([0xFF]);
        assert!(w.get());
    }

    #[test]
    fn equality_follows_boolean_semantics_not_bytes() {
        // Any non-zero byte is `true`, so it must equal TRUE even when
        // the raw bytes differ (e.g. written by a foreign program).
        assert_eq!(WireBool([0xFF]), WireBool::TRUE);
        assert_ne!(WireBool([0xFF]), WireBool::FALSE);
        assert_eq!(WireBool([0x00]), WireBool::FALSE);
    }
}
